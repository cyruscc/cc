--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

module("ViewHelp", package.seeall)

local CGameManger = import("app.platform.game.gamemanager")

local Base_Pos = 
{
    userID = tonumber(CGameManger:get_instance():get_client_main():get_user_mgr():get_user_info().UserID),
    chair = -1,
    l_chair = -1
}

local Game_Station_Type ={
	GameUnStart = 0,
	
}

local table_voice_not = {}

local NTChair = 0

function initBasePosChair()
    Base_Pos.chair = -1
    Base_Pos.l_chair = -1
end

function initVoiceNotTable()
    table_voice_not = {}
end

function insertVoiceNotTable(userID)
    removeVoiceNotTable(userID)
    table.insert(table_voice_not, #table_voice_not+1)
end

function removeVoiceNotTable(userID)
   for i=1, #table_voice_not do
        if table_voice_not[i]==userID then
           table.remove(table_voice_not, i)
           break
        end
   end
end

function isElementOfVoiceNotTable(userID)
   for i=1, #table_voice_not do
        if table_voice_not[i]==userID then
            return true
        end
   end
   return false
end

--保存当前玩家的服务器椅子ID
function setBasePosChair(chair)
    if chair == nil then
        return
    end
    Base_Pos.l_chair = Base_Pos.chair
    Base_Pos.chair = chair
end


function getUIChairIndex(chair)
    
    --print("Base_Pos.chair  " ..Base_Pos.chair)
    local client_chair = getClientChairID(Base_Pos.chair)
    return (4 + tonumber(chair) - client_chair)%4+1
end

--根据服务器的椅子id  获取UI上的椅子位置
function getUIChairIndexByServerChair(server_chair)
    local client_chair = getClientChairID(server_chair)

    return getUIChairIndex(client_chair)
     
end

function getClientChairID(server_chair)
    --跟服务器保持椅子号一致  
    --服务器 逆时针           客户端
    --      2                   2      
    --  1       3           3       1
    --      0                   0

--    if server_chair == 0 or server_chair == 2 then
--        return server_chair
--    elseif server_chair == 1 then
--        return 3
--    else
--        return 1
--    end
    return server_chair
end

function getBasePosChair()
    return Base_Pos.chair
end


function getBasePosUserID()
    return Base_Pos.userID
end

function getSelfPlayer()
    return getRoomManager():getSelfInfo()
end

function getRoomManager()
    return CGameManger:get_instance():get_game_room_mgr()

end

--获取当前桌子配置
function getDeskConfig()
    return GameSceneModule:getInstance():getGameScene():getDeskInfo()
end

 

function getNTServerChair()
    return NTChair
end

function setNTServerChair( chair )
    NTChair = chair
end


--endregion
