--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_download = import("....common.download")

local GameOverLayer = class("GameOverLayer",function()
	return cc.CSLoader:createNode("gameres/csb/resultLayer.csb")
end)
--[["<var>" = {
    "zanjilist" = {
        1 = {
            "avatarUrl"  = ""
            "point"      = 0
            "szNickName" = "haciid"
            "userid"     = 85446
        }
        2 = {
            "avatarUrl"  = ""
            "point"      = 0
            "szNickName" = "djbcgj"
            "userid"     = 85458
        }
    }
}]]
function GameOverLayer:ctor(parent,listdata)
    self.parent = parent
	--展示列表
	
	local btn_share = seekNodeByName(self,"btn_share")
	btn_share:addClickEventListener(function()
		print("-----btn_share----")
		cc.utils:captureScreen(function(succeed, outputFile)
            if succeed then
               self.parent:reqShareImageToWXSession(outputFile)
            end
        end, 
        "dahuatouzi_share.jpg")
	end)
	local btn_back = seekNodeByName(self,"btn_back")
	btn_back:addClickEventListener(function()
		print("-----btn_share----")
		self.parent:Exit_game()
	end)
	local Item_tmp = seekNodeByName(self,"itemtmp")
	Item_tmp:setVisible(false);
	--显示列表列表
	local ListView = seekNodeByName(self,"ListView_1")
	
	ListView:removeAllChildren();
	
	if listdata == nil and listdata.zanjilist~= nil  then return end
	
    local length = #(listdata.zanjilist)
	
	if length<1 then return end;
	local data = listdata.zanjilist
    for i=1,length do
        local item = Item_tmp:clone()
        item:setVisible(true)
		--修改头像
		local Image_head = seekNodeByName(item,"Image_head")
		if Image_head~= nil then
			Image_head:loadTexture("platform_res/common/boy0.png")
			if data[i].avatarUrl ~= nil and #(data[i].avatarUrl)>0 then
				m_download:get_instance():set_head_image_and_auto_update( Image_head , data[i].avatarUrl , data[i].userid)
			end
		end
		--修改昵称
		local Text_nickname = seekNodeByName(item,"Text_nickname")
		if Text_nickname ~= nil then
			Text_nickname:setString(data[i].szNickName)
		end
		--修改昵称
		local Text_id = seekNodeByName(item,"Text_id")
		if Text_id ~= nil then
			Text_id:setString("ID:"..data[i].userid)
		end
		local AtlasLabel_successs = seekNodeByName(item,"AtlasLabel_successs")
		local AtlasLabel_fail = seekNodeByName(item,"AtlasLabel_fail")
		AtlasLabel_successs:setVisible(false)
		AtlasLabel_fail:setVisible(false)
		if data[i].point>=0 then
			AtlasLabel_successs:setVisible(true)
			AtlasLabel_successs:setString("/"..data[i].point)
		else
			AtlasLabel_fail:setVisible(true)
			AtlasLabel_fail:setString("/"..math.abs(data[i].point))
		end
        ListView:pushBackCustomItem(item)
	end	
	
end


return GameOverLayer


--endregion
