--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_download = import("....common.download")

local GamePlayerLayer = class("GamePlayerLayer")

local TAG_PLAYER={}
TAG_PLAYER.Tag_zhang = 101;---庄
function GamePlayerLayer:ctor(parent,rootNode)
    self.parent = parent

    self.playerRootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self:onPlayerSitShow(true)
	self.selectPlayer={};
	self:init();
end
--重置所有座位号
function GamePlayerLayer:resetUserPlayer()
	for i = 1,self.playerCount do
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..i)
		if Panel_itemPlayer ~= nil then
			Panel_itemPlayer:setVisible(false)
			--更改默认的坐下按钮
			local Image_player = seekNodeByName(Panel_itemPlayer,"Image_player")
			Image_player:loadTexture("gameres/b10.png")
			Image_player:setVisible(false)
			
			--隐藏姓名层
			local player_info_bg = seekNodeByName(Panel_itemPlayer,"player_info_bg")
			player_info_bg:setVisible(false)
			--隐藏开辟状态
			local Image_kaiPi = seekNodeByName(Panel_itemPlayer,"Image_kaiPi")
			Image_kaiPi:setVisible(false)
			Panel_itemPlayer:addClickEventListener(function()
				
			end)
		end
	end
end
--显示左右坐下玩家
function GamePlayerLayer:showUserSitdownPlayer()
	local playerDeskMap = self.parent:getSitDownPlayerMap()
	for k,v in pairs(playerDeskMap) do
		self:showOneUser(v)
	end
end
function GamePlayerLayer:showOneUser(userinfo)
	local user_chair = self.parent:getHelper():DeskStation2View(userinfo.bDeskStation)--userinfo.bDeskStation
	if user_chair >0 and user_chair<=self.playerCount then
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(user_chair))
		if Panel_itemPlayer ~= nil then
			Panel_itemPlayer:setVisible(true);
			local Image_player = seekNodeByName(Panel_itemPlayer,"Image_player")
			Image_player:loadTexture("platform_res/common/boy0.png")
			Image_player:setVisible(true)
			--local Image_gameReady = seekNodeByName(Panel_itemPlayer,"Image_gameReady")
			--Image_gameReady:setVisible(self.parent:getUserIsReady(userinfo.dwUserID))
			m_download:get_instance():set_head_image_and_auto_update( Image_player , userinfo.avatarUrl , userinfo.dwUserID)
			local player_info_bg = seekNodeByName(Panel_itemPlayer,"player_info_bg");
			player_info_bg:setVisible(true)
			local userNickname = seekNodeByName(player_info_bg,"text_name")
			local text_money_num = seekNodeByName(player_info_bg,"text_money_num")
			userNickname:setString(api_get_ascll_sub_str_by_ui(userinfo.nickName,9))
			local money = userinfo.dwProfit
			if self.parent:isQzProject() == false then
				money = userinfo.dwMoney
				--dump(userinfo,"userinfo:")
			end
			print("money:"..money)
			text_money_num:setString(money)
			Panel_itemPlayer:addClickEventListener(function()
				--if self.parent:getGameStation() == 19 then
					print("------Panel_itemPlayer-----self.selectPlayer:"..(userinfo.bDeskStation))
					table.insert(self.selectPlayer,userinfo.bDeskStation)
					if #self.selectPlayer==2 and self.selectPlayerCallBack ~= nil then
						self.selectPlayerCallBack(self.selectPlayer)
					end
				--end
			end)
		end
	end
end
function GamePlayerLayer:showUserSit()
	self:resetUserPlayer()
	
	--[[local selfIsSit = self.parent:isAlreadySitdown()
	if selfIsSit == false then
		self:showKongSit()
	end
	--]]
	self:showUserSitdownPlayer()
end
function GamePlayerLayer:showKongSit()
	for i = 1,self.playerCount do
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..i)
		if Panel_itemPlayer ~= nil then
			Panel_itemPlayer:setVisible(true)
			--更改默认的坐下按钮
			local Image_player = seekNodeByName(Panel_itemPlayer,"Image_player")
			Image_player:loadTexture("gameres/b10.png")
			Image_player:setVisible(true)
			Panel_itemPlayer:addClickEventListener(function()
				print("Panel_itemPlayer...i:::"..i)
			end)
			Image_player:addClickEventListener(function()
				print("Image_player:"..i)
				--检查当前是否已经有人做了，如果没有人坐下，发送坐下消息
				self.parent:reqSitdownDesk(i-1,true)
			end)
			--隐藏准备按钮
			--local Image_gameReady = seekNodeByName(Panel_itemPlayer,"Image_gameReady")
			--Image_gameReady:setVisible(false)
			--隐藏姓名层
			local player_info_bg = seekNodeByName(Panel_itemPlayer,"player_info_bg")
			player_info_bg:setVisible(false)
			--隐藏开辟状态
			local Image_kaiPi = seekNodeByName(Panel_itemPlayer,"Image_kaiPi")
			Image_kaiPi:setVisible(false)
		end
	end
end
function GamePlayerLayer:init()
	for i = 1,self.playerCount do
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..i)
		if Panel_itemPlayer ~= nil then
			
			local Image_kaiPi = seekNodeByName(Panel_itemPlayer,"Image_kaiPi")
			Image_kaiPi:setVisible(false)
		end
	end
	local zhuangSprite = self.playerRootNode:getChildByTag(TAG_PLAYER.Tag_zhang)
	if zhuangSprite ~= nil then
		zhuangSprite:removeFromParent()
	end
end
--准备状态，刷新用户分数
function GamePlayerLayer:gameReady(resp_json)
	
end
function GamePlayerLayer:selectPlayerCallBack(callback)
	self.selectPlayer = nil;
	self.selectPlayer={}
	self.selectPlayerCallBack = callback;
end
--隐藏所有灯光
function GamePlayerLayer:hideDengguang()
	for i = 1,6 do
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(i))
		--local Image_dengguang = seekNodeByName(Panel_itemPlayer,"Image_dengguang")
		--Image_dengguang:setVisible(false)
	end
end
--开和劈的状态标示
function GamePlayerLayer:showAnimal(animalPath,node)
	node:removeAllChildren();
	local loadinganimlNode = cc.CSLoader:createNode(animalPath)
	local loadinganimlaction = cc.CSLoader:createTimeline(animalPath)

	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,true)
	loadinganimlNode:setPosition(24,24)
	node:addChild(loadinganimlNode)
end
--用户坐下
function GamePlayerLayer:onPlayerSit(userinfo)
	dump(userinfo,6)
	print("显示用户头像")
	
end
--收到用户返回或者劈后开的消息
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_beilv" = 0
            "beikai_chair" = 2
        }
        2 = {
            "beikai_beilv" = 4
            "beikai_chair" = 1
        }
    }
    "piUser"    = 0
	"piType"   =1
	"actionUser"=1
}]]
function GamePlayerLayer:response_Pi_kai(resp_json)
	if resp_json.piType ~= nil and resp_json.piType>0 and resp_json.piUser ~= nil and resp_json.piUser>=0 then
		
		local user_chair = self.parent:getHelper():DeskStation2View(resp_json.actionUser)--userinfo.bDeskStation
		if user_chair >0 and user_chair<=self.playerCount then
			local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(user_chair))
			local path=string.format("gameres/csb/%s.csb","actionResp_fanpi")
			if resp_json.piType == 1 then
				path=string.format("gameres/csb/%s.csb","actionResp_kai")
			end
			local loadinganimlNode = cc.CSLoader:createNode(path)
			local loadinganimlaction = cc.CSLoader:createTimeline(path)

			loadinganimlNode:runAction(loadinganimlaction)
			loadinganimlaction:gotoFrameAndPlay(0,false)
			print("Panel_itemPlayer:getPositionX():"..Panel_itemPlayer:getPositionX())
			local PanelSize = Panel_itemPlayer:getSize();
			loadinganimlNode:setPosition(Panel_itemPlayer:getPositionX()+PanelSize.width/2,Panel_itemPlayer:getPositionY()+PanelSize.height/2)
			self.playerRootNode:addChild(loadinganimlNode)
			loadinganimlaction:setLastFrameCallFunc(function()
				loadinganimlNode:removeFromParent()
				
			end)
		end
	end
end
--当用户站起的时候
function GamePlayerLayer:onPlayerStandUp(user_info , desk_info , code)
	
end
--恢复场景，要显示当前用户有没有准备--
--[["bAgree" = {
    1 = {
        "bAgree" = false
        "chair"  = 0
    }
}]]
function GamePlayerLayer:game_rebind(resp_json)
	--[[if resp_json ~= nil and resp_json.bAgree ~= nil and #resp_json.bAgree>0 then
		for i = 1,#resp_json.bAgree do
			local chair = resp_json.bAgree[i].chair;
			local bAgree = resp_json.bAgree[i].bAgree;
			local user_chair = self.parent:getHelper():DeskStation2View(chair)
			if user_chair >=0 and user_chair<=self.playerCount then
				local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(user_chair))
				if Panel_itemPlayer ~= nil then
					Panel_itemPlayer:setVisible(true);
					--local Image_gameReady = seekNodeByName(Panel_itemPlayer,"Image_gameReady")
					--Image_gameReady:setVisible(bAgree)
				end
			end
		end
	end
	--]]
end
function GamePlayerLayer:ready(resp_json)
	--self:init()
	self:game_start(resp_json)
end

function GamePlayerLayer:onPlayerSitShow(isShowFreePosition)
	for i = 1,self.playerCount do
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..i)
		if Panel_itemPlayer ~= nil then
			Panel_itemPlayer:setVisible(isShowFreePosition)
			local player_info_bg = seekNodeByName(Panel_itemPlayer,"player_info_bg");
			--local Image_fenbg = seekNodeByName(Panel_itemPlayer,"Image_fenbg")
			local Image_player = seekNodeByName(Panel_itemPlayer,"Image_player")
			
			
			--[[if i == 1 then
				Image_player:setVisible(not isShowFreePosition)
				playerItem:setVisible(not isShowFreePosition)
				player_info_bg:setVisible(not isShowFreePosition)
			else
				--]]
				Image_player:setVisible(isShowFreePosition)
				player_info_bg:setVisible(isShowFreePosition)
			--end
			
			--Image_fenbg:setVisible(false)
		end
	end
end

function GamePlayerLayer:HeadWaitTime(playerbg,iThinkTime,iTotalTime)
	local actionTo = CCProgressFromTo:create(iThinkTime, (1-iThinkTime/iTotalTime)*100,100)
	local progress = CCProgressTimer:create(CCSprite:create(''))--gameres/b05.png
	progress:setType( kCCProgressTimerTypeRadial )
	progress:setAnchorPoint(0,0)
	progress:runAction(actionTo)
	playerbg:addChild(progress)
end


function GamePlayerLayer:game_start(resp_table)
	self:hideDengguang()
	for i = 1,self.playerCount do
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(i))
		Panel_itemPlayer:setVisible(false)
	end
	print("--------GamePlayerLayer:game_start")
	if resp_table ~= nil  then
		local playerData = resp_table.playerData
		if playerData ~= nil then
			for i = 1,#playerData do
				local user_chair = self.parent:getHelper():DeskStation2View(playerData[i].chair)
				local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(user_chair))
				print("playerData[i].chair:"..playerData[i].chair)
				local userinfo = self.parent:getPlayerInfoByChairID(playerData[i].chair)
				if Panel_itemPlayer ~= nil then
					Panel_itemPlayer:setVisible(true)
					local playerItem = seekNodeByName(Panel_itemPlayer,"Image_player")
					playerItem:setVisible(true)
					playerItem:loadTexture("platform_res/common/boy0.png")
					if userinfo ~= nil then
						m_download:get_instance():set_head_image_and_auto_update( playerItem , userinfo.avatarUrl , userinfo.dwUserID)
					end
					local player_info_bg = seekNodeByName(Panel_itemPlayer,"player_info_bg");
					player_info_bg:setVisible(true)
					local userNickname = seekNodeByName(Panel_itemPlayer,"text_name")
					userNickname:setString(api_get_ascll_sub_str_by_ui(userinfo.nickName,9))
					local text_money_num = seekNodeByName(Panel_itemPlayer,"text_money_num")
					local money = playerData[i].point
					if self.parent:isQzProject() == false and userinfo ~= nil then
						money = userinfo.dwMoney
					end
					text_money_num:setString(money)
					text_money_num:setVisible(true)
					
				end
			end
		else
			printError("没有发现用户")
		end
		--生成庄动画
		if resp_table.NtStation ~= nil then
			print("===============================start zhuang donghua :"..resp_table.NtStation)
			local zhuangChair = resp_table.NtStation
			local zhuang_chair = self.parent:getHelper():DeskStation2View(zhuangChair)
			local playerItem = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(zhuang_chair))
			local sprite = cc.Sprite:create("gameres/game_banker.png")
			sprite:setPosition(640,360);
			sprite:setTag(TAG_PLAYER.Tag_zhang)
		end
	end
end
--叫分时，当前层的操作
--[[{"jiaofenStation":1,"m_TouziJiaofenTime":15,"userFenData":[{"chair":0,
"jiaofenDian":4,"jiaofenNum":3},{"chair":1,"jiaofenDian":0,"jiaofenNum":0}]}]]
function GamePlayerLayer:start_jiaofen(resp_table)

end
--排队场用户金币变化
function GamePlayerLayer:user_score_change(code,score_info)
	dump(score_info,"score_info:")
	local userinfo =self.parent:getPlayerInfoByUserID(score_info.dwUserID)
	dump(userinfo,"userinfo:")
	local user_chair = self.parent:getHelper():DeskStation2View(userinfo.bDeskStation)
	local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(user_chair))
	--local userinfo = self.parent:getPlayerInfoByChairID(playerData[i].chair)
	if Panel_itemPlayer ~= nil then
		local text_money_num = seekNodeByName(Panel_itemPlayer,"text_money_num")
		local money = userinfo.dwMoney
		text_money_num:setString(money)
	end
end
----收到用户开的消息
--[[ ---------------------------------------- recv json : 18
0_95,data:{"beiKaiUser":[{"beikai_beilv":1,"beikai_chair":1}],"kaiUser":0}]]
function GamePlayerLayer:response_userSelectKai(resp_table)
	self:hideDengguang()
	--显示当前玩家叫劈的状态
	if resp_table ~= nil and resp_table.kaiUser ~= nil then
		local user_chair = self.parent:getHelper():DeskStation2View(resp_table.kaiUser)
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..user_chair)
		if Panel_itemPlayer ~= nil then			
			local Image_kaiPi = seekNodeByName(Panel_itemPlayer,"Image_kaiPi")
			Image_kaiPi:setVisible(true)
			self:showAnimal("gameres/action/kailogo.csb",Image_kaiPi)
		end
	end
end
--收到用户劈的消息
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_chair" = 0
        }
    }
    "m_TouziJiaofenTime" = 15
    "piUser"             = 1
}]]
function GamePlayerLayer:response_receive_pi(resp_table)
	self:hideDengguang()
	--显示当前玩家叫劈的状态
	if resp_table ~= nil and resp_table.piUser ~= nil then
		local user_chair = self.parent:getHelper():DeskStation2View(resp_table.piUser)
		local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..user_chair)
		if Panel_itemPlayer ~= nil then			
			local Image_kaiPi = seekNodeByName(Panel_itemPlayer,"Image_kaiPi")
			Image_kaiPi:setVisible(true)
			self:showAnimal("gameres/action/pilogo.csb",Image_kaiPi)
		end
	end
	if resp_table ~= nil and resp_table.beiPiUser ~= nil then
		for i = 1,#resp_table.beiPiUser do
			local user_chair = self.parent:getHelper():DeskStation2View(resp_table.beiPiUser[i].beikai_chair)
			local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..user_chair)
			if Panel_itemPlayer ~= nil then			
				--local Image_dengguang = seekNodeByName(Panel_itemPlayer,"Image_dengguang")
				--Image_dengguang:setVisible(true)			
			end
		end
	end	
end
--结算对当前界面层的影响
--[[{"kaiJson":{"kai_object":[{"beikai_station":0,"beikai_totalDian":6,"beikai_totalNum":6}],"kai_station":1},
	 "resultJson":[{"cards":[6,5,5,1,5],"chair":0,"scoreChange":2},{"cards":[3,5,5,6,2],"chair":1,"scoreChange":-2}]}]]
function GamePlayerLayer:start_KaiResult(resp_table)
	self:hideDengguang()
	--更改当前用户的分数
	if resp_table ~= nil and resp_table.resultJson ~= nil and #(resp_table.resultJson)>0 then
		local result_data = resp_table.resultJson	
		for i=1,#result_data do
			local user_chair = self.parent:getHelper():DeskStation2View(result_data[i].chair)
			if user_chair>0 then
				local userinfo = self.parent:getPlayerInfoByChairID(result_data[i].chair)
				local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..user_chair)
				if Panel_itemPlayer ~= nil then
					local playerItem = seekNodeByName(Panel_itemPlayer,"Image_player")
					local player_info_bg = seekNodeByName(Panel_itemPlayer,"player_info_bg");
					player_info_bg:setVisible(true)
					performWithDelay(self.playerRootNode,function()
						self:showSuccessNum(playerItem,result_data[i].scoreChange)
						performWithDelay(self.playerRootNode,function()
							local text_money_num = seekNodeByName(player_info_bg,"text_money_num")
							local money = result_data[i].score
							if self.parent:isQzProject() == false then
								money = userinfo.dwMoney;--"22222"
							end
							text_money_num:setString(money)
						end,2)
					end,(#result_data)*1.2+2)
				end
			end 
		end		
	end
end
--显示用户输赢分数
function GamePlayerLayer:showSuccessNum(playerItem,scoreChange)
	local pngPath = "gameres/num/03.png"
	if scoreChange>0 then
		pngPath = "gameres/num/02.png"
	end
	local scoreChangePoint = ccui.TextAtlas:create("/"..tostring(math.abs(scoreChange)),pngPath,26,42,"/")
	scoreChangePoint:setPosition(cc.p(50,50))
	scoreChangePoint:setAnchorPoint(0.5,0.5)
	playerItem:addChild(scoreChangePoint)
	local scale = cc.EaseBackIn:create(cc.MoveBy:create(2.0,cc.p(0,80)))--cc.MoveBy:create(2.0,cc.p(0,80))--
	local callfunc = cc.CallFunc:create(function ()
		scoreChangePoint:removeFromParent()
	end)
	local sequence = cc.Sequence:create(scale, callfunc)
	scoreChangePoint:runAction(sequence)
end
--断线重连
function GamePlayerLayer:onGameStation(resp_json)
	
	print("GamePlayerLayer  onGameStation")
	if resp_json.GameStation == self.parent:getGameStationEnum().gameUnStartStation or
		resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE then
		self:game_start(resp_json)
	else
		self:game_start(resp_json)
	end
	
end
return GamePlayerLayer


--endregion
