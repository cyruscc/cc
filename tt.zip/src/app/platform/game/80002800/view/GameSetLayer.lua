--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameSetLayer = class("GameSetLayer",function()
	return cc.CSLoader:createNode("gameres/set/setLayer.csb")
end)

function GameSetLayer:ctor(parent)
	self.parent = parent
    local Panel_bg = seekNodeByName(self,"Panel_1")
	Panel_bg:addClickEventListener(function()
		self:removeFromParent()
	end)
	
	local btn_close = seekNodeByName(self,"btn_close")
	btn_close:addClickEventListener(function()
		self:removeFromParent()
	end)
	local Image_music = seekNodeByName(self,"Image_music")
	local Image_voice = seekNodeByName(self,"Image_voice")
	Image_music:addClickEventListener(function()
		if UserData:getMusic() == 0 then
			UserData:setMusic(1)
			self.parent.music:setMusic(true)
		else
			UserData:setMusic(0)
			self.parent.music:setMusic(false)
		end
		
		self:updateSetButtonState()
	end)
	Image_voice:addClickEventListener(function()
		if UserData:getSound() == 0 then
			UserData:setSound(1)
			self.parent.music:setVoice(true)
		else
			UserData:setSound(0)
			self.parent.music:setVoice(false)
		end
		self:updateSetButtonState()
	end)
	local Image_laguage = seekNodeByName(self,"Image_laguage")
	Image_laguage:addClickEventListener(function()
		
		local language = UserData:getSetSwitch(3)
		print("Image_laguage,,,,language:"..language)
		if language == 0  then
			UserData:setSetSwitch(3,true)
			self.parent.music:setLanguage(false)
		else
			UserData:setSetSwitch(3,false)
			self.parent.music:setLanguage(true)
		end
		self:updateLaguage_ButtonState()
	end)
	self:updateLaguage_ButtonState()
	self:updateSetButtonState()
end
function GameSetLayer:updateSetButtonState()
	local Image_music = seekNodeByName(self,"Image_music")
	local Image_voice = seekNodeByName(self,"Image_voice")
	if UserData:getMusic() == 0 then
		Image_music:loadTexture("gameres/set/c03.png")
	else
		Image_music:loadTexture("gameres/set/c04.png")
	end
	if UserData:getSound() == 0 then
		Image_voice:loadTexture("gameres/set/c03.png")
	else
		Image_voice:loadTexture("gameres/set/c04.png")
	end
end
function GameSetLayer:updateLaguage_ButtonState()
	local Image_laguage = seekNodeByName(self,"Image_laguage")
	local language = UserData:getSetSwitch(3)
	print("Image_laguage,,,,language:"..language)
	if language == 0 then
		Image_laguage:loadTexture("gameres/set/c05.png")
	else
		Image_laguage:loadTexture("gameres/set/c06.png")
	end
end


return GameSetLayer


--endregion
