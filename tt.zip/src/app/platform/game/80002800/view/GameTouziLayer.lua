--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_download = import("....common.download")

local GameTouziLayer = class("GameTouziLayer")

function GameTouziLayer:ctor(parent,rootNode)
    self.parent = parent

    self.touziRootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	
	self:init()
end
function GameTouziLayer:init()
	for i = 1,self.playerCount do
		local player_touzi_item = seekNodeByName(self.touziRootNode,"Player_touzi_"..i)
		if player_touzi_item ~= nil then
			player_touzi_item:setVisible(false)
			local Image_hezi = seekNodeByName(player_touzi_item,"Image_hezi")
			Image_hezi:loadTexture("gameres/b16.png")
		end
	end
end
--执行cocosstudio中做的动画
function GameTouziLayer:showStartAnimal(animalName)
	local path = string.format("gameres/csb/%s.csb",animalName)
	
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)

	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,false)
	
	local player_touzi_item = seekNodeByName(self.touziRootNode,"Player_touzi_1")
	local Image_hezi = seekNodeByName(player_touzi_item,"Image_hezi")
	Image_hezi:setVisible(false)
	loadinganimlNode:setPosition(Image_hezi:getPositionX(),Image_hezi:getPositionY())
	player_touzi_item:addChild(loadinganimlNode)
	player_touzi_item:setVisible(true)
	for i = 1,5 do
		local touzhiItem = seekNodeByName(player_touzi_item,"touzhi_"..i)
		touzhiItem:setVisible(false)
	end
	loadinganimlaction:setLastFrameCallFunc(function()
		loadinganimlNode:removeFromParent()
		Image_hezi:setVisible(true)
	end)
end

function GameTouziLayer:onPlayerShouTouzi(userinfo)
	dump(userinfo,6)
	local user_chair = self.parent:getHelper():DeskStation2View(userinfo.bDeskStation)--userinfo.bDeskStation
	--print("------user_chair:"..user_chair)
	local muself_chair = self.parent:getHelper():DeskStation2View(self.parent:getSelfInfo().bDeskStation)
	if user_chair >=0 and user_chair<=self.playerCount then
		local touziItem = seekNodeByName(self.touziRootNode,"Player_touzi_"..(user_chair))
		if touziItem ~= nil then
			touziItem:setVisible(true)
			local Image_hezi = seekNodeByName(touziItem,"Image_hezi")
			Image_hezi:setVisible(true)
		end
	end
end

function GameTouziLayer:game_start(resp_json)
	if resp_table ~= nil then
		local playerData = resp_table.playerData
		for i = 1,#playerData do
			local user_chair = self.parent:getHelper():DeskStation2View(playerData.chair)
			local touziItem = seekNodeByName(self.touziRootNode,"Player_touzi_"..(user_chair))
			if touziItem ~= nil then
				touziItem:setVisible(true)
				local Image_hezi = seekNodeByName(touziItem,"Image_hezi")
				Image_hezi:setVisible(true)
				if muself_chair == user_chair then
					Image_hezi:loadTexture("gameres/b17.png")
				else
					Image_hezi:loadTexture("gameres/b16.png")
				end
			end
		end
	end
end
function GameTouziLayer:game_card_send(resp_table)
	if resp_table ~= nil then
		for key, var in pairs(resp_table) do
			if key>=0 then
				self:set_card_send(key, var)
			end
        end
		
	end
end
function GameTouziLayer:set_card_send(chair,touzhiNum)
	local user_chair = self.parent:getHelper():DeskStation2View(chair)
	print("---GameTouziLayer----user_chair:"..user_chair)
	local touziItem = seekNodeByName(self.touziRootNode,"Player_touzi_"..(user_chair))
	if touziItem ~= nil then
		touziItem:setVisible(true)
		for i=1,#touzhiNum do
			local touzhiItem = seekNodeByName(touziItem,"touzhi_"..i)
			local path = string.format("gameres/touzinum/shaizi%d.png",touzhiNum[i])
			print("path:"..path)
			touzhiItem:setVisible(true)
			touzhiItem:loadTexture(path)
			local Image_hezi = seekNodeByName(touziItem,"Image_hezi")
			Image_hezi:setVisible(true)
			if touzhiNum[i] >0 then
				Image_hezi:loadTexture("gameres/b17.png")
			else
				Image_hezi:loadTexture("gameres/b16.png")
			end
		end
	end
end

--结算对当前层影响
--[[ {"kaiJson":{"kai_object":[{"beikai_station":0,"beikai_totalDian":6,"beikai_totalNum":6}],"kai_station":1},
	 "resultJson":[{"cards":[6,5,5,1,5],"chair":0,"scoreChange":2},{"cards":[3,5,5,6,2],"chair":1,"scoreChange":-2}]}
--]]
function GameTouziLayer:start_KaiResult(resp_table)
	if resp_table ~= nil then
		for key,value in pairs(resp_table.resultJson) do
			local user_chair = self.parent:getHelper():DeskStation2View(value.chair)
			local touziItem = seekNodeByName(self.touziRootNode,"Player_touzi_"..(user_chair))
			if touziItem ~= nil then
				touziItem:setVisible(true)
				for i=1,#value.cards do
					local touzhiItem = seekNodeByName(touziItem,"touzhi_"..i)
					local path = string.format("gameres/touzinum/shaizi%d.png",value.cards[i])
					touzhiItem:loadTexture(path)
				end
				performWithDelay(self.touziRootNode,function ()
					local Image_hezi = seekNodeByName(touziItem,"Image_hezi")
					Image_hezi:setVisible(false)
					self:Image_heziAction(Image_hezi)
				end,(0.8+(key-1)*1.2))
				
			end
		end
	end
end

function GameTouziLayer:Image_heziAction(Image_hezi)
	local path = "gameres/csb/kai.csb"
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)
	--loadinganimlaction:setTimeSpeed(24.0/30)
	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlNode:setPosition(Image_hezi:getPositionX(),Image_hezi:getPositionY())
	Image_hezi:getParent():addChild(loadinganimlNode);
	loadinganimlaction:gotoFrameAndPlay(0,false)
end
--断线重连
function GameTouziLayer:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_YAOTOUZI then
		print("GameTouziLayer  摇骰子状态")
		
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_XUANZHAI 
		or resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_JIAOFEN
		or resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_PI then
		print("GameTouziLayer 选斋状态")
		if resp_json ~= nil and resp_json.userFenData ~= nil then
			for i = 1,#(resp_json.userFenData) do
				self:set_card_send(resp_json.userFenData[i].chair, resp_json.userFenData[i].cards)
			end
		end
	end
end
return GameTouziLayer


--endregion
