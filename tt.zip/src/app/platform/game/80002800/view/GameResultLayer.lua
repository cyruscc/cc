--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameResultLayer = class("GameResultLayer")

function GameResultLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	for i = 1,self.playerCount do
		local Player_resulttouzi = seekNodeByName(self.rootNode,"Player_resulttouzi_"..i)
		if Player_resulttouzi ~= nil then
			Player_resulttouzi:setVisible(false)
		end
	end
	self:init()
end
function GameResultLayer:init()
	--默认，此界面成，全部隐藏
	self.rootNode:setVisible(false)
	
end
--执行cocostudio中做的动画
function GameResultLayer:showResultAnimal(item,startIndex,endIndex)
	local csbFile = "gameres/csb/gameMainscene.csb"
	local buttonShowAnimal = cc.CSLoader:createTimeline(csbFile)
	item:runAction(buttonShowAnimal)
	buttonShowAnimal:gotoFrameAndPlay(startIndex,endIndex,false)
end

--[[{"kaiJson":{"kai_object":[{"beikai_station":0,"beikai_totalDian":6,"beikai_totalNum":6,"beikai_realDian":5}],"isZhai":false,"kai_station":1},
	 "resultJson":[{"cards":[6,5,5,1,5],"chair":0,"scoreChange":2},{"cards":[3,5,5,6,2],"chair":1,"scoreChange":-2}]}]]
--[[0_103,data:{"kaiJson":{"isZhai":false,"kai_object":[{"beikai_realDian":14,"beika
i_station":1,"beikai_totalDian":2,"beikai_totalNum":3}],"kai_station":0,"waittim
e":6},"resultJson":[{"cards":[1,1,1,1,1],"chair":0,"kaidian":[{"beikai_realDian"
:7}],"score":-1,"scoreChange":-1},{"cards":[1,1,1,1,1],"chair":1,"kaidian":[{"be
ikai_realDian":7}],"score":1,"scoreChange":1}]}]]
function GameResultLayer:start_KaiResult(resp_table)
	dump(resp_table.resultJson,"resp_table:")
	local Image_showresult_bg = seekNodeByName(self.rootNode,"Image_showresult_bg")
	if Image_showresult_bg ~= nil then
		self.rootNode:setVisible(true)
		local resultList = resp_table.resultJson
		local totalPlayer = #resultList
		local kaiNum = #(resp_table.kaiJson.kai_object);
		Image_showresult_bg:setVisible(false)
		performWithDelay(self.rootNode,function ()
			Image_showresult_bg:setVisible(true)
			self:showResultAnimal(Image_showresult_bg,0,75)
		end,2+totalPlayer*1.0)
		--结果界面中心的总数的显示
		for i =1,2 do
			local Image_dian = seekNodeByName(Image_showresult_bg,"Image_dian_"..i)
			local dianNum = seekNodeByName(Image_showresult_bg,"dian_num_"..i)
			if i>kaiNum then
				Image_dian:setVisible(false)
				dianNum:setVisible(false)
			else
				Image_dian:setVisible(true)
				dianNum:setVisible(true)
				local path = string.format("gameres/touzinum/0%d.png",resp_table.kaiJson.kai_object[i].beikai_totalDian)
				Image_dian:loadTexture(path)
				--local totalNum = self:checkTouziDian()
				local realDian = resp_table.kaiJson.kai_object[i].beikai_realDian;
				print("realDian:"..realDian)
				dianNum:setString(tostring(realDian))
				if kaiNum == 1 then
					Image_dian:setPositionX(Image_dian:getPositionX()+100)
					dianNum:setPositionX(dianNum:getPositionX()+100)
				end
			end
		end
		--当前在做的每个用户的身上的点数
		for i = 1,self.playerCount do
			local Player_resulttouzi = seekNodeByName(self.rootNode,"Player_resulttouzi_"..i)
			if Player_resulttouzi ~= nil then
				Player_resulttouzi:setVisible(false)
			end
		end
		for i = 1,totalPlayer do
			--获取当前客户端显示的座位号
			local user_chair = self.parent:getHelper():DeskStation2View(resultList[i].chair)
			local Player_resulttouzi = seekNodeByName(self.rootNode,"Player_resulttouzi_"..user_chair)
			if Player_resulttouzi ~= nil then
				for j =1,2 do	
					local Image_dian = seekNodeByName(Player_resulttouzi,"Image_dian_"..j)
					local dianNum = seekNodeByName(Player_resulttouzi,"dian_num_"..j)
					if j>kaiNum then
						Image_dian:setVisible(false)
						dianNum:setVisible(false)
					else
						--用户手上的牌
						local userCards = self:getUserCardsByChair(resp_table.resultJson,resultList[i].chair)
						--查询当前用户的某一个的骰子的个数
						local getDianNUm = self:checkTouziDian2(resp_table.resultJson,resultList[i].chair,j)
						--[[self:checkTouziDian(userCards,resp_table.kaiJson.kai_object[j].beikai_totalDian,
											resp_table.kaiJson.isZhai)	
											--]]
						Image_dian:setVisible(true)
						dianNum:setVisible(true)
						local path = string.format("gameres/touzinum/0%d.png",resp_table.kaiJson.kai_object[j].beikai_totalDian)
						Image_dian:loadTexture(path)
						if getDianNUm ~= nil then
							dianNum:setString(tostring(getDianNUm))
						end
					end
				end
				Player_resulttouzi:setVisible(false)
				performWithDelay(self.rootNode,function ()
					Player_resulttouzi:setVisible(true)
					self:showResultAnimal(Player_resulttouzi,0,75)
				end,2+(i-1)*1.0)
			end
		end
	end
	
end
function GameResultLayer:getUserCardsByChair(userCardsList,userChair)
	if #userCardsList <1 then
		return nil
	end
	for i = 1,#userCardsList do
		if userCardsList[i].chair == userChair then
			return userCardsList[i].cards;
		end
	end
	return nil;
end
function GameResultLayer:checkTouziDian2(userCardsList,userChair,index)
	if #userCardsList <1 then
		return nil
	end
	for i = 1,#userCardsList do
		if userCardsList[i].chair == userChair then
			return userCardsList[i].kaidian[index].beikai_realDian;
		end
	end
	return nil
end
function GameResultLayer:checkTouziDian(cardsDian,checkDian,isZhai)
	if cardsDian == nil or #cardsDian ~= self.parent:getUserTouziNum() then
		return 0
	end
	local index = 0;
	for k,v in pairs(cardsDian) do
		if (v == checkDian) or (not isZhai and v == 1) then
			index = index+1;
		end
	end
	return index;
end
--断线重连
function GameResultLayer:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_YAOTOUZI then
		print("GameResultLayer  摇骰子状态")
		self:init()
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_XUANZHAI then
		print("GameResultLayer 选斋状态")
		self:updateShowButton()
		self:init()
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_JIAOFEN then
		print("GameResultLayer 叫分状态")
		self:init()
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_PI then
		print("GameResultLayer pi状态")
		self:init()
	end
end

return GameResultLayer


--endregion
