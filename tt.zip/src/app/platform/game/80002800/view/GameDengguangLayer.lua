--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameDengguangLayer = class("GameDengguangLayer")

function GameDengguangLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.ImageDenggang={}
	self:init()
	
end

function GameDengguangLayer:init()
	--print("self.playerCount:"..self.playerCount)
	for i = 1,self.playerCount do
		local dengguang = seekNodeByName(self.rootNode,"Image_dengguang"..i)
		--print("i:"..i)
		dengguang:setVisible(false)
		table.insert(self.ImageDenggang,i,dengguang)
	end
end
--灭掉所有灯
function GameDengguangLayer:closeAll()
	for i = 1,self.playerCount do
		self.ImageDenggang[i]:setVisible(false)
	end
end
--选斋的时间
function GameDengguangLayer:game_selectZhai(resp_table)
	self.ImageDenggang[self.parent:getHelper():DeskStation2View(resp_table.m_TouziJiaoZhaiPosition)]:setVisible(true)
end
function GameDengguangLayer:User_selectZhai(resp_table)
	self:closeAll()
end
--叫分0_92,data:{"jiaofenStation":1,"lessAnNum":3,"lessDianNum":1,"m_TouziJiaofenTime"
--:15,"maxAnNum":10,"userFenData":[{"chair":0,"jiaofenDian":0,"jiaofenNum":0},{"ch
--air":1,"jiaofenDian":0,"jiaofenNum":0}]}
function GameDengguangLayer:start_jiaofen(resp_table)
	self:closeAll()
	self.ImageDenggang[self.parent:getViewPosition(resp_table.jiaofenStation)]:setVisible(true)
end
--收到劈的消息
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_chair" = 0
        }
    }
    "m_TouziJiaofenTime" = 15
    "piUser"             = 1
}]]
function GameDengguangLayer:response_receive_pi(resp_json)
	self:closeAll()
	if resp_json ~= nil and resp_json.beiPiUser ~= nil then
		for i = 1,#resp_json.beiPiUser do
			--显示被劈用户的灯光
			self.ImageDenggang[self.parent:getViewPosition(resp_json.beiPiUser[i].beikai_chair)]:setVisible(true)
		end
	end
end
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_beilv" = 0
            "beikai_chair" = 2
			"beikai_isAction"=0//是否已经操作
        }
        2 = {
            "beikai_beilv" = 4
            "beikai_chair" = 1
			"beikai_isAction"=1//是否已经操作
        }
    }
    "piUser"    = 0
}]]
function GameDengguangLayer:response_Pi_kai(resp_json)
	--self:closeAll()
	if resp_json ~= nil and resp_json.beiPiUser ~= nil and #resp_json.beiPiUser>0 then
		
		for i = 1,#resp_json.beiPiUser do
			if resp_json.beiPiUser[i].beikai_beilv >0 and resp_json.beiPiUser[i].beikai_isAction>0 then
				--如果已经选择了，进行隐藏进度条
				self.ImageDenggang[self.parent:getViewPosition(resp_json.beiPiUser[i].beikai_chair)]:setVisible(false)
			end
		end
	end
end
function GameDengguangLayer:response_userSelectKai(resp_table)
	self:closeAll()
end
return GameDengguangLayer


--endregion
