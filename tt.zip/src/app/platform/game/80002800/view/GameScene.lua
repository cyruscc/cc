--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
cc.FileUtils:getInstance():addSearchPath(cc.FileUtils:getInstance():getWritablePath().."upd/res/game_res/80002800/")
cc.FileUtils:getInstance():addSearchPath(cc.FileUtils:getInstance():getWritablePath().."res/game_res/80002800/")
cc.FileUtils:getInstance():addSearchPath("upd/res/game_res/80002800/")
cc.FileUtils:getInstance():addSearchPath("res/game_res/80002800/")
local gameHelper=import("..gameHelper")
local GameBaseLayer = import(".GameBaseLayer")
local GameBaseButton = import(".GameBaseButton")
local GamePlayerLayer = import(".GamePlayerLayer")
local GameTouziLayer = import(".GameTouziLayer")
local GameResultLayer = import(".GameResultLayer")
local TimerUIManager = import(".TimerUIManager")
local GameFenLayer = import(".GameFenLayer")
local GameDengguangLayer = import(".GameDengguangLayer")
local GameOverLayer = import(".GameOverLayer")
local GameReadyLayer = import(".GameReadyLayer")
local GameMusic = import(".GameMusic")
local GameSceneBase = import("...GameSceneBase")
local GameSceneModule = import("..GameSceneModule")

local m_download = import("....common.download")

local TouziGameStationEnum={
	gameUnStartStation=0,--游戏未开始状态
	GS_WAIT_ARGEE = 1,---等待开始状态
	gameResultStation=19,
	DH_WAIT_YAOTOUZI=32,				--摇骰子状态
	DH_WAIT_XUANZHAI=33,--选斋状态
	DH_WAIT_JIAOFEN =34,--				//叫分状态
	DH_WAIT_PI=35,--劈的状态
	DH_WAIT_KAI=36,	--结算状态
}
local gameType = {
	gameType_qz1="qz1",
	gameType_tz1="tz1",
}
local GameScene = class("GameScene" , GameSceneBase)
function GameScene:ctor()
	self:onCreate()
end
function GameScene:onCreate()
	
    self.touziGameStation = 0
	--当前每个人使用的骰子个数
	self.userTouziNum = 5;
    self:registered_child(self)
	self.desk_index = 0;
	--保存我自己的座位号，默认为0
	self.myselfPosition = 0;
    GameSceneModule:getInstance():init(self)
	self.music = GameMusic.new(self)
	local mainscenePaht = "gameres/csb/gameMainscene.csb"
	local mainsceneNode = cc.CSLoader:createNode(mainscenePaht)
	self.rootNode = mainsceneNode
	self:addChild(mainsceneNode)
	self.gameBaseLayer = GameBaseLayer.new(self,seekNodeByName(mainsceneNode,"Panel_base"))
	self.gameBaseButton = GameBaseButton.new(self,seekNodeByName(mainsceneNode,"Panel_button"))
	self.gamePlayerLayer = GamePlayerLayer.new(self,seekNodeByName(mainsceneNode,"Panel_player"))
	self.gameTouziLayer = GameTouziLayer.new(self,seekNodeByName(mainsceneNode,"Panel_touziLayer"))
	self.gameResultLayer = GameResultLayer.new(self,seekNodeByName(mainsceneNode,"Panel_result"))
	self.gameTimeLayer = TimerUIManager.new(self,seekNodeByName(mainsceneNode,"Panel_Time"))
	self.gameReadyLayer = GameReadyLayer.new(self,seekNodeByName(mainsceneNode,"Panel_Ready"))
	self.gameMengban = seekNodeByName(mainsceneNode,"Panel_mengban")
	self.gameDengguangLayer = GameDengguangLayer.new(self,seekNodeByName(mainsceneNode,"Panel_dengang"))
	self.gameJiaofenLayer = GameFenLayer.new(self,seekNodeByName(mainsceneNode,"Panel_jiaofen"))
	self.gameMengban:setVisible(false);
	
	--摇动蒙版
	self.Panel_yao = seekNodeByName(mainsceneNode,"Panel_yao")
	self.Panel_yao:setVisible(false)
	
    self:registerScriptHandler(handler(self,self.onNodeEvent))
	
	self.userList={}
	--pos_list , scale , max_count , zorder )
	local pos_list={
		cc.p(639,206),
		cc.p(1160,385),
		cc.p(1045,596),
		cc.p(536,638),
		cc.p(241,596),
		cc.p(126,374)}
	
	self:initExpression(pos_list,1.0,15)
	--pos_list ,direction_list , quick_text_list , max_width , scale  , zorder)
	local pos_list2={
		cc.p(707,234),
		cc.p(1091,366),
		cc.p(976,584),
		cc.p(611,624),
		cc.p(311,570),
		cc.p(200,364)}
	local direction_list = {4,2,2,4,4,4}
	local list = {"你太牛了。",
				"快点叫啊。",
				"这个叫的好",
				"不好意思,我有事要先走一步了",
				"不好意思,我接个电话稍等一下",
				"怎么又断线了,网络怎么这么差啦",
	}
	self:initChatText(pos_list2,direction_list,list,200)
	
	self.isSendSitUp = false
	--是否是首轮
	self.isFirstGame = false;
end
function GameScene:getGameStationEnum()
	return TouziGameStationEnum;
end
function GameScene:getGameTouziLayer()
	return self.gameTouziLayer
end
function GameScene:getUserTouziNum()
	return self.userTouziNum;
end
function GameScene:getGameStation()
	return self.touziGameStation;
end
function GameScene:getGameTypeEnum()
	return gameType;
end
function GameScene:isQzProject()
	return self:getGameType() == gameType.gameType_qz1;
end
function GameScene:getIsFirstGame()
	return self.isFirstGame;
end
--给player层级增加头像点击监听回调
function GameScene:setPlayerClickCallBack(callback)
	self.gamePlayerLayer:selectPlayerCallBack(callback)
end
function GameScene:setDeskPlayerHeadImage()
    for key, var in pairs(self.super:getSitDownPlayerMap()) do
        self.GameLayer.MenuManager:setPlayerHeadImage(var)  
    end
end
function GameScene:getViewPosition(bdestStation)
	return self:getHelper():DeskStation2View(tonumber(bdestStation))
end
function GameScene:gameProformDelay(time,callback)
	performWithDelay(self.rootNode,function ()
			if callback ~= nil then
				callback()
			end
		end,time)
end

function GameScene:onNodeEvent(event)

    if event == "enter" then
             --返回键开启
       --g_setMainLayerDelegate(self)

    elseif event == "exit" then
		self.gameTimeLayer:stopTimer()
    end
end
--@param index 快速文字的下标
function GameScene:playQuickTextSound( text_index , user_info)
	self.music:playVoice(user_info.bBoy,"liao_"..text_index..".mp3")
end
function GameScene:check_ready()
	if self.deskActive == true then
		GameSceneModule:getInstance():request_player_ready()
	end
end
-------------------------------------------游戏消息---------------------------------------
--收到某一家准备消息
function GameScene:resp_player_ready(resp_table)
	self.gameBaseButton:resp_player_ready(resp_table)
	--self.gamePlayerLayer:resp_player_ready(resp_table)
	self:insertUserReady(self:getPlayerInfoByChairID(resp_table.chair).dwUserID)
	self.gameReadyLayer:updateUser()
end
function GameScene:resp_gameReady(resp_table)
	self.touziGameStation=TouziGameStationEnum.gameUnStartStation
	--更新用户积分
	if resp_table ~= nil and resp_table.playerData ~= nil and #(resp_table.playerData)>0 then
		for i = 1,#(resp_table.playerData) do
			local userinfo = self:getPlayerInfoByChairID(resp_table.playerData[i].chair)
			if userinfo ~= nil then
				userinfo.dwProfit = resp_table.playerData[i].point
			end
		end
	end
	self.gamePlayerLayer:init()
	--延时0.2秒执行，因为第一次有用户进来的时候，此通知比坐下通知还要早
	self:gameProformDelay(0.2,function ()
		if resp_table ~= nil then
			if resp_table.GameStation == self:getGameStationEnum().GS_WAIT_ARGEE then
				self.gameMengban:setVisible(false)
				
				self.gameBaseLayer:init()
				self.gameBaseButton:init()
				
				self.gameTouziLayer:init()
				self.gameResultLayer:init()
				self.gameDengguangLayer:closeAll()
				self.gameJiaofenLayer:closeAll()
				
				self.gameBaseButton:ready(resp_table)
				if resp_table.time ~= nil then
					self.gameTimeLayer:ready(resp_table)
				end
				--self.gamePlayerLayer:ready(resp_table)
				self.deskActive = true;
				if self:isAlreadySitdown() == false then
					self.gameBaseButton:updateShowButton("Panel_sitdown")
				end
			end
		end
	end)
end

--获取当前座位号是否已经准备
function GameScene:getUserIsReady(userid)
	for i=1,#self.userList do
		if self.userList[i] == userid then
			return true;
		end
	end
	return false;
end
function GameScene:insertUserReady(userid)
	if self.userList[userid] ~= nil then
		return;
	end
	table.insert(self.userList,userid)
end
function GameScene:deleteUserReady(userid)
	for i=1,#self.userList do
		if self.userList[i] == userid then
			table.remove(self.userList,self.userList[i])
			break;
		end
	end
	print("#self.userList:"..#self.userList)
end
function GameScene:deleteAllUserReady()
	self.userList= nil
	self.userList={}
end

    --入场场景恢复
function GameScene:game_rebind(resp_table)
	if resp_table.touziGameStation ~= nil then
		self.touziGameStation = resp_table.GameStation
	end
	if resp_table.GameStation == 1 or resp_table.GameStation == 0 then
        self.deskActive = true
    end
	--self:check_ready()
	self.gameBaseButton:game_rebind(resp_table)
	self.gamePlayerLayer:game_rebind(resp_table)
	self.gameJiaofenLayer:closeAll();
end
      --自动坐桌
function GameScene:autoSitDesk()
   
   local request = nil
    
    request = {}
    request.chair = 0
    request.auto = true
end
--游戏开始，显示一个摇动的动画，
function GameScene:game_start(resp_json)
	self.touziGameStation=TouziGameStationEnum.DH_WAIT_YAOTOUZI
	
	--开始的时候如果有搓桌界面，直接关掉
	api_hide_loading()
	--游戏开始--隐藏ready界面
	self.gameReadyLayer:closeAll()
	self.isFirstGame = false;
	--如果自己没有坐下，直接返回
	if self:isAlreadySitdown() == false then
		self.gameBaseButton:updateShowButton()
		self.gamePlayerLayer:game_start(resp_json)
		self.gameTimeLayer:ui_close()
		return;
	end
	self.gameBaseLayer:game_start(resp_json)
	self.gameBaseButton:updateShowButton()
	self.gameTimeLayer:stopTimer()
	--执行一个动画
	self:showAnimal("gameres/action/startAction.csb",function()
		self:showYaodongbg()
		--self.gameBaseButton:game_start(resp_json)
		--self.gameBaseButton:updateShowButton()
		self.gamePlayerLayer:game_start(resp_json)
		--self.gameTouziLayer:game_start(resp_json)
		--self.gameTimeLayer:gameRockTime(resp_json)
		self.music:playYaodongMusic()
		self:showAnimal("gameres/csb/shun.csb",function ()
				self:hidYaodong()
				GameSceneModule:getInstance():request_player_rockOver()
			end)
	end)
end
--超时没有摇动
function GameScene:outofTimeNoYaodong()
	--隐藏所有按钮
	self.gameBaseButton:updateShowButton();
	self:showAnimal("gameres/csb/shun.csb",function()
		self:hidYaodong()
		self.gameTimeLayer:stopTimer()
	end)
end
--显示摇动动画
function GameScene:showYaodongbg()
	self.Panel_yao:setVisible(true)
	if self.Panel_yao:getChildByTag(1001) ~= nil then
		self.Panel_yao:removeChildByTag(1001)
	end
	local path = "gameres/action/actionyaotip.csb"
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)
	loadinganimlNode:setTag(1001)
	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,true)
	loadinganimlNode:setPosition(WinSize.width/2,WinSize.height/2)
	self.Panel_yao:addChild(loadinganimlNode)
	loadinganimlaction:setLastFrameCallFunc(function()
	end)
end
--隐藏摇动提示
function GameScene:hidYaodong()
	self.Panel_yao:setVisible(false)
	if self.Panel_yao:getChildByTag(1001) ~= nil then
		self.Panel_yao:removeChildByTag(1001)
	end
	if self:isAlreadySitdown() == true then
		self.gameTouziLayer:onPlayerShouTouzi(self:getSelfInfo())
	end
end
--执行cocosstudio中做的动画
function GameScene:showAnimal(path,callback)
	--local path = string.format("gameres/csb/%s.csb",animalName)
	if self.Panel_yao:getChildByTag(1001) ~= nil then
		self.Panel_yao:removeChildByTag(1001)
	end
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)

	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,false)
	loadinganimlNode:setPosition(WinSize.width/2,WinSize.height/2)
	self.rootNode:addChild(loadinganimlNode)
	loadinganimlaction:setLastFrameCallFunc(function()
		loadinganimlNode:removeFromParent()
		if callback ~= nil then
			callback()
		end
	end)
end
--服务器下发骰子
function GameScene:game_card_send(resp_table)
	self:hidYaodong()
	self.gameBaseButton:game_card_send(resp_json)
	self.gameTouziLayer:game_card_send(resp_table)
end
--服务器通知客户端，是否选择斋
function GameScene:game_selectZhai(resp_table)
		print("开始选斋")
		self.gameBaseButton:selctZhai(resp_table)
		if resp_table.m_TouziJiaoZhaiTime ~= nil and resp_table.m_TouziJiaoZhaiTime>0 then
			--self.gameTimeLayer:startTimer(resp_table.m_TouziJiaoZhaiTime)
			self.gameTimeLayer:game_selectZhai(resp_table)
		end
		self.gameDengguangLayer:game_selectZhai(resp_table)
	--end)
end
function GameScene:User_selectZhai(resp_table)
	print("选斋结束")
	if resp_table ~= nil and resp_table.chair ~= nil and resp_table.chair>=0 and resp_table.zhai == true then
		local userinfo = self:getPlayerInfoByChairID(resp_table.chair)
		self.music:playVoice(userinfo.bBoy,"zhai.mp3")
	end
	--self.gameTimeLayer:stopTimer()
	self.gameBaseButton:selctZhaiResult(resp_table)
	self.gameTimeLayer:User_selectZhai(resp_table)
	self.gameDengguangLayer:User_selectZhai(resp_table)
end
--开始叫分
function GameScene:start_jiaofen(resp_table)
	self.touziGameStation=TouziGameStationEnum.DH_WAIT_JIAOFEN
	--self.gameTimeLayer:stopTimer()
	self.gameBaseButton:start_jiaofen(resp_table)
	self.gamePlayerLayer:start_jiaofen(resp_table)
	self.gameTimeLayer:start_jiaofen(resp_table)
	if resp_table.m_TouziJiaofenTime ~= nil and resp_table.m_TouziJiaofenTime>0 then
		--self.gameTimeLayer:startTimer(resp_table.m_TouziJiaofenTime)
	end
	self.gameDengguangLayer:start_jiaofen(resp_table)
	self.gameJiaofenLayer:start_jiaofen(resp_table)
end

function GameScene:setMengbanVisible(isShow)
	self.gameMengban:setVisible(isShow);
end
--玩家叫了多少分
function GameScene:response_jiaofen_resp(resp_table)
	local jiaofenNum = resp_table.jiaofenNum
	local chair = resp_table.chair
	local jiaofenDian = resp_table.jiaofenDian
	local changeZhai = false;
	local userinfo = self:getPlayerInfoByChairID(chair)
	if resp_table.changeZhai ~= nil then
		changeZhai = resp_table.changeZhai
	end
	if changeZhai == true then
		self.gameBaseButton:changeZhaiResult(changeZhai)
		self.music:playVoice(userinfo.bBoy,"zhai.mp3")
	end
	
	if resp_table.isAdd1 == true then
		if changeZhai == true then
			performWithDelay(self.rootNode,function()
				self.music:playVoice(userinfo.bBoy,"add1.mp3")
			end,0.5)
		else
			self.music:playVoice(userinfo.bBoy,"add1.mp3")
		end
		return;
	end
	if changeZhai == true then
		performWithDelay(self.rootNode,function()
			self.music:playVoice(userinfo.bBoy,jiaofenNum.."_ge.mp3")
			performWithDelay(self.rootNode,function()
				self.music:playVoice(userinfo.bBoy,"dian"..jiaofenDian..".mp3")
			end,0.5)
		end,0.5)
	else
		self.music:playVoice(userinfo.bBoy,jiaofenNum.."_ge.mp3")
		performWithDelay(self.rootNode,function()
			self.music:playVoice(userinfo.bBoy,"dian"..jiaofenDian..".mp3")
		end,0.5)
	end
	
end
--收到用户劈的消息
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_chair" = 0
        }
    }
    "m_TouziJiaofenTime" = 15
	"isUserQiangpi"      = true true代表当前是抢劈
    "piUser"             = 1
}]]
function GameScene:response_receive_pi(resp_json)
	local piUser = resp_json.piUser
	local path = string.format("gameres/csb/%s.csb","actionPi")
	
	self.music:playShandianMusic();
	local userinfo = self:getPlayerInfoByChairID(piUser)
	if resp_json.isUserQiangpi ~= nil and resp_json.isUserQiangpi == true then
		self.music:playVoice(userinfo.bBoy,"qiangpi.mp3")
		path = string.format("gameres/csb/%s.csb","actionQiangPi")
		self:action_Kaipi(path,piUser,resp_json.beiPiUser[1].beikai_chair)
	else
		if #resp_json.beiPiUser>1 then
			self.music:playVoice(userinfo.bBoy,"pi2.mp3")
			local user1 = resp_json.beiPiUser[1].beikai_chair
			local user2 = resp_json.beiPiUser[2].beikai_chair
			self:action_Kaipi(path,piUser,user1,user2)
		else
			self.music:playVoice(userinfo.bBoy,"pi.mp3")
			self:action_Kaipi(path,piUser,resp_json.beiPiUser[1].beikai_chair)
		end
	end
	
	
	self.gameBaseButton:response_receive_pi(resp_json)
	self.gamePlayerLayer:response_receive_pi(resp_json)
	self.gameTimeLayer:response_receive_pi(resp_json)
	self.gameDengguangLayer:response_receive_pi(resp_table)
end
--收到用户被劈后的回应
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_beilv" = 0
            "beikai_chair" = 2
        }
        2 = {
            "beikai_beilv" = 4
            "beikai_chair" = 1
        }
    }
    "piUser"    = 0
	"actionUser"=1
}]]
function GameScene:response_Pi_kai(resp_json)
	
	if resp_json.actionUser ~= nil and resp_json.actionUser>=0 then
		
		local userinfo = self:getPlayerInfoByChairID(resp_json.actionUser)
		local musicName = "fanpi.mp3"
		if resp_json.piType == 1 then
			musicName="kai.mp3"
		end
		self.music:playVoice(userinfo.bBoy,musicName)
	end
		
	
	--需要在piUser用户头上，执行一个动画
	self.gamePlayerLayer:response_Pi_kai(resp_json)
	
	self.gameBaseButton:response_Pi_kai(resp_json)
	--self.gamePlayerLayer:response_Pi_kai(resp_json)
	self.gameTimeLayer:response_Pi_kai(resp_json)
	self.gameDengguangLayer:response_Pi_kai(resp_table)
end
--收到用户开的消息
--[[ ---------------------------------------- recv json : 18
0_95,data:{"beiKaiUser":[{"beikai_beilv":1,"beikai_chair":1}],"kaiUser":0}]]
function GameScene:response_userSelectKai(resp_json)
	self.gamePlayerLayer:response_userSelectKai(resp_json)
	self.gameTimeLayer:response_userSelectKai(resp_json)
	self.gameDengguangLayer:response_userSelectKai(resp_table)
	
	print("收到用户开的消息")
	local kaiUser = resp_json.kaiUser
	--执行开动画
	--self:showAnimal("actionKai")
	local path = string.format("gameres/csb/%s.csb","actionKai")
	local userinfo = self:getPlayerInfoByChairID(kaiUser)
	
	if #resp_json.beiKaiUser>1 then
		self.music:playVoice(userinfo.bBoy,"kai2.mp3")
		self:action_Kaipi(path,kaiUser,resp_json.beiKaiUser[1].beikai_chair,resp_json.beiKaiUser[2].beikai_chair)
	else
		self.music:playVoice(userinfo.bBoy,"kai.mp3")
		self:action_Kaipi(path,kaiUser,resp_json.beiKaiUser[1].beikai_chair)
	end
end
function GameScene:action_Kaipi(path,kaiUserchair,beikaiUserchair1,beikaiUserchair2)
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)

	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,false)
	loadinganimlNode:setPosition(WinSize.width/2,WinSize.height/2)
	self.rootNode:addChild(loadinganimlNode)
	loadinganimlaction:setLastFrameCallFunc(function()
		loadinganimlNode:removeFromParent()
	end)
	--替换里面的头像
	local user1 = seekNodeByName(seekNodeByName(loadinganimlNode,"Panel_1"),"Image_3")
	local user2 = seekNodeByName(seekNodeByName(loadinganimlNode,"Panel_2"),"Image_3")
	local user3 = seekNodeByName(seekNodeByName(loadinganimlNode,"Panel_3"),"Image_3")
	if beikaiUserchair1 ~= nil then
		local kaiUserinfo = self:getPlayerInfoByChairID(kaiUserchair)
		local beikai1 = self:getPlayerInfoByChairID(beikaiUserchair1)
		
		if beikaiUserchair2 == nil then
			seekNodeByName(loadinganimlNode,"Panel_3"):setVisible(false);
			m_download:get_instance():set_head_image_and_auto_update( user1 , kaiUserinfo.avatarUrl , kaiUserinfo.dwUserID)
			m_download:get_instance():set_head_image_and_auto_update( user2 , beikai1.avatarUrl , beikai1.dwUserID)
		else
			local beikai2 = self:getPlayerInfoByChairID(beikaiUserchair2)
			m_download:get_instance():set_head_image_and_auto_update( user1 , beikai1.avatarUrl , beikai1.dwUserID)
			m_download:get_instance():set_head_image_and_auto_update( user2 , beikai2.avatarUrl , beikai2.dwUserID)
			m_download:get_instance():set_head_image_and_auto_update( user3 , kaiUserinfo.avatarUrl , kaiUserinfo.dwUserID)
		end
	end
end
--开，结算，
function GameScene:start_KaiResult(resp_table)
	--self.gameTimeLayer:stopTimer()
	self.userList={};
	self:setMengbanVisible(true);
	self.gameBaseButton:start_KaiResult(resp_table)
	self.gamePlayerLayer:start_KaiResult(resp_table)
	self.gameTouziLayer:start_KaiResult(resp_table)
	self.gameResultLayer:start_KaiResult(resp_table)
	self.gameJiaofenLayer:start_KaiResult(resp_table)

end
--断线重连
--[["playerData" = {
    1 = {
        "bAgree" = true
        "chair"  = 0
        "point"  = -2
    }
    2 = {
        "bAgree" = false
        "chair"  = 1
        "point"  = 0
    }
}]]
function GameScene:onGameStation(resp_json)
	if resp_json ~= nil and resp_json.m_iIsFirstGame ~= nil then
		if resp_json.m_iIsFirstGame == true then
			self.isFirstGame = true;
		end
	end
	if resp_json.touziGameStation ~= nil then
		self.touziGameStation = resp_json.GameStation
	end
	--[[if resp_json.deskActive ~= nil and resp_json.deskActive == true then
        self.deskActive = true
    end
	--]]
	if resp_json.GameStation == 1 or resp_json.GameStation == 0 then
        self.deskActive = true
    end
	--更新用户的准备状态
	if resp_json.playerData ~= nil then
		self:deleteAllUserReady()
		for i = 1,#resp_json.playerData do
			if resp_json.playerData[i].bAgree == true then
				self:insertUserReady(self:getPlayerInfoByChairID(resp_json.playerData[i].chair).dwUserID)
			end
		end
	end
	self.gameBaseLayer:onGameStation(resp_json)
	self.gameBaseButton:onGameStation(resp_json)
	self.gamePlayerLayer:onGameStation(resp_json)
	self.gameTouziLayer:onGameStation(resp_json)
	self.gameResultLayer:onGameStation(resp_json)
	self.gameTimeLayer:onGameStation(resp_json)
	self.gameReadyLayer:onGameStation(resp_json);
	
	
	--self:check_ready()
	--self.gameBaseButton:game_rebind(resp_table)
	--self.gamePlayerLayer:game_rebind(resp_table)
	self.gameJiaofenLayer:closeAll();
end

--结算显示战绩
function GameScene:response_showOver(resp_json)
	self:addChild(GameOverLayer.new(self,resp_json))
end
-------------------------------------------平台消息---------------------------------------

--@desc  有玩家离开房间
-- @param code 1.您正在游戏中，不允许退出 2.您已经离开，不需要请求再次离开
function GameScene:playerLeaveRoom( user_info , code )
    print("GameScene:playerLeaveRoom code = " .. code)
    if code == 0 then
        print("玩家" .. user_info.dwUserID .. "离开房间")
    elseif code == 1 then
        api_show_Msg_Box("您正在游戏中，不允许退出")
    elseif code == 2 then
        api_show_Msg_Box("您已经离开，不需要请求再次离开")
    end

end

-- 有玩家离开桌子
--@desc  离开桌子
--@param code 1.正在游戏不准离开桌子 2.已经离开不需要再次离开
function GameScene:playerLeaveDesk( user_info , desk_info  , code )
    print("CGameScene:playerLeaveDesk------------code = " .. code)

    if code == 0 then
        --print("玩家" .. user_info.dwUserID .. "离开桌子")
        --self.GameLayer.MenuManager:onPlayerLeaveDesk( user_info , desk_info , code)
		api_show_tips(string.format("%s,离线",user_info.nickName))
    elseif code == 1 then
        api_show_Msg_Box("正在游戏不准离开桌子")
    elseif code == 2 then
        api_show_Msg_Box("已经离开不需要再次离开")
    end

end
--覆盖父类，不让有同ip提示
function GameScene:check_ip_same(desk_max_people)
end
-- 有玩家坐下
--@param code 1.位置上已有玩家 2.分数不足 3.座位不正确 4.玩家未进房间 5.不允许坐下
-- 6.房间已解散 7.被房主禁了 8.桌子索引不属于本房间 9.桌子已满人 10.玩家已经坐下 -1.其它原因
function GameScene:playerSitDesk( user_info , desk_info , code  )
    --auto
    print("GameScene:playerSitDesk-------------------------")
    if not user_info then
       print("user_info-------------------------error")
       return
    end
    if code == 0 then
        --如果是自己坐下就保存BasePosChair
        if self:isMyself(user_info) then
			self:deleteAllUserReady()
			api_hide_loading()
			self.isSendSitUp = false;
			print("------设置自己的椅子号 " .. user_info.bDeskStation)
			self.myselfPosition = tonumber(user_info.bDeskStation)
        end
		self.gamePlayerLayer:showUserSit()
		self.gameReadyLayer:updateUser()
		if self:isAlreadySitdown() == true and self:isMyself(user_info) then
			self.gameBaseButton:updateShowButton("Panel_start")			
			--self.gameBaseButton:updateShowButton("Panel_sitdown")
		else
			
		end
    elseif code == 1 then
        api_show_Msg_Box("位置上已有玩家")
    elseif code == 2 then
        api_show_Msg_Box("分数不足")
    elseif code == 3 then
        api_show_Msg_Box("座位不正确")
    elseif code == 4 then
        api_show_Msg_Box("玩家未进房间")
    elseif code == 5 then
        api_show_Msg_Box("不允许坐下")
    elseif code == 6 then
        api_show_Msg_Box("房间已解散")
    elseif code == 7 then
        api_show_Msg_Box("被房主禁了")
    elseif code == 8 then
        api_show_Msg_Box("桌子索引不属于本房间")
    elseif code == 9 then
        api_show_Msg_Box("桌子已满人")
    elseif code == 10 then
        api_show_Msg_Box("玩家已经坐下")
    end
--]]
end

function GameScene:user_need_repeat_queue()
	
end
--判断当前用户是否是房主
function GameScene:isMast()
	if self:isQzProject() == false then
		return false;
	end
	return self:getDeskInfo().mastUserID == self:getSelfInfo().dwUserID
end
--检查当前自己是否坐下
function GameScene:isAlreadySitdown()
	local myself = self:getSelfInfo();
	return myself.bDeskStation>=0;
end
--对比userinfo是否值自己
function GameScene:isMyself(userinfo)
	if userinfo == nil or userinfo.dwUserID== nil then
		return false;
	end
	local myself = self:getSelfInfo();
	if myself.dwUserID == userinfo.dwUserID then
		return true;
	end
	return false;
end
--判断当前座位号是否为nil
function GameScene:isFreeChair(chair)
	local playerDeskMap = self:getSitDownPlayerMap()
	for k,v in pairs(playerDeskMap) do
		if playerDeskMap.bDeskStation == chair then
			return false;
		end
	end
	return true;
end
--@desc  站起
--@param code 1.玩家正在游戏中 2.玩家不在房间  -1.其它原因
function GameScene:playerStandUp( user_info , desk_info , code ) 
	if code == 0 or code == 50 then
        --Music:playEffect("res/sound/game/game_stand.mp3", false)
		print("界面游戏玩家站起")
        --self.gamePlayerLayer:onPlayerStandUp( user_info , desk_info , code)
		--if self:isMyself(user_info) == true then
			print("站起玩家为当前用户，进行桌子显示")
			--如果是自己，需要现实的当前桌上的空闲位置
			--self.gamePlayerLayer:onPlayerSitShow(true)
			--self.gameBaseButton:updateShowButton()
		--end
		
		self:deleteUserReady(user_info.dwUserID)
		user_info.bDeskStation = -1
		self.gamePlayerLayer:showUserSit()
		self.gameReadyLayer:updateUser()
		--判断当前自己是否坐下，如果没有坐下，显示按钮，显示提示
		
		if self:isMyself(user_info) and self.isSendSitUp == false and self:isQzProject() == true then
			api_show_tips("超时未开始，系统自动弹起")
			self.gameBaseButton:updateShowButton("Panel_sitdown")
		end
		if self:isAlreadySitdown() == false then
			if self:isQzProject() == true then
				self.gameBaseButton:updateShowButton("Panel_sitdown")
			else
				self.gamePlayerLayer:resetUserPlayer()
				api_hide_loading()
				api_show_loading_gameWaitting("正在匹配...","没有匹配到用户",nil,function()
					self:Exit_game()
				end)
				self.gameTimeLayer:stopTimer()
			end
		end
		
    elseif code == 1 then
        api_show_Msg_Box("房主已经解散房间")
    elseif code == 2 then
        api_show_Msg_Box("玩家不在房间")
    end
end
--添加一个最终结算的界面
function GameScene:showGameOverLayer()
	
end

--@desc  被T           玩家被房主T出房间
--@param code 1.不能踢自己 2.不是房主不能T人 3.要踢出的用户不在房间中 4.你不在房间中不能操作 5.玩家已曾踢除 10.请求参数有误 -1.其它原因
function GameScene:playerByMasterBoot( user_info , desk_info , code )
    if code == 0 then
        api_show_Msg_Box("你已经被房主踢出房间！",function()
            self:Exit_game()
        end)
    elseif code == 1 then
        api_show_Msg_Box("不能踢自己！")
    elseif code == 2 then
        api_show_Msg_Box("不是房主不能T人！")
    elseif code == 3 then
        api_show_Msg_Box("要踢出的用户不在房间中！")
    elseif code == 4 then
        api_show_Msg_Box("你不在房间中不能操作！") 
    elseif code == 5 then
        api_show_Msg_Box("玩家已曾踢除！") 
    elseif code == 10 then
        api_show_Msg_Box("请求参数有误！") 
    end
    

end
-- 掉线通知
-- code 1.socket错误 2.心跳超时
--[[function GameScene:onOffLineNotify( code , desc )
    print("----GameScene:onOffLineNotify  code = " .. code .. "  desc = " .. desc)
    
    if code == 1 then
        api_show_Msg_Box(" 你已经掉线 ！",function()
            self:Exit_game()
        end)
    elseif code == 2 then
        api_show_Msg_Box(" 你已经掉线 ！",function()
            self:Exit_game()
        end)
    end

end
--]]
--其他玩家掉线
function GameScene:other_player_offline( user_info )
    api_show_tips("【"..user_info.nickName .."】掉线")
end
--@desc  桌子解散
--@param code 1.房主解散 2.对局已打满  3.桌子限期已到  4大家同意解散 5.有玩家申请解散房间
--@param user_info 有玩家请求解散时对应玩家的信息
function GameScene:onDeskDismiss( code , user_info )
    print("GameScene:onDeskDismiss")
    if code == 1 then
        api_show_Msg_Box("房主解散房间" , function()
            --self:Exit_game()
        end)
    elseif code == 2 then
        --api_show_Msg_Box("对局已打满",function()
        --    self:Exit_game()
		--end)
    elseif code == 3 then
        api_show_Msg_Box("桌子限期已到",function()
            self:Exit_game()
        end)
    elseif code == 4 then
        api_show_Msg_Box("大家同意解散",function()
            self:Exit_game()
        end)
    elseif code == 5 then
        api_show_Msg_Box("有玩家申请解散房间",function()
            self:Exit_game()
        end)
    end
end

--@desc  房主请求解散失败时的返回
--@param code 0.解散命令已成功，但是要等待游戏结束 1.未在房间里没权解散 2.不是房主无权解散 3.桌子已经解散不需要重复解散 -1.其他原因 
function GameScene:onMasterDismissDeskFail( code  )
    print("GameScene:onMasterDismissDeskFail")
    if code == 0 then
        --api_show_Msg_Box("解散命令已成功，但是要等待游戏结束")
    elseif code == 1 then
        api_show_Msg_Box("未在房间里没权解散")
    elseif code == 2 then
        api_show_Msg_Box("不是房主无权解散")
    elseif code == 3 then
        api_show_Msg_Box("桌子已经解散不需要重复解散")
    end
end
--------------------------------------end------------------------------------------
--排队场特有接口
--用户金币变化
function GameScene:user_score_change(code,score_info)
    print("显示用户金币变化")
	--self.gamePlayerLayer:user_score_change(code,score_info)
end

return GameScene
--endregion