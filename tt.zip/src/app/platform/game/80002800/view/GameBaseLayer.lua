--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local GameMenuLayer = import(".GameMenuLayer")
local GameBaseLayer = class("GameBaseLayer")

function GameBaseLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	local Image_char = seekNodeByName(self.rootNode,"Image_char")
	Image_char:addClickEventListener(function()
		print("-----------123456----------------")
		self.parent:showChat(list)
	end)
	local Text_RoomNum = seekNodeByName(self.rootNode,"Text_RoomNum");
	if self.parent:isQzProject() then
		local deskInfo = self.parent:getDeskInfo();
		Text_RoomNum:setString("桌号:"..deskInfo.roomKey)
	else
		Text_RoomNum:setVisible(false)
		Image_char:setVisible(false)
	end
	
	--返回按钮
	local Image_back = seekNodeByName(self.rootNode,"Image_back")
	Image_back:addClickEventListener(function ()
		self.parent:Exit_game()
	end);
	local weixin_shareicon = seekNodeByName(self.rootNode,"weixin_shareicon")
	weixin_shareicon:addClickEventListener(function ()
		local str = "一齐来嗨大话骰!正宗大话骰玩法：可斋、劈、反劈、开两家、劈两家等刺激玩法!";
		if self.parent:isQzProject() == true then
			str = string.format("一齐来嗨大话骰!%s,正宗大话骰玩法：可斋、劈、反劈、开两家、劈两家等刺激玩法!","房号:"..deskInfo.roomKey)
		end
		self.parent:reqShareToWXSession(lua_to_plat:get_app_name().."[大话骰子]",str);
	end);
	
	local Image_menu = seekNodeByName(self.rootNode,"Image_setmenu")
	if Image_menu ~= nil then
		Image_menu:addClickEventListener(function()
			self.parent:addChild(GameMenuLayer.new(parent))
		end)
	end
	 --语音发送按钮
    
	if self.parent:isQzProject() then
		local quickVoiceLayer = import("app.platform.common.QuickVoiceLayer")
		self.m_voiceLayer = quickVoiceLayer:create(self.parent:getSelfInfo().dwUserID, handler(self.parent, self.parent.reqRecordSound) )
		self.m_voiceLayer:set_voice_image("gameres/a03.png")
		self.m_voiceLayer:set_voice_postion(57,131)
		self.m_voiceLayer:setZOrder(99) 
		self.rootNode:addChild(self.m_voiceLayer)
	end
	local Text_jushu = seekNodeByName(self.rootNode,"Text_jushu")
	if self.parent:isQzProject()==false then
		Text_jushu:setVisible(false)
	end
	self:init()
end

function GameBaseLayer:init()
	
end
--游戏开始的时候，显示当前局数和最大局数
function GameBaseLayer:game_start(resp_json)
	local Text_jushu = seekNodeByName(self.rootNode,"Text_jushu")
	if Text_jushu ~= nil and resp_json ~= nil then
		if resp_json.CurRounds ~= nil and resp_json.MaxRounds ~= nil then
			Text_jushu:setString(string.format("局数:%d/%d",resp_json.CurRounds,resp_json.MaxRounds))
		end
	end

end
--断线重连的时候要显示当前局数
function GameBaseLayer:onGameStation(resp_json)
	local Text_jushu = seekNodeByName(self.rootNode,"Text_jushu")
	if Text_jushu ~= nil and resp_json ~= nil then
		if resp_json.CurRounds ~= nil and resp_json.MaxRounds ~= nil then
			Text_jushu:setString(string.format("局数:%d/%d",resp_json.CurRounds,resp_json.MaxRounds))
		end
	end
end

function GameBaseLayer:updateStartButton()
	if self.parent:getGameStation() == ViewHelp.Game_Station_Type.GameUnStart then
		
	end
end
--选斋
function GameBaseLayer:selctZhai(resp_table)
	if self.Panel_select_zhai ~= nil then
		self.Panel_select_zhai:setVisible(true)
	else 
		print("self.Panel_select_zhai is nil")
	end
end
--结束选斋
function GameBaseLayer:selctZhaiResult(resp_table)
	if self.Panel_select_zhai ~= nil then
		self.Panel_select_zhai:setVisible(false)
	end
	if resp_table.zhai ~= nil then
		if self.Image_logZhai ~= nil then
			self.Image_logZhai:setVisible(true)
		end
	end
end

function GameBaseLayer:start_KaiResult(resp_table)
	
end

return GameBaseLayer


--endregion
