--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameMusic = class("GameMusic")

function GameMusic:ctor(parent)
	Music:stopMusic()  
	self.parent = parent
    self.musicisOpen = false;
	self.voiceisOpen = false;
	self.language = "music/ch_pt"
	if UserData:getMusic() == 0 then
		self.musicisOpen = false
	else
		self.musicisOpen = true
	end
	if UserData:getSound() == 0 then
		self.voiceisOpen = false;
	else
		self.voiceisOpen = true;
	end
	local language = UserData:getSetSwitch(3)
		
	if language == 0  then
		self:setLanguage(true)
	else
		self:setLanguage(false)
	end
	self:playbg();
end
function GameMusic:setMusic(musicOpen)
	self.musicisOpen = musicOpen
	if self.musicisOpen == true then
		self:playbg();
	else
		AudioEngine.stopMusic(false)
	end
end
function GameMusic:setVoice(voiceOpen)
	self.voiceisOpen = voiceOpen
end
function GameMusic:getMusic()
	return self.musicisOpen
end
function GameMusic:getVoice()
	return self.voiceisOpen
end
function GameMusic:setLanguage(isPutong)
	if isPutong == true then
		self.language="music/ch_pt"
	else
		self.language="music/ch_yue"
	end
	print("self.language:"..self.language)
end
function GameMusic:playVoice(man,musicname)
	if self.voiceisOpen == false then
		return;
	end
	local persion = "man"
	if type(man)== "boolean" then
		if man == false then
			persion="woman"
		end
	else
		if tonumber(man) == 0 then
			persion="woman"
		end
	end
	local path = string.format("%s/%s/%s",self.language,persion,musicname)
	print("path:"..path)
	AudioEngine.playEffect(path)
end
function GameMusic:playbg()
	if self.musicisOpen == false then
		return;
	end
	local path="music/bg.mp3"
	AudioEngine.preloadMusic(path)
	AudioEngine.playMusic(path,true)
end
function GameMusic:playYaodongMusic()
	if self.voiceisOpen == false then
		return;
	end
	local path="music/dice_yaoshai.mp3"
	AudioEngine.playEffect(path)
end
function GameMusic:playShandianMusic()
	if self.voiceisOpen == false then
		return;
	end
	local path="music/lightning.mp3"
	AudioEngine.playEffect(path)
end

return GameMusic


--endregion
