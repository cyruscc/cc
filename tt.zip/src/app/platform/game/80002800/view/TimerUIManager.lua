--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local TimerUIManager = class("TimerUIManager")

function TimerUIManager:ctor(parent,rootNode)

	self.parent = parent
	
	self.rootNode = rootNode
    
    self.Image_timebg = rootNode:getChildByName("Image_timebg")

    --[[local Sprite = cc.Sprite:create("gameres/game_clock_1.png")
    self.ProgressTimer = cc.ProgressTimer:create(Sprite)
    self.ProgressTimer:setPosition(self.Image_timebg:getPositionX(), self.Image_timebg:getPositionY())
    rootNode:addChild(self.ProgressTimer)
    self.ProgressTimer:setPercentage(100)
    self.ProgressTimer:setMidpoint(cc.p(0.5, 0.5))
    self.ProgressTimer:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
    self.ProgressTimer:setRotationSkewY(180)

    self.AtlasLabel = seekNodeByName(rootNode,"timeNum")
    self.AtlasLabel:setString("")
    self.time = 0
    self.schedule_handle = nil
	
	self.Text_tip =seekNodeByName(rootNode,"Text_tip")
	if self.Text_tip ~= nil then
		self.Text_tip:setString("")
	end
	--]]
	self:ui_close();
	self:init()
end
function TimerUIManager:init()
	for i = 1,6 do
		local Image_time = seekNodeByName(self.rootNode,"Image_time"..i)
		if Image_time ~= nil then
			Image_time:setVisible(false);
			--Image_time:removeAllChildren();
		end
	end
end
function TimerUIManager:ready(resp_json)
	if resp_json ~= nil and resp_json.time ~= nil then
		self:gameTipActon("点击开始游戏进行游戏",resp_json.time,function()
			if self.parent:isQzProject() == false then
				--self.parent.gameBaseButton:updateShowButton("Panel_reChange")
			end
		end)
	end
end
--摇骰子时间
--[["playerData" = {
     1 = {
         "chair" = 0
         "point" = 0
     }
     2 = {
         "chair" = 1
         "point" = 0
     }
 }
]]
function TimerUIManager:gameRockTime(resp_table)
	print("=====================")
	self:gameTipActon("摇动时间",resp_table.TouziRockTime-4,function()
		print("摇动提示超时")
		self.parent:outofTimeNoYaodong()
	end,cc.p(0,-100))	
end
function TimerUIManager:gameTipActon(tipmessage,time,callback,position)
	self:stopTimer()	
	local Panel_tip = seekNodeByName(self.rootNode,"Panel_tip")
	Panel_tip:removeAllChildren()
	if not time or time<=0 or time>600 then
		--self:ui_close()
		if time<=0 and call_function~=nil then
			call_function()
		end
		return
	end
	
	if self.schedule_handle~=nil then
		g_scheduler:unscheduleScriptEntry(self.schedule_handle)
	end
	
	local path ="gameres/csb/waitingtip.csb"
	local loadinganimlaction = cc.CSLoader:createTimeline(path)
	local loadinganimlNode = cc.CSLoader:createNode(path)
	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,false)
	local message = seekNodeByName(loadinganimlNode,"Text_1")
	
	local showMessage = string.format("%s...(%d)",tipmessage,time)
	message:setString(showMessage)
	if position ~= nil then
		loadinganimlNode:setPosition(position)
	end
	
	--loadinganimlNode:setPosition(WinSize.width/2,WinSize.height/2)
	Panel_tip:addChild(loadinganimlNode)
	--loadinganimlaction:setLastFrameCallFunc(function()
		--loadinganimlNode:removeFromParent()
	--end)
	self.time = time
	self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
		self.time = self.time-0.25
		
		showMessage = string.format("%s...(%d)",tipmessage,math.ceil(self.time))
		--print("showMessage:"..showMessage)
		message:setString(showMessage)
		if self.time<=0 then
			--g_scheduler:unscheduleScriptEntry(self.schedule_handle)
			self:stopTimer()
			if loadinganimlNode ~= nil then
				--loadinganimlNode:removeFromParentAndCleanup()
			end
			if callback~=nil then
			   callback()
			end
		end
	end,
	0.25, 
	false)
end

--选斋的时间
function TimerUIManager:game_selectZhai(resp_table)
	self:gameTipActon("选斋时间",resp_table.m_TouziJiaoZhaiTime-2)
	self:showWaitTimeStation(resp_table.m_TouziJiaoZhaiPosition,resp_table.m_TouziJiaoZhaiTime-2,function()
			print("---------------m_TouziJiaofenTime out of time--------")
		end)
end
function TimerUIManager:User_selectZhai(resp_table)
	self:init();
	self:gameTipActon("选斋结束",-1)
end
--叫分0_92,data:{"jiaofenStation":1,"lessAnNum":3,"lessDianNum":1,"m_TouziJiaofenTime"
--:15,"maxAnNum":10,"userFenData":[{"chair":0,"jiaofenDian":0,"jiaofenNum":0},{"ch
--air":1,"jiaofenDian":0,"jiaofenNum":0}]}

function TimerUIManager:start_jiaofen(resp_table)
	self:init();
	--self:gameTipActon("叫分",resp_table.m_TouziJiaofenTime)
	if resp_table.jiaofenStation ~= nil and resp_table.m_TouziJiaofenTime ~= nil and resp_table.m_TouziJiaofenTime>0  then
		--local user_chair = self.parent:getHelper():DeskStation2View(resp_table.jiaofenStation)
		print("----TimerUIManager:start_jiaofen----:");
		self:showWaitTimeStation(resp_table.jiaofenStation,resp_table.m_TouziJiaofenTime,function()
			print("---------------m_TouziJiaofenTime out of time--------")
		end)
	end
end
--收到劈的消息
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_chair" = 0
        }
    }
    "m_TouziJiaofenTime" = 15
    "piUser"             = 1
}]]
function TimerUIManager:response_receive_pi(resp_json)
	local piwaitTime = resp_json.m_TouziJiaofenTime
	if resp_json ~= nil and resp_json.beiPiUser ~= nil then
		self:gameTipActon("等待被劈用户操作",piwaitTime)
		for i = 1,#resp_json.beiPiUser do
			self:showWaitTimeStation(resp_json.beiPiUser[i].beikai_chair,piwaitTime,function()
				print("---------------m_TouziJiaofenTime out of time--------")
			end)
		end
	end
	
end
--开消息
function TimerUIManager:response_userSelectKai(resp_json)
	self:init();
	self:stopTimer()
	self:gameTipActon("开",-1)
end
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_beilv" = 0
            "beikai_chair" = 2
			"beikai_isAction"=0//是否已经操作
        }
        2 = {
            "beikai_beilv" = 4
            "beikai_chair" = 1
			"beikai_isAction"=1//是否已经操作
        }
    }
	"actionUser"=1
    "piUser"    = 0
}]]
function TimerUIManager:response_Pi_kai(resp_json)
	--self:init();
	
	if resp_json ~= nil and resp_json.actionUser ~= nil and resp_json.actionUser>=0 then
		self:showWaitTimeStation(resp_json.actionUser,0)
		local actionUserTotal = true
		for i = 1,#resp_json.beiPiUser do
			if  resp_json.beiPiUser[i].beikai_isAction<=0 then
				actionUserTotal= false
			end
		end
		if actionUserTotal == true then
			self:stopTimer()
		end
	end
	--self:gameTipActon("开",-1)
end
--公共方法，某个位置上显示进度,station位置编号，timenum，时间，callback回调
function TimerUIManager:showWaitTimeStation(station,timenum,callback)
	local user_chair = self.parent:getHelper():DeskStation2View(station)
	print("----showWaitTimeStation----user_chair:"..user_chair);
	local Image_time = seekNodeByName(self.rootNode,"Image_time"..user_chair)
	if Image_time ~= nil then
		Image_time:setVisible(true);
		if timenum <=0 then
			Image_time:setVisible(false);
			return;
		end
		self:HeadWaitTime(Image_time,timenum,timenum,callback)
	else
		print("Image_time is nil")
	end
end
--进度动画
function TimerUIManager:HeadWaitTime(playerbg,iThinkTime,iTotalTime,callback)
	playerbg:setVisible(true)
	print("HeadWaitTime---开始显示动画")
	local actionTo = CCProgressFromTo:create(iThinkTime, (iThinkTime/iTotalTime)*100,0)
	local progress = CCProgressTimer:create(CCSprite:create("gameres/b24.png"))--gameres/b05.png
	progress:setType(cc.PROGRESS_TIMER_TYPE_BAR)
	progress:setAnchorPoint(0,0)
	progress:setMidpoint(cc.p(0, 0.5))
	local sequence = cc.Sequence:create(actionTo,cc.CallFunc:create(function() 
			playerbg:setVisible(false)
			--progress:removeFormParent()
            if callback ~= nil then
				callback()
			end
        end ))
	sequence:setTag(107)
	progress:runAction(sequence)
	progress:setBarChangeRate(cc.p(1, 0))
	playerbg:removeAllChildren()
	--[[progress:setTag(106)
	local action = playerbg:getChildByTag(106)
	if  action~= nil then
		action:stopActionByTag(107)
		action:removeFromParent()
	end
	--]]
	--end
	playerbg:addChild(progress)
	
end

function TimerUIManager:startTimer(time, call_function, text)
     --[[self:ui_open()
     local Sprite = cc.Sprite:create("gameres/game_clock_1.png")
     self.ProgressTimer:setSprite(Sprite)
     self.ProgressTimer:setPercentage(100)
     if not time or time<=0 or time>600 then
        --self:ui_close()
        if time<=0 and call_function~=nil then
            call_function()
        end
        return
     end
     if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
     end
     self.time = time
     self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
        self.time = self.time-0.25
        self.AtlasLabel:setString(tostring(math.ceil(self.time)))
        self.ProgressTimer:setPercentage(self.time/time*100)
        if self.time<=time/2 then
           local Sprite = cc.Sprite:create("gameres/game_clock_2.png")
           self.ProgressTimer:setSprite(Sprite)
           self.AtlasLabel:setProperty(tostring(math.ceil(self.time)), "gameres/num/02.png", 26, 42, '/') 
        end
        if self.time<=time*1/4 then
           local Sprite = cc.Sprite:create("gameres/game_clock_3.png")
           self.ProgressTimer:setSprite(Sprite)
           self.AtlasLabel:setProperty(tostring(math.ceil(self.time)), "gameres/num/03.png", 26, 42, '/') 
        end
        if self.time<=0 then
            self:stopTimer()
            if call_function~=nil then
               call_function()
            end
        end
     end,
     0.25, 
     false)
     self.AtlasLabel:setProperty(tostring(math.ceil(self.time)), "gameres/num/02.png", 26, 42, '/')
     self.AtlasLabel:setString(tostring(math.ceil(self.time)))
     if text then
        self.Text_tip:setString(text)
     else
        self.Text_tip:setString("")
     end
	--]]
end


function TimerUIManager:stopTimer()
    if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
        self.schedule_handle = nil
    end
	local Panel_tip = seekNodeByName(self.rootNode,"Panel_tip")
	Panel_tip:removeAllChildren()
    self.time = 0
    --self.AtlasLabel:setString("")
    --.Text_tip:setString("")
    self:ui_close()
	self:init()
end

function TimerUIManager:setText(text)
    self.Text_tip:setString(text)
end

function TimerUIManager:setEnable(enable)
    self.Image_timebg:setVisible(enable)
    self.ProgressTimer:setVisible(enable)
    self.AtlasLabel:setVisible(enable)
    self.Text_tip:setVisible(enable)
end


function TimerUIManager:clearSchedule()
   if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
   end
end


function TimerUIManager:ui_open()
    --self.rootNode:setVisible(true)
end

function TimerUIManager:ui_close()
    --self.rootNode:setVisible(false)
end
--断线重连
function TimerUIManager:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE then
		--local resp = {}
		--resp.m_TouziJiaoZhaiTime = resp_json.iLeaverTime
		--resp.m_TouziJiaoZhaiPosition = resp_json.m_TouziJiaoZhaiPosition
		if resp_json ~= nil and resp_json.iLeaverTime ~= nil  then
			self:gameTipActon("点击开始游戏进行游戏",resp_json.iLeaverTime)
		end
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_YAOTOUZI then
		print("TimerUIManager  摇骰子状态")
		local resp = resp_json
		resp.TouziRockTime = resp_json.iLeaverTime
		self:gameRockTime(resp)
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_XUANZHAI then
		local resp = {}
		resp.m_TouziJiaoZhaiTime = resp_json.iLeaverTime
		resp.m_TouziJiaoZhaiPosition = resp_json.m_TouziJiaoZhaiPosition
		
		self:game_selectZhai(resp)
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_JIAOFEN then
		--resp_table.jiaofenStation ~= nil and resp_table.m_TouziJiaofenTime 
		local resp = {}
		resp.jiaofenStation =resp.jiaofenStation 
		resp.m_TouziJiaofenTime = resp_json.iLeaverTime
		self:start_jiaofen(resp)
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_PI  then
		local resp = {}
		resp.m_TouziJiaofenTime = resp_json.iLeaverTime
		resp.beiPiUser = resp_json.beiPiUser
		self:response_receive_pi(resp)
	end
end

return TimerUIManager



--endregion
