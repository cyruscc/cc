--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameBaseButton = class("GameBaseButton")
local GameSceneModule = import("..GameSceneModule")

function GameBaseButton:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	
	self.Panel_sitdown = seekNodeByName(self.rootNode,"Panel_sitdown")
	local Image_back = seekNodeByName(self.Panel_sitdown,"Image_back")
	local Image_sitdown = seekNodeByName(self.Panel_sitdown,"Image_sitdown")
	Image_back:addClickEventListener(function()
			self.parent:Exit_game()
		end);
	Image_sitdown:addClickEventListener(function()
			--如果是排队场，直接进行发送搓桌命令
			if self.parent:isQzProject() == false then
				api_show_loading_gameWaitting("正在匹配...","没有匹配到用户",nil,function()
					self.parent:Exit_game()
				end)
				self.parent:reqChangeDesk()
				--清除倒计时
				self.parent.gameTimeLayer:stopTimer()
			else			
				local playerCount = self.parent:getHelper():getPlayerContainNum()
				local freeChair = 0;
				for i = 0,playerCount-1 do
					if self.parent:isFreeChair(i) then
						freeChair = i;
						break;
					end
				end
				self.parent:reqSitdownDesk(freeChair,true)
			end
		end);
	--开始按钮组
	self.Panel_start = seekNodeByName(self.rootNode,"Panel_start");
	self.Panel_start:setVisible(false)
	local Image_yaoqing = seekNodeByName(self.Panel_start,"Image_yaoqing")
	if Image_yaoqing ~= nil then
		Image_yaoqing:addClickEventListener(function()
				print("邀请好友")
				local str = "一齐来嗨大话骰!正宗大话骰玩法：可斋、劈、反劈、开两家、劈两家等刺激玩法!";
				if self.parent:isQzProject() == true then
					local deskInfo = self.parent:getDeskInfo();
					str = string.format("一齐来嗨大话骰!%s,正宗大话骰玩法：可斋、劈、反劈、开两家、劈两家等刺激玩法!","房号:"..deskInfo.roomKey)
				end
				self.parent:reqShareToWXSession(lua_to_plat:get_app_name().."[大话骰子]",str);
			end);
	end
	local Image_start = seekNodeByName(self.Panel_start,"Image_start")
	if Image_start ~= nil then
		Image_start:addClickEventListener(function()
			print("----click start")
			self.parent:check_ready()
		end);
	end
	local Image_changestart = seekNodeByName(self.Panel_start,"Image_reChange")
	Image_changestart:addClickEventListener(function()
		print("开始换桌")
		self.parent:deleteAllUserReady()
		api_hide_loading()
		api_show_loading_gameWaitting("正在匹配...","没有匹配到用户",nil,function()
			self.parent:Exit_game()
		end)
		self.parent.gamePlayerLayer:resetUserPlayer()
		--清除倒计时
		self.parent.gameTimeLayer:stopTimer()
		self.parent:reqChangeDesk()
	end)
	if self.parent:isQzProject() == false then
		Image_yaoqing:setVisible(false)
		Image_changestart:setVisible(true)
		--Image_start:setPositionX(Image_start:getPositionX()-100)
	else
		Image_changestart:setVisible(false)
		Image_yaoqing:setVisible(true)
	end
	self.panel_button_bg = seekNodeByName(self.rootNode,"panel_button_bg")
	self.panel_button_bg:setVisible(false)
	--摇骰子按钮组
	self.Panel_roundType = seekNodeByName(self.rootNode,"Panel_roundType")
	if self.Panel_roundType ~= nil then
		self.Panel_roundType:setVisible(false)
		local Image_left_right = seekNodeByName(self.Panel_roundType,"Image_left_right")
		if Image_left_right ~= nil then
			Image_left_right:addClickEventListener(function()
				--self:showStartAnimal("zuo")
				self.parent:showAnimal("gameres/csb/zuo.csb",function ()
					self.parent:hidYaodong()
					GameSceneModule:getInstance():request_player_rockOver()
				end)
				self.parent.gameTimeLayer:stopTimer()
				--self.Panel_roundType:setVisible(false)
				self:updateShowButton()
			end);
		end
		local Image_unclock = seekNodeByName(self.Panel_roundType,"Image_unclock")
		if Image_unclock ~= nil then
			Image_unclock:addClickEventListener(function()
				--self:showStartAnimal("ni")
				self.parent:showAnimal("gameres/csb/ni.csb",function ()
					self.parent:hidYaodong()
					GameSceneModule:getInstance():request_player_rockOver()
				end)
				self.parent.gameTimeLayer:stopTimer()
--				self.Panel_roundType:setVisible(false)
				self:updateShowButton()			
			end);
		end
		local Image_clock = seekNodeByName(self.Panel_roundType,"Image_clock")
		if Image_clock ~= nil then
			Image_clock:addClickEventListener(function()
				--self:showStartAnimal("shun")
				self.parent:showAnimal("gameres/csb/shun.csb",function ()
					self.parent:hidYaodong()
					GameSceneModule:getInstance():request_player_rockOver()
				end)
				self.parent.gameTimeLayer:stopTimer()
				self.Panel_roundType:setVisible(false)
			end);
		end
	end
	--选择斋与不斋按钮组
	self.Panel_select_zhai = seekNodeByName(self.rootNode,"Panel_select_zhai")
	if self.Panel_select_zhai~= nil then
		self.Panel_select_zhai:setVisible(false)
		local Image_zhai = seekNodeByName(self.Panel_select_zhai,"Image_zhai")
		local Image_buzhai = seekNodeByName(self.Panel_select_zhai,"Image_buzhai")
		Image_zhai:addClickEventListener(function()
			GameSceneModule:getInstance():send_game_selectZhai(true)
		end)
		Image_buzhai:addClickEventListener(function()
			GameSceneModule:getInstance():send_game_selectZhai(false)
		end)
	end
	--logzhai
	self.Image_logZhai = seekNodeByName(self.rootNode,"Image_logZhai")
	if self.Image_logZhai ~= nil then
		self.Image_logZhai:setVisible(false)
	end
	--Panel_select_jiao
	self.Panel_select_jiao = seekNodeByName(self.rootNode,"Panel_select_jiao")
	if self.Panel_select_jiao ~= nil then
		self.Panel_select_jiao:setVisible(false)
		--叫分按钮组监听
		local Image_kai = seekNodeByName(self.rootNode,"Image_kai")
		if Image_kai ~= nil then
			Image_kai:addClickEventListener(function()
				GameSceneModule:getInstance():response_Kai()
			end)
		end
		self.ImageKai = Image_kai
		--开2
		local Image_kai2 = seekNodeByName(self.rootNode,"Image_kai2")		
		if Image_kai2 ~= nil then
			Image_kai2:addClickEventListener(function()
				self.parent:setMengbanVisible(true)
				self.parent:setPlayerClickCallBack(function(selectData)
					GameSceneModule:getInstance():response_Kai2(selectData)
				end)
			end)
		end
		self.ImageKai2 = Image_kai2
		--劈
		local Image_pi = seekNodeByName(self.rootNode,"Image_pi")
		if Image_pi ~= nil then
			Image_pi:addClickEventListener(function()
				GameSceneModule:getInstance():request_Pi()
			end)
		end
		self.ImagePi = Image_pi
		--劈2
		local Image_pi2 = seekNodeByName(self.rootNode,"Image_pi2")
		if Image_pi2 ~= nil then
			Image_pi2:addClickEventListener(function()
				self.parent:setMengbanVisible(true)
				self.parent:setPlayerClickCallBack(function(selectData)
					GameSceneModule:getInstance():request_Pi(selectData)
				end)
			end)
		end
		self.ImagePi2 = Image_pi2
		--叫分
		local Image_jiao = seekNodeByName(self.rootNode,"Image_jiao")
		if Image_jiao ~= nil then
			Image_jiao:addClickEventListener(function()
				self:ButtonJiaofen()
			end)
		end
		self.Imagejiao =Image_jiao
		--叫+1分
		local Image_jiao_1 = seekNodeByName(self.rootNode,"Image_jiao_1")
		if Image_jiao_1 ~= nil then
			Image_jiao_1:addClickEventListener(function()
				self:ButtonJiaofen_1()
			end)
		end
		self.ImageJiao1 = Image_jiao_1
		self.Image_numbg = seekNodeByName(self.rootNode,"Image_numbg")
		self.Image_numbg:setVisible(false)
		local Image_dianbg = seekNodeByName(self.Image_numbg,"Image_dianbg")
		Image_dianbg:setVisible(false)
		
		local Image_ItemNum = seekNodeByName(self.Image_numbg,"Image_ItemNum")
		Image_ItemNum:setVisible(false)
		self.Image_snum = seekNodeByName(self.Image_numbg,"Panel_snum")
		self.Image_snum:setVisible(false);
		--[[if self.parent:isQzProject() == false then
			Image_kai2:setVisible(false)
			Image_pi2:setVisible(false)
		end]]
	end
	--被劈后，操作按钮
	self.Panel_select_beipi = seekNodeByName(self.rootNode,"Panel_select_beipi")
	if self.Panel_select_beipi ~= nil then
		self.Image_pi_kai = seekNodeByName(self.Panel_select_beipi,"Image_pi_kai")
		self.Image_pi_kai:addClickEventListener(function()
				--self:ButtonJiaofen_1()
				GameSceneModule:getInstance():request_pi_kai(1)
			end)
		self.Image_pi_unpi = seekNodeByName(self.Panel_select_beipi,"Image_pi_unpi");
		self.Image_pi_unpi:addClickEventListener(function()
				--self:ButtonJiaofen_1()
				GameSceneModule:getInstance():request_pi_kai(2)
			end)
		self.Panel_select_beipi:setVisible(false)
	end
	--抢劈
	self.Panel_qiangpi = seekNodeByName(self.rootNode,"Panel_qiangpi")
	if self.Panel_qiangpi ~= nil then
		self.Image_qiangpi = seekNodeByName(self.Panel_qiangpi,"Image_qiangpi")
		self.Image_qiangpi:addClickEventListener(function()
				--self:ButtonJiaofen_1()
				GameSceneModule:getInstance():request_qiangpi()
			end)
		self.Panel_qiangpi:setVisible(false)
	end
	self.panel_reChange = seekNodeByName(self.rootNode,"Panel_reChange")
	if self.panel_reChange ~= nil then
		local Image_reChange = seekNodeByName(self.panel_reChange,"Image_reChange")
		Image_reChange:addClickEventListener(function ()
			if self.parent:isQzProject() == false then
				print("开始换桌")
				self.parent:deleteAllUserReady()
				api_show_loading_gameWaitting("正在匹配...","没有匹配到用户",nil,function()
					self.parent:Exit_game()
				end)
				self.parent:reqChangeDesk()
			end
		end)
	end
	self:init()
end
function GameBaseButton:init()
	self:updateShowButton()
end
function GameBaseButton:updateJiaofenButton(resp_json)
	local Image_kai = seekNodeByName(self.rootNode,"Image_kai")
	if resp_json.isKai == true then
		Image_kai:setOpacity(255)
		Image_kai:addClickEventListener(function()
				GameSceneModule:getInstance():response_Kai()
			end)
	else
		Image_kai:setOpacity(80)
		Image_kai:addClickEventListener(function()
			end)
	end
	if resp_json.isKai2 == true then
		self.ImageKai2:setOpacity(255)
		self.ImageKai2:addClickEventListener(function()
				--self.parent:setMengbanVisible(true)
				--self.parent:setPlayerClickCallBack(function(selectData)
					GameSceneModule:getInstance():response_Kai2()
				--end)
			end)
	else
		self.ImageKai2:setOpacity(80)
		self.ImageKai2:addClickEventListener(function()
			end)
	end
	if resp_json.isPi == true then
		self.ImagePi:setOpacity(255)
		self.ImagePi:addClickEventListener(function()
				GameSceneModule:getInstance():request_Pi()
			end)
	else
		self.ImagePi:setOpacity(80)
		self.ImagePi:addClickEventListener(function()
			end)
	end
	if resp_json.isPi2 == true then
		self.ImagePi2:setOpacity(255)
		self.ImagePi2:addClickEventListener(function()
				--self.parent:setMengbanVisible(true)
				--self.parent:setPlayerClickCallBack(function(selectData)
					GameSceneModule:getInstance():request_Pi2()
				--end)
			end)
	else
		self.ImagePi2:setOpacity(80)
		self.ImagePi2:addClickEventListener(function()
			end)
	end
	if resp_json.isFen == true then
		self.Imagejiao:setOpacity(255)
		self.Imagejiao:addClickEventListener(function()
				self:ButtonJiaofen()
			end)
	else
		self.Imagejiao:setOpacity(80)
		self.Imagejiao:addClickEventListener(function()
			end)
	end
	if resp_json.isFenAdd1 == true then
		self.ImageJiao1:setOpacity(255)
		self.ImageJiao1:addClickEventListener(function()
				self:ButtonJiaofen_1()
			end)
	else
		self.ImageJiao1:setOpacity(80)
		self.ImageJiao1:addClickEventListener(function()
			end)
	end
end
--等待进入下一轮
--[["resp_json" = {
    "GameStation" = 1
    "playerData" = {
        1 = {
            "bAgree" = true
            "chair"  = 0
            "point"  = 6
        }
        2 = {
            "bAgree" = false
            "chair"  = 1
            "point"  = -6
        }
    }
    "time"        = 20
}]]
function GameBaseButton:ready(resp_json)
	--self.Panel_start()
	self:updateShowButton()
	if resp_json ~= nil and resp_json.playerData ~= nil then
		for i = 1,#resp_json.playerData do
			if resp_json.playerData[i].chair == self.parent:getSelfInfo().bDeskStation then
				if resp_json.playerData[i].bAgree == false then
					self:updateShowButton("Panel_start")
				end
			end
		end
	end
	
end
--按钮组在这里进行统一管理，每次只显示一组，不会多组同时显示
function GameBaseButton:updateShowButton(strButtonName)
	self.Panel_sitdown:setVisible(false)
	self.Panel_start:setVisible(false);
	self.Panel_roundType:setVisible(false)
	self.Panel_select_zhai:setVisible(false)
	self.Panel_select_jiao:setVisible(false)
	self.Panel_select_beipi:setVisible(false)
	self.Panel_qiangpi:setVisible(false)
	self.panel_button_bg:setVisible(false)
	self.panel_reChange:setVisible(false);
	if strButtonName ~= nil then
		if strButtonName == "Panel_sitdown"  then
			self.Panel_sitdown:setVisible(true)
			self:showButtonAnimal(self.Panel_sitdown,0,55)
			self.panel_button_bg:setVisible(true)
		elseif strButtonName == "Panel_start" then
			self.Panel_start:setVisible(true)
			--self:showButtonAnimal(self.Panel_start,0,55)
			self.panel_button_bg:setVisible(true)
			local Image_start = seekNodeByName(self.rootNode,"Image_start")
			local imgfont38 = seekNodeByName(Image_start,"Image_38")--开始游戏
			local imgfont138 = seekNodeByName(Image_start,"Image_138")--准备
			imgfont38:setVisible(false)
			imgfont138:setVisible(false)
			if self.parent:getIsFirstGame() == true and self.parent:isMast() then
				imgfont38:setVisible(true)
			else
				imgfont138:setVisible(true)
			end
			--self:showButtonAnimal(self.panel_button_bg,0,15)
		elseif strButtonName == "Panel_roundType" then
			self.Panel_roundType:setVisible(true)
			self:showButtonAnimal(self.Panel_roundType,0,55)
			self.panel_button_bg:setVisible(true)
			--self:showButtonAnimal(self.panel_button_bg,0,15)
		elseif strButtonName == "Panel_select_zhai" then
			self.Panel_select_zhai:setVisible(true)
			self:showButtonAnimal(self.Panel_select_zhai,0,55)
			--self:showButtonAnimal(self.panel_button_bg,0,15)
			self.panel_button_bg:setVisible(true)
		elseif strButtonName == "Panel_select_jiao" then
			self.Panel_select_jiao:setVisible(true)
			self:showButtonAnimal(self.Panel_select_jiao,0,55,function()
				
			end)
			
			--self:showButtonAnimal(self.panel_button_bg,0,15)
			self.panel_button_bg:setVisible(true)
		elseif strButtonName == "Panel_select_beipi" then
			self.Panel_select_beipi:setVisible(true)
			self:showButtonAnimal(self.Panel_select_beipi,0,55)
			--self:showButtonAnimal(self.panel_button_bg,0,15)
			self.panel_button_bg:setVisible(true)
		elseif strButtonName == "Panel_qiangpi" then
			self.Panel_qiangpi:setVisible(true)
			self:showButtonAnimal(self.Panel_qiangpi,0,55)
			--self:showButtonAnimal(self.panel_button_bg,0,15)
			self.panel_button_bg:setVisible(true)
		elseif strButtonName == "Panel_reChange" then
			self.panel_reChange:setVisible(true)
			self.panel_button_bg:setVisible(true)
			self:showButtonAnimal(self.panel_reChange,0,55)
		end
	end
end
--执行cocosstudio中做的动画
function GameBaseButton:showStartAnimal(animalName)
	local path = string.format("gameres/csb/%s.csb",animalName)
	
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)

	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,false)
	loadinganimlNode:setPosition(WinSize.width/2,WinSize.height/2)
	self.rootNode:addChild(loadinganimlNode)
	loadinganimlaction:setLastFrameCallFunc(function()
		loadinganimlNode:removeFromParent()
	end)
end
--收到准备消息
function GameBaseButton:resp_player_ready(resp_json)
	if resp_json.chair == self.parent:getSelfInfo().bDeskStation then
		self.Panel_start:setVisible(false)
	end
end
--初始显示邀请好友和开始按钮
function GameBaseButton:game_rebind(resp_json)
	--[[if self.parent:getGameStation() == 0 or self.parent:getGameStation() == 1 then
		self.Panel_start:setVisible(true)
	else
		self.Panel_start:setVisible(false)
	end
	--]]
end
--开始显示骰子了，
function GameBaseButton:game_card_send()
	--self.Panel_start:setVisible(false)
	self:updateShowButton()
end
function GameBaseButton:overRock()
	--self.Panel_start:setVisible(false)
	self:updateShowButton()
	self:showStartAnimal("zuo")
end
--游戏开始的时候对当前界面的影响
function GameBaseButton:game_start(resp_json)
	--self.Panel_start:setVisible(false)
	--self.Panel_roundType:setVisible(true)
	self:updateShowButton("Panel_roundType")
	--self:showButtonAnimal(self.Panel_roundType,0,55)
end
--+1按钮相应
function GameBaseButton:ButtonJiaofen_1()
	if self.jiaofenLimit ~= nil then
		local minNum = tonumber(self.jiaofenLimit.lessAnNum)
		local minDianNum = tonumber(self.jiaofenLimit.lessDianNum)
		local maxNum = tonumber(self.jiaofenLimit.maxAnNum)
		if minDianNum==1 then
			--minNum = minNum-1
			minDianNum = 6
		else
			minNum=minNum+1
			minDianNum = minDianNum-1
		end
		
		--GameSceneModule:getInstance():response_AddFen(minNum,minDianNum)
		GameSceneModule:getInstance():response_Add1()
	end
end
--叫分按钮响应
function GameBaseButton:ButtonJiaofen()
	self.Image_numbg:setVisible(true)
	--排列数组上的数字
	--计算上面需要排列多少数字
	if self.jiaofenLimit ~= nil then
		local minNum = tonumber(self.jiaofenLimit.lessAnNum)
		local minDianNum = tonumber(self.jiaofenLimit.lessDianNum)
		local maxNum = tonumber(self.jiaofenLimit.maxAnNum)
		--local Image_numbg = seekNodeByName(self.rootNode,"Image_numbg")
		--list
		local ListView_1 = seekNodeByName(self.Image_numbg,"ListView_1")
		ListView_1:removeAllChildren()
		ListView_1:setScrollBarEnabled(false)
		local lengthnum = maxNum-minNum+1
		if lengthnum>8 then
			lengthnum = 8
		elseif lengthnum <1 then
			lengthnum = 1;
		end
		--ListView_1:setSize(lengthnum*80,ListView_1:getSize().height)
		----Image_numbg:setSize(lengthnum*80+40,Image_numbg:getSize().height)
		--模板
		local Image_ItemNumtmp = seekNodeByName(self.Image_numbg,"Image_ItemNum")
		Image_ItemNumtmp:setVisible(false)
		local Image_dianbg = seekNodeByName(self.Image_numbg,"Image_dianbg")
		Image_dianbg:setVisible(false)
		--选择的三角符号隐藏
		self.Image_snum:setVisible(false)
		
		for i = minNum,maxNum do
			local itemtmp = Image_ItemNumtmp:clone()
			itemtmp:setVisible(true)
			local itemNum = seekNodeByName(itemtmp,"itemNum");
			itemNum:setString(i)
			itemtmp:addClickEventListener(function()
				self.selectAnNum = i
				self:showDianLayer(i,itemtmp)
			end);
			ListView_1:pushBackCustomItem(itemtmp)
		end
	else
		print("self.jiaofenLimit is nil")
	end
end

--叫分按钮上面，点子的显示
function GameBaseButton:showDianLayer(startdian,item)
	--local Image_numbg = seekNodeByName(self.rootNode,"Image_numbg")
	local ListView_1 = seekNodeByName(self.Image_numbg,"ListView_1")
	local Image_dianbg = seekNodeByName(self.Image_numbg,"Image_dianbg")
	Image_dianbg:setVisible(true)
	--Image_dianbg:setPosition(ListView_1:getPositionX()+item:getPositionX()+10,ListView_1:getPositionY()+item:getPositionY()+45)
	local minNum = tonumber(self.jiaofenLimit.lessAnNum)
	local minDianNum = tonumber(self.jiaofenLimit.lessDianNum)
	local maxNum = tonumber(self.jiaofenLimit.maxAnNum)
	local positionx = ListView_1:getInnerContainer():getPositionX();
	local positiony = ListView_1:getInnerContainer():getPositionY();
	print("ListView_1:getInnerContainerPosition()--------:"..positionx..","..positiony)
	self:showShanSnum(cc.p(ListView_1:getPositionX()+item:getPositionX()-20+positionx,ListView_1:getPositionY()+item:getPositionY()+45))
	
	--点数的监听
	for i = 1,6 do
		local itemdian = seekNodeByName(Image_dianbg,"Image_jiao_"..i)
		if itemdian ~= nil then
			print("startdian:"..startdian)
			print("minNum:"..minNum)
			print("minDianNum:"..minDianNum)
			if startdian == minNum and minDianNum > i and i ~= 1 then
				itemdian:setOpacity(80)
				itemdian:addClickEventListener(function()
					
				end)
			else
				itemdian:setOpacity(255)
				itemdian:addClickEventListener(function()
					self.selectDianNum = i;
					GameSceneModule:getInstance():response_AddFen(self.selectAnNum,self.selectDianNum)
				end)				
			end
		end
	end
	
end
--显示点数下面闪动的三角
function GameBaseButton:showShanSnum(position)
	self.Image_snum:setVisible(true)
	self.Image_snum:setPosition(position)
	if self.Image_snum:getChildByTag(1005) ~= nil then
		self.Image_snum:removeChildByTag(1005)
	end
	local path = "gameres/action/selectnum.csb"
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)
	
	loadinganimlNode:setTag(1005)
	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,true)
	loadinganimlNode:setPosition(self.Image_snum:getSize().width/2,self.Image_snum:getSize().height/2)
	self.Image_snum:addChild(loadinganimlNode)
end
function GameBaseButton:updateStartButton()
	if self.parent:getGameStation() == ViewHelp.Game_Station_Type.GameUnStart then
		
	end
end
--选斋
function GameBaseButton:selctZhai(resp_table)
	self:updateShowButton()
	if self.Panel_select_zhai ~= nil then
		if resp_table.m_TouziJiaoZhaiPosition == self.parent:getSelfInfo().bDeskStation then
			--self.Panel_select_zhai:setVisible(true)
			--self:showButtonAnimal(self.Panel_select_zhai,0,55)
			self:updateShowButton("Panel_select_zhai")
		end
	else 
		print("self.Panel_select_zhai is nil")
	end
end
function GameBaseButton:showButtonAnimal(item,startIndex,endIndex,callback)
	local csbFile = "gameres/csb/gameMainscene.csb"
	local buttonShowAnimal = cc.CSLoader:createTimeline(csbFile)
	item:runAction(buttonShowAnimal)
	buttonShowAnimal:gotoFrameAndPlay(startIndex,endIndex,false)
	buttonShowAnimal:setLastFrameCallFunc(function()
		if callback ~= nil then
			callback()
		end
	end)
end
--结束选斋
function GameBaseButton:selctZhaiResult(resp_table)
	if self.Panel_select_zhai ~= nil then
		self:updateShowButton()
	end
	if resp_table.zhai ~= nil then
		if self.Image_logZhai ~= nil then
			self.Image_logZhai:setVisible(true)
			self.Image_logZhai:removeAllChildren()
			local path = "gameres/csb/actionNoZhai.csb"
			if resp_table.zhai == true then
				path = "gameres/csb/actionZhai.csb"
			end
			local loadinganimlaction = cc.CSLoader:createTimeline(path)
			local loadinganimlNode = cc.CSLoader:createNode(path)
			loadinganimlNode:runAction(loadinganimlaction)
			loadinganimlaction:gotoFrameAndPlay(0,false)
			--loadinganimlNode:setPosition(WinSize.width/2,WinSize.height/2)
			self.Image_logZhai:addChild(loadinganimlNode)
			loadinganimlaction:setLastFrameCallFunc(function()
				--loadinganimlNode:removeFromParent()
			end)
		end
	end
end
function GameBaseButton:changeZhaiResult(isZhai)
	if self.Image_logZhai ~= nil then
		self.Image_logZhai:setVisible(true)
		self.Image_logZhai:removeAllChildren()
		local path = "gameres/csb/actionNoZhai.csb"
		if isZhai == true then
			path = "gameres/csb/actionZhai.csb"
		end
		local loadinganimlaction = cc.CSLoader:createTimeline(path)
		local loadinganimlNode = cc.CSLoader:createNode(path)
		loadinganimlNode:runAction(loadinganimlaction)
		loadinganimlaction:gotoFrameAndPlay(0,false)
		--loadinganimlNode:setPosition(WinSize.width/2,WinSize.height/2)
		self.Image_logZhai:addChild(loadinganimlNode)
		loadinganimlaction:setLastFrameCallFunc(function()
			--loadinganimlNode:removeFromParent()
		end)
	end
end
--[[180_92,data:{"jiaofenStation":1,"m_TouziJiaofenTime":15,"userFenData":[{"chair":0,
"jiaofenDian":4,"jiaofenNum":3},{"chair":1,"jiaofenDian":0,"jiaofenNum":0}]}
--]]
--增加了六个按钮的控制
--[[jiaofenJson["isKai"]=isJiaoKai();
	jiaofenJson["isKai2"]=isJiaoKai2();
	jiaofenJson["isPi"]=isJiaoPi();
	jiaofenJson["isPi2"]=isJiaoPi2();
	jiaofenJson["isFen"]=isJiaoFen();
	jiaofenJson["isFenAdd1"]=isJiaoAdd1();]]
--开始叫分
function GameBaseButton:start_jiaofen(resp_table)
	self.jiaofenLimit = resp_table
	--self.Panel_select_jiao:setVisible(false)
	self:updateShowButton()
	if resp_table.jiaofenStation == self.parent:getSelfInfo().bDeskStation then
		self:updateShowButton("Panel_select_jiao")
		self:updateJiaofenButton(self.jiaofenLimit)
		--隐藏弹出的数字
		local Image_numbg = seekNodeByName(self.Panel_select_jiao,"Image_numbg")
		if Image_numbg ~= nil then
			Image_numbg:setVisible(false)
		end
		if self.jiaofenLimit ~= nil then
			local minNum = tonumber(self.jiaofenLimit.lessAnNum)
			local minDianNum = tonumber(self.jiaofenLimit.lessDianNum)
			local maxNum = tonumber(self.jiaofenLimit.maxAnNum)
			if minNum>=maxNum then
				--self.ImageJiao1:setVisible(false)
			end
		end
	else
		--如果未坐下，直接返回
		if self.parent:isAlreadySitdown() == false then
			return
		end
		--#(resp_table.userFenData)>2当2个人以上的时候，才可以抢劈
		if resp_table ~= nil and resp_table.userFenData ~= nil and #(resp_table.userFenData)>2 then
			local userDatafen = resp_table.userFenData;
			local serviceisQiangpi = resp_table.isQiangpi;
			if serviceisQiangpi ~= nil and serviceisQiangpi == false  then
				return;
			end
			local isqiangPi = false;
			for i = 1,#userDatafen do
				if userDatafen[i]~= nila and userDatafen[i].jiaofenDian>0 and userDatafen[i].jiaofenNum>0 
					and userDatafen[i].chair ~= self.parent:getSelfInfo().bDeskStation then
					isqiangPi = true;
					break;
				end
			end
			if isqiangPi then
				self:updateShowButton("Panel_qiangpi")
			end
		end
	end
end
--收到玩家劈的消息
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_chair" = 0
        }
    }
    "m_TouziJiaofenTime" = 15
    "piUser"             = 1
}]]
function GameBaseButton:response_receive_pi(resp_json)
	self:updateShowButton()
	self.Panel_select_jiao:setVisible(false)
	self.Panel_select_beipi:setVisible(false)
	if resp_json ~= nil and resp_json.beiPiUser ~= nil and #(resp_json.beiPiUser) > 0 then
		if self:isMyselfBeiPi(resp_json.beiPiUser) then
			--.Panel_select_beipi:setVisible(true)
			--执行当前按钮显示动画
			--self:showButtonAnimal(self.Panel_select_beipi,0,55)
			self:updateShowButton("Panel_select_beipi")
			
		end
	end
end

function GameBaseButton:isMyselfBeiPi(beiPiData)
	if beiPiData == nil or #beiPiData<1 then
		return false;
	end
	local myselfInfo = self.parent:getSelfInfo();
	for i = 1,#beiPiData do
		if myselfInfo.bDeskStation == beiPiData[i].beikai_chair then
			return true;
		end
	end
	return false;
end
--收到用户被劈后的回应
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_beilv" = 0
            "beikai_chair" = 2
			"beikai_isAction"=0//是否已经操作
        }
        2 = {
            "beikai_beilv" = 4
            "beikai_chair" = 1
			"beikai_isAction"=1
        }
    }
    "piUser"    = 0
}]]
function GameBaseButton:response_Pi_kai(resp_json)
	--self.Panel_select_jiao:setVisible(false)
	--self.Panel_select_beipi:setVisible(false)
	if resp_json ~= nil and resp_json.beiPiUser ~= nil and #resp_json.beiPiUser>0 then
		local myselfInfo = self.parent:getSelfInfo();
		for i = 1,#resp_json.beiPiUser do
			if resp_json.beiPiUser[i].beikai_chair == myselfInfo.bDeskStation then
				if resp_json.beiPiUser[i].beikai_beilv>0 and resp_json.beiPiUser[i].beikai_isAction>0 then
					self:updateShowButton()
				end
			else
				--self:updateShowButton()
			end
		end
	end
	
end

function GameBaseButton:start_KaiResult(resp_table)
	--self.Panel_select_jiao:setVisible(false)
	self:updateShowButton()
end
--断线重连
function GameBaseButton:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().gameUnStartStation or
		resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE  then
		print("GameBaseButton  等待开始")
		self:updateShowButton("Panel_start")
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_YAOTOUZI then
		print("GameBaseButton  摇骰子状态")
		self:updateShowButton("Panel_roundType")
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_XUANZHAI then
		print("GameBaseButton 选斋状态")
		self:updateShowButton()
		if resp_json.NtStation == self.parent:getSelfInfo().bDeskStation then
			self:updateShowButton("Panel_select_zhai")
		end
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_JIAOFEN then
		print("GameBaseButton 叫分状态")
		if resp_json.jiaofenStation == self.parent:getSelfInfo().bDeskStation then
			self:updateShowButton("Panel_select_jiao")
			self.jiaofenLimit=resp_json
		else
			self:updateShowButton()
			--如果不是自己叫分，如果已经有人叫分了，可以进行抢劈
			if resp_table ~= nil and resp_table.userFenData ~= nil and #(resp_table.userFenData)>2 then
				local userDatafen = resp_table.userFenData;
				local serviceisQiangpi = resp_table.isQiangpi;
				if serviceisQiangpi ~= nil and serviceisQiangpi == false  then
					return;
				end
				local isqiangPi = false;
				for i = 1,#userDatafen do
					if userDatafen[i]~= nila and userDatafen[i].jiaofenDian>0 and userDatafen[i].jiaofenNum>0 
						and userDatafen[i].chair ~= self.parent:getSelfInfo().bDeskStation then
						isqiangPi = true;
						break;
					end
				end
				if isqiangPi then
					self:updateShowButton("Panel_qiangpi")
				end
			end
		end
	elseif resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_PI then
		print("GameBaseButton pi状态")
		self:updateShowButton()
		if resp_json ~= nil and resp_json.beiPiUser ~= nil and #(resp_json.beiPiUser) > 0 then
			if self:isMyselfBeiPi(resp_json.beiPiUser) then
				self:updateShowButton("Panel_select_beipi")
			end
		end
	end
end

return GameBaseButton


--endregion
