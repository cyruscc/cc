--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
require("app/platform/game/80002800/handleGameMessage")

--local GameScene = import(".view.GameScene")
local GameSceneModule = class("GameSceneModule")
local GameMessage_MainID = 180

local TouziGameStation={
	gameUnStartStation=0,--游戏未开始状态
	GS_WAIT_ARGEE = 1,---等待开始状态
	gameResultStation=19,
}

local Table_GameMessage_ASSID = 
{
    --消息接收和发送ID相同
    T_GAME_READY_TIMER_CANCEL = 47,--准备倒计时取消
    T_GAME_READY_TIMER = 48,		--准备倒计时
	
    T_PLAYER_READY = 49,			--玩家准备
	ASS_SHAIZI_JIAOZHAI = 90,         --玩家开始叫斋
	ASS_SHAIZI_JIAOZHAI_RSP = 91,        --玩家开始叫斋
	ASS_SHAIZI_JIAOFEN == 92,           --玩家开始叫分
	ASS_SHAIZI_ADDFEN=93,               --玩家叫分返回
	ASS_SHAIZI_QIANGPI=94,               --发送的抢劈命令
	ASS_SHAIZI_Kai=95,               --玩家叫开
	ASS_SHAIZI_Pi=96,               --玩家叫劈
	ASS_SHAIZI_Pi_Kai = 97,         --被劈的人叫的开或者反劈
	ASS_YAODONG_START = 56,        --通知服务器，玩家已经摇动完毕
	
    T_GAME_START = 51,--游戏开始
    T_GAME_BANKER_NOTIFY = 52,--通知玩家叫庄
    T_PLAYER_BANKER = 53,--玩家叫庄
    T_GAME_BANKER_END = 54,--叫庄结束
    --T_GAME_BANKER_RAND = 62,--随机庄
    T_GAME_BET_NOTIFY = 55,--通知玩家下注
    --T_PLAYER_BET = 56,--玩家下注
    T_GAME_CARD_SEND = 57,--发牌
    T_GAME_CARD_OPEN = 59,--开始开牌
    T_PLAYER_CARD_OPEN = 60,--玩家开牌
    T_GAME_END = 61,--结算
    T_GAME_RECORD = 62 , --游戏结束战绩
    T_GAME_REBIND = 2,--断线重连
    T_PLAYER_POINT_LEASE = 210
}
function GameSceneModule:getInstance()
    if not self.GameSceneModule then
       self.GameSceneModule = self.new()
    end
    return self.GameSceneModule
end

function GameSceneModule:onDestroy()
    --self.GameSceneModule = nil
end

function GameSceneModule:init(GameScene)
    self.GameScene = GameScene
    --print("*********************************dong test setGameMessageHandler = 1111")
    handleGameMessage.setGameMessageHandler(self)
end

function GameSceneModule:getGameScene()
    return self.GameScene
end

--测试消息回调
function GameSceneModule:response_game_test(resp_json)
    print("dong test msg response")
    local result = resp_json.result
    print("add result is " .. result)
end

--通知玩家准备，显示倒计时，进行准备
function GameSceneModule:resp_gameReady(resp_json)    
    --dump(resp_json,"resp_json")
	if self.GameScene ~= nil and self.GameScene.resp_gameReady ~= nil then
		self.GameScene:resp_gameReady(resp_json)
	end
end
    --玩家准备
function GameSceneModule:request_player_ready()    
    local request = {}
    request.chair  = self:getGameScene():getSelfInfo().bDeskStation
    self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.T_PLAYER_READY, request)

    print("玩家请求准备------------------------------------------------------------------------------%d", request.chair)

end
    --收到玩家准备
function GameSceneModule:resq_player_ready(resp_json)    
    self.GameScene:resp_player_ready(resp_json)
end
--通知服务器，摇动完毕
function GameSceneModule:request_player_rockOver()    
    local request = {}
    request.chair  = self:getGameScene():getSelfInfo().bDeskStation
    self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_YAODONG_START, request)

    print("玩家请求准备------------------------------------------------------------------------------%d", request.chair)

end
--游戏开始
function GameSceneModule:response_game_start(resp_json)

    print("------------------------------------------GameSceneModule:response_game_start recv game start")
    ROUND_CURRENT = resp_json.ROUNT_CURRENT
    self.GameScene:game_start(resp_json)
end

--发牌	
function GameSceneModule:response_game_card_send(resp_json)
    local resp_table = {}
    for i=1, #resp_json do
        local user_json = resp_json[i]
        local resp_user_crad = {}
        for j=1, #user_json.cards do
           resp_user_crad[j] = user_json.cards[j]
        end
        resp_table[user_json.chair]=resp_user_crad
    end
    self.GameScene:game_card_send(resp_table)
end
--服务器下发选择叫斋{"m_TouziJiaoZhaiTime":20}
function GameSceneModule:response_game_selectZhai(resp_table)
	self.GameScene:game_selectZhai(resp_table)
end
--向服务器发送选择斋的结果
function GameSceneModule:send_game_selectZhai(isZhai)
	if isZhai == nil then isZhai= false end
	
	local request = {}
	request.zhai = 0;
	if isZhai == true then
		request.zhai = 1;
	end
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_JIAOZHAI_RSP, request)
end
--收到某人选择斋
function GameSceneModule:response_User_selectZhai(resp_table)
	
	self:getGameScene():User_selectZhai(resp_table)
end
--收到叫分消息 
--[[180_92,data:{"jiaofenStation":1,"m_TouziJiaofenTime":15,"userFenData":[{"chair":0,
"jiaofenDian":4,"jiaofenNum":3},{"chair":1,"jiaofenDian":0,"jiaofenNum":0}]}
--]]
function GameSceneModule:response_start_jiaofen(resp_table)
	
	self:getGameScene():start_jiaofen(resp_table)
end
function GameSceneModule:response_jiaofen_resp(resp_table)
	self:getGameScene():response_jiaofen_resp(resp_table)
end
--叫分+1
--[[{
	"addFenType":1,--1需要有另外两个字段，2，+1叫分模式，
	"addAnNum":4,
	"addDianNum"：5----代表4个5
}]]
function GameSceneModule:response_Add1()
	local request = {}
	request.addFenType = 2
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_ADDFEN,request)
end
function GameSceneModule:response_AddFen(addAnNum,addDianNum)
	local request = {}
	request.addFenType = 1
	request.addAnNum = addAnNum
	request.addDianNum = addDianNum
	
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_ADDFEN,request)
end
--开
function GameSceneModule:response_Kai()
	local request = {}
	request.kaiType = 1
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_Kai,request)
end
--开两家
function GameSceneModule:response_Kai2(data)
	local request = {}
	request.kaiType = 2
	--request.kaiData = data
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_Kai,request)
end
function GameSceneModule:response_userSelectKai(resp_table)
	self:getGameScene():response_userSelectKai(resp_table);
end
--发送抢劈命令
function GameSceneModule:request_qiangpi()
	local request = {}
	request.kaiType = 1
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_QIANGPI,request)
end
--劈2家，如果data为nil，进行劈一家，如果有值，进行劈两家的操作
function GameSceneModule:request_Pi()
	local request = {}
	request.piType = 1
	--[[if data == nil then
		request.piType = 1
		dump(data,"pi data:")
	end]]
	--request.piData = data;
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_Pi,request)
end
function GameSceneModule:request_Pi2()
	local request = {}
	request.piType = 2
	
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_Pi,request)
end
--收到劈的消息
--[["<var>" = {
    "beiPiUser" = {
        1 = {
            "beikai_chair" = 0
        }
    }
    "m_TouziJiaofenTime" = 15
    "piUser"             = 1
}]]
function GameSceneModule:response_Pi(resp_json)
	self:getGameScene():response_receive_pi(resp_json);
end
--被劈后的Type，如果piType ：1，直接进行开，如果piType：2 是反劈
function GameSceneModule:request_pi_kai(type)
	local request = {}
	request.piType = type
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_SHAIZI_Pi_Kai,request)
end
--被劈后，玩家的回应
function GameSceneModule:response_Pi_kai(resp_json)
	self:getGameScene():response_Pi_kai(resp_json)
end
--开骰子消息
function GameSceneModule:response_player_card_open(resp_json)
	self:response_game_card_send(resp_json)
end
--[[
	 ---------------------------------------- recv json : 180_103,data:
	{"kaiJson":{"kai_object":[{"beikai_station":0,"beikai_totalDian":6,"beikai_totalNum":6}],"kai_station":1},
	 "resultJson":[{"cards":[6,5,5,1,5],"chair":0,"scoreChange":2},{"cards":[3,5,5,6,2],"chair":1,"scoreChange":-2}]}
	[{
        "cards": [4, 3, 4,5,6],
        "chair": 0,
        "scoreChange": 1
    },{
        "cards": [5, 6, 2, 1,5],
        "chair": 1,
        "scoreChange": -1
    }]
]]
function GameSceneModule:response_result(resp_json)
	self:getGameScene():start_KaiResult(resp_json)
end

--游戏局数完成，显示战绩
function GameSceneModule:response_showOver(resp_json)
	self.GameScene:response_showOver(resp_json)
end
--定庄消息
function GameSceneModule:response_game_make_nt(resp_json)
    print("recieve make nt ")
    self.GameScene.GameLayer.PlayersHeadUIManager:onMakeNT(resp_json)
    self.GameScene.GameLayer.MenuManager:onMakeNT()
    print("GameSceneModule make nt  over")
end

--下发手牌牌
function GameSceneModule:response_game_fetch_handcards(resp_json)
    print("recieve cards ")
    print("resp_json.CardNum = " .. resp_json.CardNum)

    self.GameScene.GameLayer.HandCardUIManager:onFetchCards(resp_json.Cards)
    self.GameScene.GameLayer.MenuManager:onFetchCards(resp_json)
    self.GameScene.GameLayer.PlayersHeadUIManager:onFetchCards(resp_json)
    self.GameScene.GameLayer.GameBaseUIManager:onFetchCards(resp_json)
end


--庄家跳牌
function GameSceneModule:response_game_tiao_cards(resp_json)
    --print("recieve tiao cards : " .. resp_json.tiaoFetch )
    --庄家抓一张跳牌
    self.GameScene.GameLayer.HandCardUIManager:onTiaoCards(resp_json)
    self.GameScene.GameLayer.GameBaseUIManager:onTiaoCards(resp_json)
end

--某个玩家拿到令牌
function GameSceneModule:response_game_token(resp_json)
    print(" get token by = "..resp_json.TokenbyUser)
    self.GameScene.GameLayer.OutCardUIManager:onGetToken(resp_json)
    self.GameScene.GameLayer.HandCardUIManager:onGetToken(resp_json)
    self.GameScene.GameLayer.GameBaseUIManager:onGetToken(resp_json)
    self.GameScene.GameLayer.PlayersHeadUIManager:onGetToken(resp_json)
end

--玩家收到可以执行的动作(吃碰杠胡牌)
function GameSceneModule:response_game_act_notify(resp_json)
    print("recieve act notify")
    self.GameScene.GameLayer.ChiPengUIManager:onActNotify(resp_json)
    self.GameScene.GameLayer.OutCardUIManager:onActNotify(resp_json)

end


--玩家收到执行某个动作的结果(吃碰杠胡牌)
function GameSceneModule:response_game_act_info(resp_json)
    print("---------------暗杠------------------------")
    print("recieve act info resp_json.usActFlag = " .. resp_json.usActFlag)
    self.GameScene.GameLayer.OutCardUIManager:onActInfo(resp_json)
    self.GameScene.GameLayer.HandCardUIManager:onActInfo(resp_json)
    self.GameScene.GameLayer.GameBaseUIManager:onActInfo(resp_json)
    self.GameScene.GameLayer.PlayersHeadUIManager:onActInfo(resp_json)
    print("recieve act info end")
end


--某玩家的出牌结果
function GameSceneModule:response_game_out_card_info(resp_json)
    print("recieve outcardinfo : ")
    self.GameScene.GameLayer.OutCardUIManager:onOutCardInfo(resp_json)
    self.GameScene.GameLayer.HandCardUIManager:onOutCardInfo(resp_json)
    self.GameScene.GameLayer.PlayersHeadUIManager:onOutCardInfo(resp_json)
    self.GameScene.GameLayer.GameBaseUIManager:onOutCardInfo(resp_json)
end

--回合结束
function GameSceneModule:response_game_round_finish(resp_json)
    print("recv round finish")
    self.GameStation = GameStation.GS_WAIT_NEXT_ROUND
    self.GameScene.GameLayer.OutCardUIManager:onRoundFinish(resp_json)
    self.GameScene.GameLayer.HandCardUIManager:onRoundFinish(resp_json)
end


--断线重连
function GameSceneModule:response_game_station(resp_json)
    --dump(resp_json)
	
	if resp_json.GameStation ~= nil then
		self.GameStation = resp_json.GameStation
	end
	--self.GameScene:game_rebind(resp_json)
    --各层断线重连
	self.GameScene:onGameStation(resp_json)
end

--获取当前游戏状态
function GameSceneModule:getGameStation()
    return self.GameStation
end
return GameSceneModule

--endregion
