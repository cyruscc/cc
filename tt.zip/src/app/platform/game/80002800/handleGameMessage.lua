--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

module("handleGameMessage", package.seeall)
local GameMessage_MainID = 180


Table_GameMessage_ASSID = 
{
    T_DONG_TEST_SEND = 66,                  --dong测试消息
	ASS_GAME_BEGIN   = 51,                  --游戏开始
	
	ASS_NOTE_READY	 =48,				--通知玩家准备
	T_PLAYER_READY = 49,			--玩家准备
	ASS_SHAIZI_JIAOZHAI = 90,              --庄家开始叫斋
	ASS_SHAIZI_JIAOZHAI_RSP = 91,              --庄家开始叫斋
	ASS_SHAIZI_JIAOFEN  = 92,              --庄家开始叫分
	--ASS_SHAIZI_QIANGPI  = 94,              --收到抢劈消息
	ASS_SHAIZI_Kai      = 95,              --收到用户开的消息
	ASS_SHAIZI_Pi       = 96,              --收到劈消息
	ASS_SHAIZI_Pi_Kai   = 97,              --收到反劈或者劈开的消息
	ASS_SHAIZI_JIAOFEN_RSP = 98,           --收到叫分消息
	ASS_SHAIZI_RESULT = 103,			

	T_GAME_CARD_SEND = 57,                  --发牌
	T_GAME_CARD_OPEN = 59,--开始开牌
    T_PLAYER_CARD_OPEN = 60,--玩家开牌
    ASS_DHTZ_CONTINUE_END = 61,--开始准备下一局
    T_GAME_RECORD = 62 , --游戏结束战绩
	
	ASS_CONTINUE_END = 84,                  --游戏结束
    T_PLAYER_POINT_LEASE = 210,
	
    ASS_GM_GAME_STATION = 2                     --断线重连

}

local Table_Action_Handler = {}

local Local_handler = nil

function setGameMessageHandler(handler)

	Local_handler = handler
   
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_NOTE_READY] = handler.resp_gameReady
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_GAME_BEGIN] = handler.response_game_start
	Table_Action_Handler[Table_GameMessage_ASSID.T_PLAYER_READY] = handler.resq_player_ready
	Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_CARD_SEND] = handler.response_game_card_send
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_JIAOZHAI] = handler.response_game_selectZhai
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_JIAOZHAI_RSP] = handler.response_User_selectZhai
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_JIAOFEN] = handler.response_start_jiaofen
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_JIAOFEN_RSP] = handler.response_jiaofen_resp
	--Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_QIANGPI] = handler.response_qiangpi	
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_Kai] = handler.response_userSelectKai
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_Pi] = handler.response_Pi	
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_Pi_Kai] = handler.response_Pi_kai	

	Table_Action_Handler[Table_GameMessage_ASSID.ASS_CONTINUE_END] = handler.response_player_card_open
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SHAIZI_RESULT] = handler.response_result
	
	Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_RECORD] = handler.response_showOver
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_DHTZ_CONTINUE_END] = handler.resp_gameReady
		
	--断线重连
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_GM_GAME_STATION] = handler.response_game_station
	
	
end

--处理服务器发来的消息
function HandleGameMessage( AssistantID, json_value )
   print("-------AssistantID = "..AssistantID)
   if Table_Action_Handler[AssistantID]~=nil then
      Table_Action_Handler[AssistantID](Local_handler, json_value)
   else
        print("----Table_Action_Handler["..AssistantID.."]---nil")
   end
end

--客户端发送消息
--[[function SendGameMessage(AssistantID, request)
    print("send mj game message AssistantID = " .. AssistantID)
--    if not request then
--       request ={}
--    end
--    g_server_obj:send_game_server_msg(GameMessage_MainID, AssistantID, 0, true , request)

    GameSceneModule:getInstance():getGameScene():getHelper():sendGameMessage(AssistantID, request)

end
--]]

--endregion
