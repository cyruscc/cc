--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameFireLayer = class("GameFireLayer")

function GameFireLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.Panelfire={}
	self.PanelAll = {}
	self:init()
	self.PanelfireAction={}
end

function GameFireLayer:init()
	--print("self.playerCount:"..self.playerCount)
	for i = 1,self.playerCount do
		local Panel_fire = seekNodeByName(self.rootNode,"Panel_fire"..i)
		--print("i:"..i)
		Panel_fire:setVisible(false)
		
		
		table.insert(self.Panelfire,i,Panel_fire)
	end
	self.PanelAll = seekNodeByName(self.rootNode,"Panel_fireall")
	self.PanelAll:setVisible(false)
	performWithDelay(self.rootNode,function()
		self:loadingAction()
	end,1)
end
--加载动画
function GameFireLayer:loadingAction()
	for i = 1,self.playerCount do
		local loadinganimlaction = cc.CSLoader:createTimeline("action/fire_1.csb")
		local actionNode = seekNodeByName(self.Panelfire[i],"FileNode_3")
		actionNode:runAction(loadinganimlaction)
		loadinganimlaction:gotoFrameAndPlay(0,true)
		loadinganimlaction:setTimeSpeed(24/60)
	end
	local loadinganimlaction = cc.CSLoader:createTimeline("action/fire_all.csb")
	local actionNodeAll = seekNodeByName(self.PanelAll,"FileNode_2")
	
	actionNodeAll:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,true)
	loadinganimlaction:setTimeSpeed(24/60)
end
--灭掉所有火
function GameFireLayer:closeAll()
	for i = 1,self.playerCount do
		self.Panelfire[i]:setVisible(false)
	end
end
function GameFireLayer:getFirePosition(chair)
	if chair == nil or chair<0 or chair >self.playerCount then
		return;
	end
	local userViewChair = self.parent:getHelper():DeskStation2View(chair);
	return self.Panelfire[userViewChair]:getPosition()
end
--每个玩家头上的小火
function GameFireLayer:showFire(chair,isShow)
	local userViewChair = self.parent:getHelper():DeskStation2View(chair);
	if isShow == true then
		if self.Panelfire[userViewChair]:isVisible() == true then
			return;
		end
		self.Panelfire[userViewChair]:setVisible(true)
		
	else
		self.Panelfire[userViewChair]:setVisible(false)
	end
end
--整个场景的大火
function GameFireLayer:showFireRound(isShow)
	if isShow == true then
		if self.PanelAll:isVisible() == true then
			return;
		end
		self.PanelAll:setVisible(true)
		--self.parent.music:playNormalVoice("huopinbgm")
		self.parent.music:playFireAllMusic()
	else
		self.parent.music:stopFireAllMusic()
		self.PanelAll:setVisible(false)
	end
	
end
--下注消息
function GameFireLayer:response_startXiazhu(resp_json)
	if resp_json ~= nil and resp_json.iTurnNum ~= nil and resp_json.chairinfo ~= nil then
		local turnNum = resp_json.iTurnNum;
		if turnNum>=4 then
			self:showFireRound(true)
		end
		if turnNum>=5 then
			local player = resp_json.chairinfo
			for i = 1,#player do
				if player[i].chair ~= nil and player[i].userdiu ~= nil and player[i].userdiu==0 then
					self:showFire(player[i].chair,true)
				else
					self:showFire(player[i].chair,false)
				end
			end
		end
	end
end
--本局结算
function GameFireLayer:response_showOver(resp_json)
	self:showFireRound(false)
	self:closeAll();
	local winPlayer = {};
	if  resp_json ~= nil and resp_json.winPlayer ~= nil then
		--winPlayer = resp_json.winPlayer
		table.insert(winPlayer,resp_json.winPlayer)
	end
	if resp_json ~= nil and resp_json.winPlayerlist ~= nil and #resp_json.winPlayerlist>0 then
		winPlayer={}
		for i = 1,#resp_json.winPlayerlist do
			table.insert(winPlayer,resp_json.winPlayerlist[i])
		end
	end
	dump(winPlayer,"winPlayer:")
	--更加当前数据，显示赢家的牌型
	if winPlayer ~= nil and #winPlayer>0 then
		for i = 1,#winPlayer do
			local cards = resp_json.cards
			local cardType = self:getCardTypeByWinPalyer(cards,winPlayer[i])
			if cardType ~= nil then
				local jiesuanaction = cc.CSLoader:createTimeline("action/jiesuan.csb")
				local actionNode = cc.CSLoader:createNode("action/jiesuan.csb")
				actionNode:runAction(jiesuanaction)
				jiesuanaction:gotoFrameAndPlay(0,false)
				jiesuanaction:setTimeSpeed(24/60)
				jiesuanaction:setLastFrameCallFunc(function()
					actionNode:removeFromParent();
				end)
				--更新当前赢家的牌型
				local cardTypeItem = seekNodeByName(actionNode,"cardType")
				if cardType ~= nil then
					cardTypeItem:loadTexture(string.format("res/cardtype/cardType%d.png",cardType))
				else
					cardTypeItem:setVisible(false)
				end
				--更新赢的筹码数
				local winMoney = seekNodeByName(actionNode,"winMoney")
				if resp_json.winMoney ~= nil then
					winMoney:setString("."..resp_json.winMoney)
				else
					winMoney:setVisible(false)
				end
				local pointx,pointy = self:getFirePosition(winPlayer[i])
				pointx = pointx+10;
				actionNode:setPosition(cc.p(pointx,pointy))
				self.parent:addChild(actionNode)
			end
		end
	end
end

--更加数据获取当前赢家的牌型
function GameFireLayer:getCardTypeByWinPalyer(baseData,winPlayer)
	if baseData ~= nil and #baseData>0 and winPlayer ~= nil then
		for i = 1,#baseData do
			if baseData[i].chair ~= nil and baseData[i].chair == winPlayer then
				return baseData[i].cardtype
			end
		end
	end
	return nil
end
return GameFireLayer


--endregion
