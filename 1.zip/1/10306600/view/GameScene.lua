--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local gameHelper=import("..gameHelper")
local GameBaseLayer = import(".GameBaseLayer")
local GameBaseButton = import(".GameBaseButton")
local GamePlayerLayer = import(".GamePlayerLayer")

local TimerUIManager = import(".TimerUIManager")

local GameReadyLayer = import(".GameReadyLayer")
local GameMusic = import(".GameMusic")
local GameSceneModule = import("..gameSceneModule")
local GameSceneBase = import("...GameSceneBase")
local GameChairLayer = import(".GameChairLayer")
local GamePlayerCoinLayer = import(".GamePlayerCoinLayer")
local GameCardLayer = import(".GameCardLayer")
local GameStartLayer = import(".GameStartLayer")
local GameCardHandle = import(".GameCardHandle")
--local GameResultLayer = import(".GameResultLayer")
local GameOverLayer = import(".GameOverLayer")
local GameFireLayer = import(".GameFireLayer")
local GameRoomInfoLayer = import(".GameRoomInfoLayer")
local GameMaskAddNumCoinLayer = import(".GameMaskAddNumCoinLayer")
local GameAddCoinLayer = import(".GameAddCoinLayer")
local GameTimeLayer = import(".GameTimeLayer")

local m_download = import("....common.download")

local TouziGameStationEnum={
	gameUnStartStation=0,--游戏未开始状态
	GS_WAIT_ARGEE = 1,---等待开始状态
	GS_XIAZHU	  = 4,				--下注状态
	GS_WAIT_NEXT = 8,   --等待进入下一局
}
local gameType = {
	gameType_qz1="qz1",
	gameType_tz1="tz1",
}
local GameScene = class("GameScene" , GameSceneBase)
function GameScene:ctor()
	self:onCreate()
end
function GameScene:onCreate()
	cc.FileUtils:getInstance():addSearchPath(cc.FileUtils:getInstance():getWritablePath().."upd/res/game_res/10306600/",true)
	cc.FileUtils:getInstance():addSearchPath(cc.FileUtils:getInstance():getWritablePath().."res/game_res/10306600/",true)
	cc.FileUtils:getInstance():addSearchPath("upd/res/game_res/10306600/",true)
	cc.FileUtils:getInstance():addSearchPath("res/game_res/10306600/",true)
	
    self.gameStation = 0
	--当前每个人牌的个数
	self.userCardNum = 3;
	--用户当前是否弃牌
	self.userIsQi = false;
    self:registered_child(self)
	self.desk_index = 0;
	--保存我自己的座位号，默认为0
	self.myselfPosition = 0;
    GameSceneModule:getInstance():init(self)
	self.music = GameMusic.new(self)
	local mainscenePaht = "game/gameLayer.csb"
	local mainsceneNode = cc.CSLoader:createNode(mainscenePaht)
	self.rootNode = mainsceneNode
	self:addChild(mainsceneNode)
	
	self.gameBaseLayer = GameBaseLayer.new(self,seekNodeByName(mainsceneNode,"Panel_base"))
	self.gameChairLayer = GameChairLayer.new(self,seekNodeByName(mainsceneNode,"Panel_zuoyi"))
		
	self.gamePlayerLayer = GamePlayerLayer.new(self,seekNodeByName(mainsceneNode,"Panel_player"))
	self.gamePlayerCoinLayer = GamePlayerCoinLayer.new(self,seekNodeByName(mainsceneNode,"Panel_jinbi"))
	
	self.gameBaseButton = GameBaseButton.new(self,seekNodeByName(mainsceneNode,"Panel_button"))
	self.gameCardLayer = GameCardLayer.new(self,seekNodeByName(mainsceneNode,"Panel_card"))
	self.gameStartLayer = GameStartLayer.new(self,seekNodeByName(mainsceneNode,"Panel_start"))
	self.gameReadyLayer = GameReadyLayer.new(self,seekNodeByName(mainsceneNode,"Panel_ready"))
	self.gameCardHandle = GameCardHandle.new(self,seekNodeByName(mainsceneNode,"Panel_cardHandle"))
	self.gameFireLayer = GameFireLayer.new(self,seekNodeByName(mainsceneNode,"Panel_fire"))
	self.gameTimeLayer = GameTimeLayer.new(self,seekNodeByName(mainsceneNode,"Panel_time"))
	
	--修改当前背景桌布
	self:updateSceneBg()

    self:registerScriptHandler(handler(self,self.onNodeEvent))
	self.userList={}
	--pos_list , scale , max_count , zorder )
	local pos_list={
		cc.p(625,307),
		cc.p(1100,390),
		cc.p(860,450),
		cc.p(410,450),
		cc.p(170,430)}
	
	self:initExpression(pos_list,1.0,15)
	--pos_list ,direction_list , quick_text_list , max_width , scale  , zorder)
	local pos_list2={
		cc.p(625,307),
		cc.p(1100,390),
		cc.p(860,450),
		cc.p(410,450),
		cc.p(170,430)}
	local direction_list = {4,2,2,4,4}
	local list = {"不要偷鸡，我的牌很大哦。",
				"冲动是魔鬼，冷静。",
				"别看牌，我们闷到底。",
				"大家好，很高兴见到各位",
				"不要走，决战到天亮。",
				"交个朋友吧，以后一起打牌",
				"你的牌打的也忒好了。",
				"青山不改，绿水长流，后会有期",
	}
	self:initChatText(pos_list2,direction_list,list,200)
	
	self.isSendSitUp = false
	--是否是首轮
	self.isFirstGame = false;
	--]]
	math.randomseed(os.time())
	--当前游戏中的玩家
	self.playerData = {};
end

function GameScene:updateSceneBg()
	local bgColor = UserData:getBgColor();
	local ImageBg = seekNodeByName(self.rootNode,"Image_bg")
	if bgColor == 1 then
		ImageBg:loadTexture("res/bg.png")
	else
		ImageBg:loadTexture("res/bg01.png")
	end
end
function GameScene:updateSceneCardBg()
	self.gameCardLayer:updateCardBg()
end
function GameScene:getGameStationEnum()
	return TouziGameStationEnum;
end
function GameScene:getGameTouziLayer()
	return self.gameTouziLayer
end
function GameScene:getUserTouziNum()
	return self.userTouziNum;
end
function GameScene:getGameStation()
	return self.gameStation;
end
function GameScene:getGameTypeEnum()
	return gameType;
end
function GameScene:isQzProject()
	return self:getGameType() == gameType.gameType_qz1;
end
function GameScene:getIsFirstGame()
	return self.isFirstGame;
end
--给player层级增加头像点击监听回调
function GameScene:setPlayerClickCallBack(callback)
	self.gamePlayerLayer:selectPlayerCallBack(callback)
end
function GameScene:setDeskPlayerHeadImage()
    for key, var in pairs(self.super:getSitDownPlayerMap()) do
        self.GameLayer.MenuManager:setPlayerHeadImage(var)  
    end
end
function GameScene:getViewPosition(bdestStation)
	return self:getHelper():DeskStation2View(tonumber(bdestStation))
end
function GameScene:gameProformDelay(time,callback)
	performWithDelay(self.rootNode,function ()
			if callback ~= nil then
				callback()
			end
		end,time)
end
--获得当前游戏中人员
function GameScene:getNowPlayer()
	return self.playerData
end
--检查当前用户是否在游戏中
function GameScene:checkUserInGame(chair)
	if self.playerData == nil or #self.playerData<1 then
		return false;
	end
	for i = 1,#self.playerData do
		if(self.playerData[i].chair == chair) then
			return true;
		end
	end
	return false;
end

function GameScene:onNodeEvent(event)

    if event == "enter" then
    elseif event == "exit" then
		--self.gameTimeLayer:stopTimer()
		self.gameTimeLayer:stopTimer();
    end
end
--@param index 快速文字的下标
function GameScene:playQuickTextSound( text_index , user_info)
	self.music:playNormalVoice("msg"..text_index,user_info.bBoy)
end
function GameScene:check_ready()
	if self.deskActive == true then
		GameSceneModule:getInstance():request_player_ready()
	else
		
	end
end
-------------------------------------------游戏消息---------------------------------------
--收到某一家准备消息
function GameScene:resp_player_ready(resp_table)
	local userinfo = self:getPlayerInfoByChairID(resp_table.chair);
	self:insertUserReady(userinfo.dwUserID)
	self.gameReadyLayer:updateUser()
	self.gameStartLayer:resp_player_ready(resp_table)
end
--收到倒计时准备，如果倒计时后未开始，用户将会被踢下线
function GameScene:noteUser_ready(resp_json)
	self.gameTimeLayer:noteUser_ready(resp_json)
	--重置客户端准备状态
	self:deleteAllUserReady();
	if resp_json ~= nil and resp_json.playerData ~= nil and #resp_json.playerData>0 then
		for i = 1,#resp_json.playerData do
			local userinfo = self:getPlayerInfoByChairID(resp_json.playerData[i].chair);
			print("userinfo.dwUserID:"..userinfo.dwUserID)
			dump(resp_json.playerData[i].bAgree,"resp_json.playerData[i].bAgree:")
			if resp_json.playerData[i].bAgree ~= nil and resp_json.playerData[i].bAgree == true then
				self:insertUserReady(userinfo.dwUserID)
			end
		end
		self.gameReadyLayer:updateUser()
	end
end
function GameScene:resp_gameReady(resp_table)
	self.gameStation=TouziGameStationEnum.gameUnStartStation
	--更新用户积分
	if resp_table ~= nil and resp_table.playerData ~= nil and #(resp_table.playerData)>0 then
		for i = 1,#(resp_table.playerData) do
			local userinfo = self:getPlayerInfoByChairID(resp_table.playerData[i].chair)
			if userinfo ~= nil then
				userinfo.dwProfit = resp_table.playerData[i].point
			end
		end
	end
	self.gamePlayerLayer:init()
	--延时0.2秒执行，因为第一次有用户进来的时候，此通知比坐下通知还要早
	self:gameProformDelay(0.2,function ()
		if resp_table ~= nil then
			if resp_table.GameStation == self:getGameStationEnum().GS_WAIT_ARGEE then
				self.gameMengban:setVisible(false)
				
				self.gameBaseLayer:init()
				self.gameBaseButton:init()
				
				self.gameTouziLayer:init()
				--self.gameResultLayer:init()
				self.gameJiaofenLayer:closeAll()
				
				self.gameBaseButton:ready(resp_table)
				if resp_table.time ~= nil then
					self.gameTimeLayer:ready(resp_table)
				end
				--self.gamePlayerLayer:ready(resp_table)
				self.deskActive = true;
				if self:isAlreadySitdown() == false then
					self.gameBaseButton:updateShowButton("Panel_sitdown")
				end
			end
		end
	end)
end

--获取当前座位号是否已经准备
function GameScene:getUserIsReady(userid)
	for i=1,#self.userList do
		if self.userList[i] == userid then
			return true;
		end
	end
	return false;
end
function GameScene:insertUserReady(userid)
	if self.userList[userid] ~= nil then
		return;
	end
	table.insert(self.userList,userid)
end
function GameScene:deleteUserReady(userid)
	for i=1,#self.userList do
		if self.userList[i] == userid then
			table.remove(self.userList,self.userList[i])
			break;
		end
	end
	print("#self.userList:"..#self.userList)
end
function GameScene:deleteAllUserReady()
	self.userList= nil
	self.userList={}
end
--[[{
    "NtStation"  = 1
    "iCurRounds" = 1
    "iDingZhu"   = 100
    "iDizhu"     = 10
    "iMaxXiaZhu" = -1163005939
    "iSkin"      = 10
    "playerData" = {
        1 = {
            "chair" = 0
            "point" = 1000
        }
        2 = {
            "chair" = 1
            "point" = 1000
        }
    }
}]]
function GameScene:game_start(resp_json)
	if self:isAlreadySitdown() == true then
		self.userIsQi = false;
	end
	--客户端保存当前参与打牌的玩家。
	self.playerData = resp_json.playerData;
	self.gameStation = TouziGameStationEnum.GS_XIAZHU
	self.gameTimeLayer:game_start(resp_json)
	--隐藏准备按钮层
	self.gameReadyLayer:game_start(resp_json)
	self.gamePlayerCoinLayer:game_start(resp_json)
	self.gameBaseLayer:game_start(resp_json)
	self.gameBaseButton:game_start(resp_json)
	self.music:playNormalVoice("fapai")
end
--下发用户手中的牌和桌上扣的筹码，手上的筹码，按钮的操作控制
--[["<var>" = {
    "CurrentXiaZhustation" = 1
    "allCountZhu"          = 20
    "chairinfo" = {
        1 = {
            card = *MAX NESTING*
            "chair"      = 0
            "point"      = 990
            "tablePoint" = 10
        }
        2 = {
            card = *MAX NESTING*
            "chair"      = 1
            "point"      = 990
            "tablePoint" = 10
        }
    }
    "isAdd"                = true
    "isBi"                 = true
    "isGen"                = true
    "isLook"               = true
    "isQi"                 = true
}]]
function GameScene:response_sendCard(resp_json)
	self.gameCardLayer:response_sendCard(resp_json)
	self.gameBaseLayer:response_sendCard(resp_json)
	self.gameBaseButton:response_sendCard(resp_json)
	self.gamePlayerCoinLayer:response_sendCard(resp_json)
end
--收到某一个玩家下注消息
function GameScene:response_startXiazhu(resp_json)
	print("======================response_startXiazhu")
	if resp_json ~= nil and resp_json.isUpdate ~= nil and resp_json.isUpdate == true then
		--如果当前是用来更新的，只控制更新按钮
		self.gameBaseButton:response_startXiazhu(resp_json)
		return
	end
	self.gameBaseLayer:response_startXiazhu(resp_json)
	self.gameBaseButton:response_startXiazhu(resp_json)
	self.gamePlayerCoinLayer:response_startXiazhu(resp_json)
	self.gameFireLayer:response_startXiazhu(resp_json)
	self.gamePlayerLayer:response_startXiazhu(resp_json)
end
--加时超时时，影响头像层
function GameScene:response_outOfXiaZhuTime(resp_json)
	self.gameTimeLayer:response_outOfXiaZhuTime(resp_json)
	self.gamePlayerLayer:response_outOfXiaZhuTime(resp_json)
	
end
function GameScene:response_outOfTimeOver(resp_json)
	self.gameTimeLayer:response_outOfTimeOver(resp_json)
	self.gamePlayerLayer:response_outOfTimeOver(resp_json)
end
--收到玩家下注或者加注消息
function GameScene:response_userXiaZhu(resp_json)
	self.gameBaseLayer:response_userXiaZhu(resp_json)
	self.gamePlayerCoinLayer:response_userXiaZhu(resp_json)
	self.gamePlayerLayer:response_userXiaZhu(resp_json)
	self.gameBaseButton:response_userXiaZhu(resp_json)
	if resp_json ~= nil and resp_json.addCoinType ~= nil then
		local chair = resp_json.CurrentXiaZhustation
		local userinfo = self:getPlayerInfoByChairID(chair)
		if resp_json.addCoinType == 0 then
			local index =  math.random(1,3)
			self.music:playNormalVoice("genzhu"..index,userinfo.bBoy)
		else
			local index =  math.random(1,4)
			self.music:playNormalVoice("jiazhu"..index,userinfo.bBoy)
		end
	end
end
--玩家看牌返回
function GameScene:response_showUserCard(resp_json)
	self.gameBaseButton:response_showUserCard(resp_json)
	self.gameCardLayer:response_showUserCard(resp_json)
end
--收到某人看牌通知
function GameScene:response_showLookCard(resp_json)
	self.gameCardHandle:response_showLookCard(resp_json)
	--self.gameBaseButton:response_showLookCard(resp_json)
	local chair = resp_json.chair
	local userinfo = self:getPlayerInfoByChairID(chair)
	self.music:playNormalVoice("kanpai",userinfo.bBoy)
end
--收到某人弃牌通知
function GameScene:response_showQiCard(resp_json)
	self.gameCardLayer:response_showQiCard(resp_json)
	self.gameCardHandle:response_showQiCard(resp_json)
	self.gamePlayerLayer:response_showQiCard(resp_json)
	local chair = resp_json.chair
	local userinfo = self:getPlayerInfoByChairID(chair)
	if self:isMyself(userinfo) == true then
		self.userIsQi = true
	end
	self.music:playNormalVoice("qipai",userinfo.bBoy)
end
--比牌返回
--[["<var>" = {
    "firstPlayer"  = 1
    "secondPlayer" = 0
    "winPlayer"    = 0
	"failPlayer"   = 1
}]]
 --[["<var>" = {
     "allCountZhu" = 36
     "firstPlayer" = 0
     "isMyWin"     = true
     "myDownMoney" = 9
     "points" = {
         1 = {
             "chair" = 0
             "point" = 0
         }
         2 = {
             "chair" = 4
             "point" = 14
         }
     }
 }
--]]
function GameScene:response_compairCard(resp_json)
	--pk动画之前，需要更新当前玩家金币
	self.gamePlayerCoinLayer:response_compairCard(resp_json)
	self.gameBaseLayer:response_compairCard(resp_json)
	self.gamePlayerLayer:response_compairCard(resp_json)
	self.gameTimeLayer:stopTimer();
	--self.gameBaseButton:response_compairCard(resp_json)
	--执行pk动画
	if resp_json ~= nil and resp_json.firstPlayer ~= nil and resp_json.secondPlayer ~= nil then
		--两个人进行了比牌
		self:showPKAction(resp_json.winPlayer,resp_json.failPlayer, function ()
			self.gameCardLayer:response_compairCard(resp_json)
			self.gameCardHandle:response_compairCard(resp_json)
			if resp_json.winPlayer == self:getSelfInfo().bDeskStation then
				self.music:playNormalVoice("shengli")
			elseif resp_json.failPlayer == self:getSelfInfo().bDeskStation then
				self.music:playNormalVoice("shibai")
			end
		end)
	elseif resp_json ~= nil and resp_json.firstPlayer ~= nil and resp_json.isMyWin ~= nil then
		--一个人对所有人进行了比牌操作
		self:show_PK_AllAction(resp_json.firstPlayer,resp_json.isMyWin,function ()
			self.gameCardLayer:response_compairCard(resp_json)
			self.gameCardHandle:response_compairCard(resp_json)
			if resp_json.isMyWin ~= nil and resp_json.isMyWin == true  then
				self.music:playNormalVoice("shengli")
			else
				self.music:playNormalVoice("shibai")
			end
		end)
	else
		--所有人进行了来牌
		
	end
	
end
--总结算结果返回
function GameScene:response_showOver(resp_json)
	self.gameStation = TouziGameStationEnum.GS_WAIT_NEXT
	--每局结束后，要更新本地用户分数
	if resp_json ~= nil and resp_json.points ~= nil and #resp_json.points>0 then
		for i=1,#resp_json.points do
			local chair = resp_json.points[i].chair;
			local userinfo = self:getPlayerInfoByChairID(chair)
			local coin = resp_json.points[i].npoint;
			userinfo.dwMoney = coin;
		end
	end
	
	self.gameBaseLayer:response_showOver(resp_json)
	self.gamePlayerLayer:response_showOver(resp_json)
	self.gameCardLayer:response_showOver(resp_json)
	performWithDelay(self, function()
		
		self.gamePlayerCoinLayer:response_showOver(resp_json)
	end, 1);
	performWithDelay(self, function()
		self.music:playNormalVoice("shoujijinbi")
	end, 1.2);
	
	self.gameBaseButton:response_showOver(resp_json)
	self.gameFireLayer:response_showOver(resp_json)
	self.gameTimeLayer:stopTimer();
	if resp_json ~= nil and resp_json.baoziAdd ~= nil and resp_json.baoziAdd == true then
		self:playBaoziAction()
		self.music:playNormalVoice("baozi")
		
	end
	--self.gamePlayerLayer:response_showOver(resp_json)
end
--播放豹子动画
function GameScene:playBaoziAction()
	local path = "action/santiao.csb"
	local baoziNode = cc.CSLoader:createNode(path)
	local baoziAction = cc.CSLoader:createTimeline(path)
	baoziAction:setTimeSpeed(24/60)
	
	baoziNode:runAction(baoziAction)
	baoziAction:gotoFrameAndPlay(0,false)
	local windowSize = CCDirector:getInstance():getWinSize()
	baoziNode:setPosition(windowSize.width/2,windowSize.height/2)
	self:addChild(baoziNode)
	baoziAction:setLastFrameCallFunc(function()
		baoziNode:removeFromParent();
		
	end)
end
--开始下一局
function GameScene:response_resetGame(resp_json)
	self.gameStation = TouziGameStationEnum.GS_WAIT_ARGEE
	self.playerData = {}
	self:deleteAllUserReady()
	self.gameBaseLayer:response_resetGame(resp_json)
	self.gameStartLayer:response_resetGame(resp_json)
	self.gameCardLayer:response_resetGame(resp_json)
	--self.gameBaseButton:response_resetGame(resp_json)
	self.gameCardHandle:response_resetGame(resp_json)
	self.gamePlayerLayer:response_resetGame(resp_json)
	--刷新准备层状态，
	self.gameReadyLayer:updateUser()
end

--[["resp_json:" = {
    "GameStation"       = 4
    "allCountZhu"       = 20
    "bPlaying"          = true
    "iCountXiaZhuLimit" = -1163005939
    "iCurRounds"        = 1
    "iDizhu"            = 10
    "iLeaverTime"       = -1
    "iMaxRounds"        = 4
    "iNtStation"        = 1
    "iTotalNoteLimit"   = 100
    "iTurnCount"        = -1163005939
    "iVersion"          = 2
    "iVersion2"         = 0
}]]
function GameScene:onGameStation(resp_json)
	if resp_json ~= nil and resp_json.m_iIsFirstGame ~= nil then
		if resp_json.m_iIsFirstGame == true then
			self.isFirstGame = true;
		end
	end
	--dump(resp_json,"resp_json:")
	
	--更新当前游戏状态
	if resp_json.GameStation ~= nil then
		self.gameStation = resp_json.GameStation
	end
	if resp_json.deskActive ~= nil then
		self.deskActive = resp_json.deskActive;
	end
	--如果是下注状态，更新当前在线用户信息
	if resp_json.player ~= nil and resp_json.player.chairinfo ~= nil and
		resp_json.GameStation == self:getGameStationEnum().GS_XIAZHU then
		self.playerData = resp_json.player.chairinfo
	end
	self.gamePlayerLayer:onGameStation(resp_json)
	self.gameChairLayer:onGameStation(resp_json)
	self.gameBaseButton:onGameStation(resp_json)
	self.gameBaseLayer:onGameStation(resp_json)
	self.gameStartLayer:onGameStation(resp_json)
	self.gameReadyLayer:onGameStation(resp_json)
	self.gameTimeLayer:onGameStation(resp_json)
	
	self.gamePlayerCoinLayer:onGameStation(resp_json)
	self.gameCardLayer:onGameStation(resp_json)
	self.gameCardHandle:onGameStation(resp_json)
	
end

--显示PK动画
function GameScene:showPKAction(winPlayerIndex,failPlayerIndex,callback)
	
	self.music:playNormalVoice("shandian")
	local path = "action/PK.csb"
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)
	
	--本动画使用两个动画进行合成，1，头像放大飞出动画，和pk动画
	--第一个动画
	local headItemPath = "action/headItem.csb"
	local headItem1 = cc.CSLoader:createNode(headItemPath)
	local headItem2 = cc.CSLoader:createNode(headItemPath)
	self:addChild(headItem1)
	self:addChild(headItem2)
	local winViewIndex = self:getHelper():DeskStation2View(winPlayerIndex)
	local failViewIndex = self:getHelper():DeskStation2View(failPlayerIndex)
	local firstPlayer = winPlayerIndex
	local secondPlayer = failPlayerIndex
	if winViewIndex == 4 or winViewIndex == 5 then 
		firstPlayer = winPlayerIndex
		secondPlayer = failPlayerIndex
	elseif failViewIndex == 4 or failViewIndex == 5 then
		firstPlayer = failPlayerIndex
		secondPlayer = winPlayerIndex
	end
	headItem1:setPosition(self.gamePlayerLayer:getPositionByChair(firstPlayer))
	headItem2:setPosition(self.gamePlayerLayer:getPositionByChair(secondPlayer))
	
	--更新飞动的头像动画
	local Image_head1 = seekNodeByName(headItem1,"Image_head")
	local Image_head2 = seekNodeByName(headItem2,"Image_head")
	local userinfo1 = self:getPlayerInfoByChairID(firstPlayer)
	local userinfo2 = self:getPlayerInfoByChairID(secondPlayer)
	m_download:get_instance():set_head_image_and_auto_update( Image_head1 , userinfo1.avatarUrl , userinfo1.dwUserID)
	m_download:get_instance():set_head_image_and_auto_update( Image_head2 , userinfo2.avatarUrl , userinfo2.dwUserID)
	
	--更新上面头像的位置
	local node1 = seekNodeByName(loadinganimlNode,"FileNode_1")
	local node2 = seekNodeByName(loadinganimlNode,"FileNode_2")
	node1:setVisible(false)
	node2:setVisible(false)
	local node1head = seekNodeByName(node1,"Image_head")
	local node2head = seekNodeByName(node2,"Image_head")
	m_download:get_instance():set_head_image_and_auto_update( node1head , userinfo1.avatarUrl , userinfo1.dwUserID)
	m_download:get_instance():set_head_image_and_auto_update( node2head , userinfo2.avatarUrl , userinfo2.dwUserID)

	local ScaleTo1 = cc.ScaleTo:create(0.3,1.2);
	local ScaleTo2 = cc.ScaleTo:create(0.3,1.2);
	
	local scale1 = cc.Spawn:create(cc.EaseExponentialInOut:create(cc.MoveTo:create(0.5,cc.p(370,481))),cc.ScaleTo:create(0.4,1.0))
	local scale2 = cc.Spawn:create(cc.EaseExponentialInOut:create(cc.MoveTo:create(0.5,cc.p(918,399))),cc.ScaleTo:create(0.4,1.0))
	local scale3 = cc.EaseExponentialInOut:create(cc.MoveTo:create(0.9,cc.p(self.gamePlayerLayer:getPositionByChair(firstPlayer))))
	local scale4 = cc.EaseExponentialInOut:create(cc.MoveTo:create(0.9,cc.p(self.gamePlayerLayer:getPositionByChair(secondPlayer))))
	local callfunc1 = cc.CallFunc:create(function()
			--headItem1:removeFromParent()
			headItem1:setVisible(false)
			node1:setVisible(true)
			--赢的人后播动画，输的人先播动画
			local time = 0.1
			if firstPlayer == winPlayerIndex then
				 time = 0.5
			end
			performWithDelay(node1, function()
				local failpath = "action/PK_LOST.csb"
				local winpath = "action/PK_WIN.csb"
				local strpath = failpath; 
				if firstPlayer == winPlayerIndex then
					strpath = winpath
				end 
				print("node1:action:"..strpath)
				local action_node = cc.CSLoader:createNode(strpath)
				local action_x = cc.CSLoader:createTimeline(strpath)
				action_x:setTimeSpeed(24/60)
				action_x:gotoFrameAndPlay(0,false)
				action_node:runAction(action_x)
				node1:addChild(action_node)
			end,time)
		end)
	local callfunc2 = cc.CallFunc:create(function()
			headItem2:setVisible(false)
			node2:setVisible(true)
			--赢的人后播动画，输的人先播动画
			local time = 0.1
			if secondPlayer == winPlayerIndex then
				 time = 0.5
			end
			performWithDelay(node2, function()
				local failpath = "action/PK_LOST.csb"
				local winpath = "action/PK_WIN.csb"
				local strpath = failpath; 
				if firstPlayer ~= winPlayerIndex then
					strpath = winpath;
				end 
				print("node2:action:"..strpath)
				local action_node = cc.CSLoader:createNode(strpath)
				local action_x = cc.CSLoader:createTimeline(strpath)
				action_x:setTimeSpeed(24/60)
				action_x:gotoFrameAndPlay(0,false)
				action_node:runAction(action_x)
				node2:addChild(action_node)
			end, time)
		end)
	local callfunc1_1 = cc.CallFunc:create(function()
			headItem1:setVisible(true)
			node1:setVisible(false)
		end)
	local callfunc2_1 = cc.CallFunc:create(function()
			headItem2:setVisible(true)
			--headItem1:setVisible(false)
			node2:setVisible(false)
		end)
	local callfunc3 = cc.CallFunc:create(function()
			headItem1:removeFromParent()
		end)
	local callfunc4 = cc.CallFunc:create(function()
			headItem2:removeFromParent()
			self.gamePlayerLayer:setUserSit(winViewIndex,true)
			self.gamePlayerLayer:setUserSit(failViewIndex,true)
		end)
	local delay1 = cc.DelayTime:create(1.0)
	local delay2 = cc.DelayTime:create(1.0)
	local sequence1 = cc.Sequence:create(ScaleTo1,scale1, callfunc1,delay1,callfunc1_1,scale3,callfunc3)--动画，隐藏，等待，显示，动画，移除
	local sequence2 = cc.Sequence:create(ScaleTo2,scale2, callfunc2,delay2,callfunc2_1,scale4,callfunc4)--动画，隐藏，等待，显示，动画，移除
	headItem1:runAction(sequence1)
	headItem2:runAction(sequence2)
	self.gamePlayerLayer:setUserSit(winViewIndex,false)
	self.gamePlayerLayer:setUserSit(failViewIndex,false)
	loadinganimlaction:setTimeSpeed(24/60)
	
	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,false)
	local windowSize = CCDirector:getInstance():getWinSize()
	loadinganimlNode:setPosition(windowSize.width/2,windowSize.height/2)
	self:addChild(loadinganimlNode)
	loadinganimlaction:setLastFrameCallFunc(function()
		loadinganimlNode:removeFromParent();
		if callback ~= nil then
			callback();
		end
	end)
end

--显示PK_All动画
function GameScene:show_PK_AllAction(firstPlayer,isMyWin,callback)
	
	self.music:playNormalVoice("shandian")
	local path = "action/PK.csb"
	local loadinganimlNode = cc.CSLoader:createNode(path)
	local loadinganimlaction = cc.CSLoader:createTimeline(path)
	
	--本动画使用两个动画进行合成，1，头像放大飞出动画，和pk动画
	--第一个动画
	local headItemPath = "action/headItem.csb"
	local headItem1 = cc.CSLoader:createNode(headItemPath)
	--local headItem2 = cc.CSLoader:createNode(headItemPath)
	self:addChild(headItem1)
	--self:addChild(headItem2)
	
	headItem1:setPosition(self.gamePlayerLayer:getPositionByChair(firstPlayer))
	--headItem2:setPosition(self.gamePlayerLayer:getPositionByChair(secondPlayer))
	
	--更新飞动的头像动画
	local Image_head1 = seekNodeByName(headItem1,"Image_head")
	--local Image_head2 = seekNodeByName(headItem2,"Image_head")
	local userinfo1 = self:getPlayerInfoByChairID(firstPlayer)
	--local userinfo2 = self:getPlayerInfoByChairID(secondPlayer)
	m_download:get_instance():set_head_image_and_auto_update( Image_head1 , userinfo1.avatarUrl , userinfo1.dwUserID)
	--m_download:get_instance():set_head_image_and_auto_update( Image_head2 , userinfo2.avatarUrl , userinfo2.dwUserID)
	
	--更新上面头像的位置
	local node1 = seekNodeByName(loadinganimlNode,"FileNode_1")
	local node2 = seekNodeByName(loadinganimlNode,"FileNode_2")
	node1:setVisible(false)
	node2:setVisible(false)
	local node1head = seekNodeByName(node1,"Image_head")
	--local node2head = seekNodeByName(node2,"Image_head")
	m_download:get_instance():set_head_image_and_auto_update( node1head , userinfo1.avatarUrl , userinfo1.dwUserID)
	--m_download:get_instance():set_head_image_and_auto_update( node2head , userinfo2.avatarUrl , userinfo2.dwUserID)

	local ScaleTo1 = cc.ScaleTo:create(0.3,1.2);
	--local ScaleTo2 = cc.ScaleTo:create(0.3,1.2);
	
	local scale1 = cc.Spawn:create(cc.EaseExponentialInOut:create(cc.MoveTo:create(0.5,cc.p(370,481))),cc.ScaleTo:create(0.4,1.0))
	local scale2 = cc.Spawn:create(cc.EaseExponentialInOut:create(cc.MoveTo:create(0.5,cc.p(918,399))),cc.ScaleTo:create(0.4,1.0))
	local scale3 = cc.EaseExponentialInOut:create(cc.MoveTo:create(0.9,cc.p(self.gamePlayerLayer:getPositionByChair(firstPlayer))))
	--local scale4 = cc.EaseExponentialInOut:create(cc.MoveTo:create(0.9,cc.p(self.gamePlayerLayer:getPositionByChair(secondPlayer))))
	local callfunc1 = cc.CallFunc:create(function()
			--headItem1:removeFromParent()
			headItem1:setVisible(false)
			node1:setVisible(true)
			--赢的人后播动画，输的人先播动画
			local time = 0.1
			
			performWithDelay(node1, function()
				local failpath = "action/PK_LOST.csb"
				local winpath = "action/PK_WIN.csb"
				local strpath = failpath
				if isMyWin == true then
					strpath = winpath
				end
				print("node1:action:"..strpath)
				local action_node = cc.CSLoader:createNode(strpath)
				local action_x = cc.CSLoader:createTimeline(strpath)
				action_x:setTimeSpeed(24/60)
				action_x:gotoFrameAndPlay(0,false)
				action_node:runAction(action_x)
				node1:addChild(action_node)
			end,time)
		end)
	local callfunc2 = cc.CallFunc:create(function()
			headItem2:setVisible(false)
			node2:setVisible(true)
			--赢的人后播动画，输的人先播动画
			local time = 0.1
			if secondPlayer == winPlayerIndex then
				 time = 0.5
			end
			performWithDelay(node2, function()
				local failpath = "action/PK_LOST.csb"
				local winpath = "action/PK_WIN.csb"
				local strpath = failpath; 
				if firstPlayer ~= winPlayerIndex then
					strpath = winpath;
				end 
				print("node2:action:"..strpath)
				local action_node = cc.CSLoader:createNode(strpath)
				local action_x = cc.CSLoader:createTimeline(strpath)
				action_x:setTimeSpeed(24/60)
				action_x:gotoFrameAndPlay(0,false)
				action_node:runAction(action_x)
				node2:addChild(action_node)
			end, time)
		end)
	local callfunc1_1 = cc.CallFunc:create(function()
			headItem1:setVisible(true)
			node1:setVisible(false)
		end)
	local callfunc2_1 = cc.CallFunc:create(function()
			headItem2:setVisible(true)
			--headItem1:setVisible(false)
			node2:setVisible(false)
		end)
	local callfunc3 = cc.CallFunc:create(function()
			headItem1:removeFromParent()
		end)
	local callfunc4 = cc.CallFunc:create(function()
			headItem2:removeFromParent()
			self.gamePlayerLayer:setUserSit(winViewIndex,true)
			self.gamePlayerLayer:setUserSit(failViewIndex,true)
		end)
	local delay1 = cc.DelayTime:create(1.0)
	local delay2 = cc.DelayTime:create(1.0)
	local sequence1 = cc.Sequence:create(ScaleTo1,scale1, callfunc1,delay1,callfunc1_1,scale3,callfunc3)--动画，隐藏，等待，显示，动画，移除
	--local sequence2 = cc.Sequence:create(ScaleTo2,scale2, callfunc2,delay2,callfunc2_1,scale4,callfunc4)--动画，隐藏，等待，显示，动画，移除
	headItem1:runAction(sequence1)
	--headItem2:runAction(sequence2)
	self.gamePlayerLayer:setUserSit(firstPlayer,false)
	--self.gamePlayerLayer:setUserSit(failViewIndex,false)
	loadinganimlaction:setTimeSpeed(24/60)
	
	loadinganimlNode:runAction(loadinganimlaction)
	loadinganimlaction:gotoFrameAndPlay(0,false)
	local windowSize = CCDirector:getInstance():getWinSize()
	loadinganimlNode:setPosition(windowSize.width/2,windowSize.height/2)
	self:addChild(loadinganimlNode)
	loadinganimlaction:setLastFrameCallFunc(function()
		loadinganimlNode:removeFromParent();
		if callback ~= nil then
			callback();
		end
	end)
	local path2 = "action/PKALL_WIN.csb"
	if isMyWin == true then
		path2 = "action/PKALL_LOST.csb"
	end
	local pkAllNode = cc.CSLoader:createNode(path2)
	local pkAllAction = cc.CSLoader:createTimeline(path2)
	pkAllAction:setTimeSpeed(24/60)
	pkAllNode:runAction(pkAllAction)
	pkAllAction:gotoFrameAndPlay(0,false)
	
	--loadinganimlNode:setPosition(windowSize.width/2,windowSize.height/2)
	loadinganimlNode:addChild(pkAllNode)
end
--总结算界面
function GameScene:response_allGameResult(resp_json)
	
	self:addChild(GameOverLayer:create(self,resp_json))
end
function GameScene:response_gameRecord(resp_json)
	self.gameBaseLayer:showNowZhanji(resp_json)
end
-------------------------------------------平台消息---------------------------------------

--@desc  收到申请信息
function GameScene:onHasApplyInfo()
	print("收到申请消息")
	self.gameBaseLayer:onHasApplyInfo()
end
--@desc  给玩家加分结果返回
--@param code 1.房主身份验证不通过; 2.您不是房主没权加分 3.桌子不存在; 4.该玩家没有进入过本桌子; 10.请求参数有误; -1.其它原因
--@param add_point 本次添加的分数
function GameScene:playeMasterAddPointBack( user_info , desk_info , code , add_point)
	if code == 1 then
        api_show_tips("你不是房主，没有权限加分")
    elseif code == 2 then
        api_show_tips("你不是房主，没有权限加分")
    elseif code == 3 then
        api_show_Msg_Tip("桌子已解散，请退出房间" , function() 
            self.super:Exit_game()
        end , true)
    elseif code == 4 then
        api_show_tips("该玩家没有进入过本桌子，不可以对其添加分数")
    elseif code == 10 then
        api_show_tips("请求参数有错误")
    elseif code == 0 or code == nil then
		dump(user_info,"user_info:")
		if user_info.dwUserID == self:getSelfInfo().dwUserID and self:getDeskInfo().mastUserID ~= self:getSelfInfo().dwUserID then
			api_show_tips(string.format("房主给您加了%d分！", add_point))
		else
			api_show_tips(string.format("房主给\"%s\"加了%d分！", user_info.nickName , add_point))
		end
		self:update_game_record()
		self.gamePlayerCoinLayer:showUserCoin();
    else
        api_show_Msg_Box("加分失败，未知错误("..code..")")
    end 
end
--添加一个监听，如果存在，notify界面，通知刷新
function GameScene:update_game_record()
    if self.game_record_update_call then
        performWithDelay( self , self.game_record_update_call , 0.5)
    end
end

function GameScene:register_game_record_update_call( call )
    self.game_record_update_call = call
end

--@desc  有玩家离开房间
-- @param code 1.您正在游戏中，不允许退出 2.您已经离开，不需要请求再次离开
function GameScene:playerLeaveRoom( user_info , code )
    print("GameScene:playerLeaveRoom code = " .. code)
    if code == 0 then
        print("玩家" .. user_info.dwUserID .. "离开房间")
    elseif code == 1 then
        api_show_Msg_Box("您正在游戏中，不允许退出")
    elseif code == 2 then
        api_show_Msg_Box("您已经离开，不需要请求再次离开")
    end

end

-- 有玩家离开桌子
--@desc  离开桌子
--@param code 1.正在游戏不准离开桌子 2.已经离开不需要再次离开
function GameScene:playerLeaveDesk( user_info , desk_info  , code )
    print("CGameScene:playerLeaveDesk------------code = " .. code)

    if code == 0 then
        --print("玩家" .. user_info.dwUserID .. "离开桌子")
        --self.GameLayer.MenuManager:onPlayerLeaveDesk( user_info , desk_info , code)
		api_show_tips(string.format("%s,离线",user_info.nickName))
    elseif code == 1 then
        api_show_Msg_Box("正在游戏不准离开桌子")
    elseif code == 2 then
        api_show_Msg_Box("已经离开不需要再次离开")
    end

end
--覆盖父类，不让有同ip提示
function GameScene:check_ip_same(desk_max_people)
end
-- 有玩家坐下
--@param code 1.位置上已有玩家 2.分数不足 3.座位不正确 4.玩家未进房间 5.不允许坐下
-- 6.房间已解散 7.被房主禁了 8.桌子索引不属于本房间 9.桌子已满人 10.玩家已经坐下 -1.其它原因
function GameScene:playerSitDesk( user_info , desk_info , code  )
    --auto
    print("GameScene:playerSitDesk-------------------------")
    if not user_info then
       print("user_info-------------------------error")
       return
    end
    if code == 0 then
        --如果是自己坐下就保存BasePosChair
        if self:isMyself(user_info) then
			--self:deleteAllUserReady()
			api_hide_loading()
			api_hide_loading()
			self.isSendSitUp = false;
			print("------设置自己的椅子号 " .. user_info.bDeskStation)
			self.myselfPosition = tonumber(user_info.bDeskStation)
			self:reqDeskRebind();
        end
		self.gamePlayerLayer:showUserSit()
		self.gamePlayerCoinLayer:showUserCoin();
		self.gameChairLayer:updateUser()
		if self.gameStation == self:getGameStationEnum().gameUnStartStation or
			self.gameStation == self:getGameStationEnum().GS_WAIT_ARGEE  then
			self.gameReadyLayer:updateUser();
		elseif self.gameStation == self:getGameStationEnum().GS_XIAZHU then
			self.gameCardLayer:updateUserCard();
			self.gameTimeLayer:updateUserTime();
		end
		if self:isMyself(user_info) and self.gameStation ~= self:getGameStationEnum().GS_XIAZHU then
			if  self.deskActive == true then
				self.gameStartLayer:updateButton("Button_zhunbei")
			else
				if self:isMast() then
					self.gameStartLayer:updateButton("Button_kaizuo")
				else
					self.gameStartLayer:updateButton("Image_tip")
				end
			end
		end
		
    elseif code == 1 then
        api_show_Msg_Box("位置上已有玩家")
    elseif code == 2 then
        api_show_Msg_Box("分数不足")
    elseif code == 3 then
        api_show_Msg_Box("座位不正确")
    elseif code == 4 then
        api_show_Msg_Box("玩家未进房间")
    elseif code == 5 then
        api_show_Msg_Box("不允许坐下")
    elseif code == 6 then
        api_show_Msg_Box("房间已解散")
    elseif code == 7 then
        api_show_Msg_Box("被房主禁了")
    elseif code == 8 then
        api_show_Msg_Box("桌子索引不属于本房间")
    elseif code == 9 then
        api_show_Msg_Box("桌子已满人")
    elseif code == 10 then
        api_show_Msg_Box("玩家已经坐下")
    end
--]]
end

--判断当前用户是否是房主
function GameScene:isMast()
	if self:isQzProject() == false then
		return false;
	end
	return self:getDeskInfo().mastUserID == self:getSelfInfo().dwUserID
end
--检查当前自己是否坐下
function GameScene:isAlreadySitdown()
	local myself = self:getSelfInfo();
	return myself.bDeskStation>=0;
end
--对比userinfo是否值自己
function GameScene:isMyself(userinfo)
	if userinfo == nil or userinfo.dwUserID== nil then
		return false;
	end
	local myself = self:getSelfInfo();
	if myself.dwUserID == userinfo.dwUserID then
		return true;
	end
	return false;
end
--判断当前座位号是否为nil
function GameScene:isFreeChair(chair)
	local playerDeskMap = self:getSitDownPlayerMap()
	for k,v in pairs(playerDeskMap) do
		if playerDeskMap.bDeskStation == chair then
			return false;
		end
	end
	return true;
end
function GameScene:pointLease()
    local text_tip  = ""
    local call_func = nil
    if self:getDeskInfo().mastUserID~=tonumber(self:getSelfInfo().dwUserID) then
        text_tip = "您的分数不够啦，请及时联系房主加分！"
        call_func = function()
			local selfinfo = self:getSelfInfo()
			local apply_info ={}
			apply_info.apply_user_nickName = selfinfo.nickName
			apply_info.apply_user_tablePoint = selfinfo.dwMoney
			apply_info.apply_user_id = selfinfo.dwUserID
			apply_info.desk_id=self:getDeskInfo().bDeskNO
			self:addChild(GameAddCoinLayer:create(self, 10000))
        end
    else
        text_tip = "您的分数不够啦，给自己加点分吧！"
        call_func = function()
			local selfinfo = self:getSelfInfo()
			local apply_info ={}
			apply_info.apply_user_nickName = selfinfo.nickName
			apply_info.apply_user_tablePoint = selfinfo.dwMoney
			apply_info.apply_user_id = selfinfo.dwUserID
			apply_info.desk_id=self:getDeskInfo().bDeskNO
			self:addChild(GameMaskAddNumCoinLayer.new(self,apply_info))
        end
    end
    api_show_Msg_Tip( text_tip , call_func )
end
--@desc  加入桌子
--@param code 1.桌子号不属于本房间 5.桌子人数已满人 -1.其它原因
function GameScene:playerJoinDesk( user_info , desk_info , code )
	dump(user_info,"playerJoinDesk....user_info:")
	--dump(desk_info,"desk_info:")
	--print(code)
	--self.gamePlayerLayer:showUserSit()
	--self.gamePlayerCoinLayer:showUserCoin();
	self:deleteUserReady(user_info.dwUserID)
	self.gamePlayerLayer:showUserSit()
	if self.gameStation == self:getGameStationEnum().gameUnStartStation or
		self.gameStation == self:getGameStationEnum().GS_WAIT_ARGEE  then
		self.gameReadyLayer:updateUser()
	else
		self.gameTimeLayer:playerJoinDesk(user_info)
	end
	self.gameBaseButton:updateShowButton()
	if self:isMyself(user_info) == true and self:isAlreadySitdown() == false then
		self.gameStartLayer:updateButton()
	end
	if self:isMyself(user_info) and self:isAlreadySitdown() == false and self:isQzProject() == true then
		--api_show_tips("超时未开始，系统自动弹起")
		--self.gameBaseButton:updateShowButton("Panel_sitdown")
		self.gameChairLayer:updateUser()
	end
	
end
--@desc  站起
--@param code 1.玩家正在游戏中 2.玩家不在房间  -1.其它原因
function GameScene:playerStandUp( user_info , desk_info , code ) 
	if code == 0 or code == 50 then
        --Music:playEffect("res/sound/game/game_stand.mp3", false)
		print("界面游戏玩家站起")
        print("站起玩家为当前用户，进行桌子显示")
		
		self:deleteUserReady(user_info.dwUserID)
		user_info.bDeskStation = -1
		self.gamePlayerLayer:showUserSit()
		self.gameReadyLayer:updateUser()
		self.gamePlayerCoinLayer:showUserCoin()
		if self:isMyself(user_info) then
			--如果自己站起，隐藏所有按钮
			self.gameStartLayer:updateButton()
		end
		--如果有人站起，及时更新座椅，如果自己也是站起的，可以多一个位置进行选择坐下
		self.gameChairLayer:updateUser()
		
		if self:isAlreadySitdown() == false then
			if self:isQzProject() == true then
				self.gameBaseButton:updateShowButton("Panel_sitdown")
			else
				api_hide_loading()
				api_show_loading_gameWaitting("正在匹配...","没有匹配到用户",nil,function()
					self.parent:Exit_game()
				end)
			end
		end
		
    elseif code == 1 then
        api_show_Msg_Box("房主已经解散房间")
    elseif code == 2 then
        api_show_Msg_Box("玩家不在房间")
    end
end
--添加一个最终结算的界面
function GameScene:showGameOverLayer()
	
end
-------------------------------------------平台接口---------------------------------------
--@desc  桌子激活
--@param code 0.激活桌子成功 1.未进入房间 2.你不是房主无权限 3.桌子已曾激活 -1.其它原因
function GameScene:deskStart( code  )
    if code == 1 then
        api_show_Msg_Box( "你已掉线，是否重新进入游戏" , function()
            self.super:Exit_game()
        end ,  false )
    elseif code == 2 then
        api_show_tips("你不是房主，没权解散房间")
    elseif code == 3 then
        print("桌子已经激活")
    elseif code == 0 or code == nil then
       
        self.deskActive = true
		self.gameStartLayer:deskStart()
    else
        api_show_Msg_Box("开始失败，未知的错误("..code..")")
    end
end
--@desc  被T           玩家被房主T出房间
--@param code 1.不能踢自己 2.不是房主不能T人 3.要踢出的用户不在房间中 4.你不在房间中不能操作 5.玩家已曾踢除 10.请求参数有误 -1.其它原因
function GameScene:playerByMasterBoot( user_info , desk_info , code )
    if code == 0 then
        api_show_Msg_Box("你已经被房主踢出房间！",function()
            self:Exit_game()
        end)
    elseif code == 1 then
        api_show_Msg_Box("不能踢自己！")
    elseif code == 2 then
        api_show_Msg_Box("不是房主不能T人！")
    elseif code == 3 then
        api_show_Msg_Box("要踢出的用户不在房间中！")
    elseif code == 4 then
        api_show_Msg_Box("你不在房间中不能操作！") 
    elseif code == 5 then
        api_show_Msg_Box("玩家已曾踢除！") 
    elseif code == 10 then
        api_show_Msg_Box("请求参数有误！") 
    end
    

end

--其他玩家掉线
function GameScene:other_player_offline( user_info )
    api_show_tips("【"..user_info.nickName .."】掉线")
end
--@desc  桌子解散
--@param code 1.房主解散 2.对局已打满  3.桌子限期已到  4大家同意解散 5.有玩家申请解散房间
--@param user_info 有玩家请求解散时对应玩家的信息
function GameScene:onDeskDismiss( code , user_info )
    print("GameScene:onDeskDismiss")
    if code == 1 then
        api_show_Msg_Box("房主解散房间" , function()
            --self:Exit_game()
        end)
    elseif code == 2 then
        --api_show_Msg_Box("对局已打满",function()
        --    self:Exit_game()
		--end)
    elseif code == 3 then
        api_show_Msg_Box("桌子限期已到",function()
            self:Exit_game()
        end)
    elseif code == 4 then
        api_show_Msg_Box("大家同意解散",function()
            self:Exit_game()
        end)
    elseif code == 5 then
        api_show_Msg_Box("有玩家申请解散房间",function()
            self:Exit_game()
        end)
    end
end

--@desc  房主请求解散失败时的返回
--@param code 0.解散命令已成功，但是要等待游戏结束 1.未在房间里没权解散 2.不是房主无权解散 3.桌子已经解散不需要重复解散 -1.其他原因 
function GameScene:onMasterDismissDeskFail( code  )
    print("GameScene:onMasterDismissDeskFail")
    if code == 0 then
        --api_show_Msg_Box("解散命令已成功，但是要等待游戏结束")
    elseif code == 1 then
        api_show_Msg_Box("未在房间里没权解散")
    elseif code == 2 then
        api_show_Msg_Box("不是房主无权解散")
    elseif code == 3 then
        api_show_Msg_Box("桌子已经解散不需要重复解散")
    end
end
--------------------------------------end------------------------------------------
--排队场特有接口
--用户金币变化
function GameScene:user_score_change(code,score_info)
    print("显示用户金币变化")
	self.gamePlayerLayer:user_score_change(code,score_info)
end

return GameScene
--endregion