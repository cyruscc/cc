--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
local m_download = import("....common.download")

local GameRecordLayer = class("GameRecordLayer",function()
	return cc.CSLoader:createNode("game/gameRecord.csb")
end)
--[["zanjilist" = {
    1 = {
        "avatarUrl"  = ""
        "point"      = 0
        "szNickName" = "chenchao"
        "userid"     = 87322
    }
    2 = {
        "avatarUrl"  = ""
        "point"      = 20
        "szNickName" = "111"
        "userid"     = 87608
    }
}]]
function GameRecordLayer:ctor(parent,data)
	
	self.parent = parent
	self.data = data;
	
    local Image_bg = seekNodeByName(self,"Image_bg")
	local btn_back = seekNodeByName(Image_bg,"btn_back")
	btn_back:addClickEventListener(function()
		self:removeFromParent();
	end)
	local iCurRounds = data.iCurRounds
	local iMaxRounds = data.iMaxRounds
	--当前局数显示
	local Text_now_jushu = seekNodeByName(Image_bg,"Text_now_jushu")
	Text_now_jushu:setString(string.format("%d/%d",iCurRounds,iMaxRounds))
	--列表
	local ListView_1 = seekNodeByName(Image_bg,"ListView_1")
	--列表模板
	local Panel_2 = seekNodeByName(Image_bg,"Panel_2")
	Panel_2:setVisible(false)
	if ListView_1 ~= nil then
		ListView_1:removeAllChildren()
	end
	--添加列表内容
	local zhanjilist = self.data.zanjilist
	local length = #zhanjilist
	local Image_head=nil
	local Text_name=nil
	local Text_takeMoney=nil
	local Text_nowScore=nil
	local score_fail=nil
	local score_success=nil
    for i=1,length do
        local panel_Item = Panel_2:clone()
        panel_Item:setVisible(true)
		--更新头像
		Image_head = seekNodeByName(panel_Item,"Image_head")
		Text_name = seekNodeByName(panel_Item,"Text_name")
		Text_takeMoney = seekNodeByName(panel_Item,"Text_takeMoney")
		Text_nowScore = seekNodeByName(panel_Item,"Text_nowScore")
		score_fail = seekNodeByName(panel_Item,"score_fail")
		score_success = seekNodeByName(panel_Item,"score_success")
		if Image_head ~= nil and zhanjilist[i].avatarUrl ~= nil and #(zhanjilist[i].avatarUrl)>0 then
			m_download:get_instance():set_head_image_and_auto_update( Image_head , zhanjilist[i].avatarUrl , zhanjilist[i].userid)
		end
		if Text_name ~= nil and zhanjilist[i].szNickName ~= nil and zhanjilist[i].szNickName ~= "" then
			Text_name:setString(zhanjilist[i].szNickName)
		end
		if Text_takeMoney ~= nil and zhanjilist[i].takeMoney ~= nil then
			Text_takeMoney:setString(zhanjilist[i].takeMoney)
		end
		if Text_nowScore ~= nil and zhanjilist[i].point ~= nil then
			Text_nowScore:setString(zhanjilist[i].point)
		end
		local changeScore = zhanjilist[i].takeMoney-zhanjilist[i].point
		if changeScore > 0 then
			score_success:setVisible(true)
			score_fail:setVisible(false)
			score_success:setString("."..changeScore)
		else
			score_success:setVisible(false)
			score_fail:setVisible(true)
			score_fail:setString("/"..changeScore)
		end
		
        ListView_1:pushBackCustomItem(panel_Item)
    end
end


return GameRecordLayer


--endregion
