--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local GameMenuLayer = import(".GameMenuLayer")
local GameBaseLayer = class("GameBaseLayer")
local GameRoomInfoLayer = import(".GameRoomInfoLayer")
local GameRecordLayer = import(".GameRecordLayer")
local GameSceneModule = import("..gameSceneModule")
local GameMaskAddCoinLayer = import(".GameMaskAddCoinLayer")

function GameBaseLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	
	self:init()
end

function GameBaseLayer:init()
	local Button_menu = seekNodeByName(self.rootNode,"Button_menu")
	if Button_menu ~= nil then
		Button_menu:addClickEventListener(function ()
			--self.parent:Exit_game()
			self.parent:addChild(GameMenuLayer.new(self.parent))
		end)
	end
	local Button_home = seekNodeByName(self.rootNode,"Button_home")
	if Button_home ~= nil then
		Button_home:addClickEventListener(function()
			self.parent:addChild(GameRoomInfoLayer.new(self.parent),100)
		end)
	end
	--房间号
	local Text_fangkey = seekNodeByName(self.rootNode,"Text_fangkey")
	if self.parent:isQzProject() then
		local deskInfo = self.parent:getDeskInfo();
		Text_fangkey:setString("房号:"..deskInfo.roomKey)
	else
		Text_fangkey:setVisible(false)
	end
	--局数
	local Text_fangju = seekNodeByName(self.rootNode,"Text_fangju")
	if self.parent:isQzProject() == true then
		Text_fangju:setString(string.format("局数:%d/%d",0,10))
	else
		Text_fangju:setVisible(false)
	end 
	--单注
	local Text_danzhu = seekNodeByName(self.rootNode,"Text_danzhu")
	Text_danzhu:setString("单注:100")
	--封顶
	local Text_fengding = seekNodeByName(self.rootNode,"Text_fengding")
	Text_fengding:setString("封顶:1000")
	--轮数
	local Text_lunNum = seekNodeByName(self.rootNode,"Text_lunNum")
	Text_lunNum:setString("轮数:1")
	
	local Button_message = seekNodeByName(self.rootNode,"Button_message")
	self.Button_message = Button_message
	local Image_tip  = seekNodeByName(Button_message,"Image_tip")
	Image_tip:setVisible(false)
	if self.parent:isQzProject() == true and self.parent:isMast() == true then
		Button_message:addClickEventListener(function()
			print("房主可看到的消息")
			Image_tip:setVisible(false)
			self.maskAddCoin = GameMaskAddCoinLayer.new(self.parent)
			self.parent:addChild(self.maskAddCoin,100)
		end)
	else
		Button_message:setVisible(false)
	end
	local Button_peipai = seekNodeByName(self.rootNode,"Button_peipai")
	Button_peipai:addClickEventListener(function ()
		self:showPeipai()
	end)
	--战绩
	local Button_rule = seekNodeByName(self.rootNode,"Button_rule")
	Button_rule:addClickEventListener(function ()
		--self:showPeipai()
		--需要从服务器实时获取
		GameSceneModule:getInstance():getGameRecord()
		--self:showNowZhanji()
	end)
	local Button_weixin = seekNodeByName(self.rootNode,"Button_weixin")
	Button_weixin:addClickEventListener(function()
		local str = "一齐来嗨拼三张!";
		if self.parent:isQzProject() == true then
			local deskInfo = self.parent:getDeskInfo();
			str = string.format("一齐来嗨拼三张!%s","房号:"..deskInfo.roomKey)
		end
		self.parent:reqShareToWXSession(lua_to_plat:get_app_name().."[拼三张]",str);
	end)
	--表情和语音
	local Image_face = seekNodeByName(self.rootNode,"Image_face")
	Image_face:addClickEventListener(function()
		self.parent:showChat(list)
	end)
	local Image_voice = seekNodeByName(self.rootNode,"Image_voice")
	Image_voice:setVisible(false)
	local quickVoiceLayer = import("app.platform.common.QuickVoiceLayer")
	self.m_voiceLayer = quickVoiceLayer:create(self.parent:getSelfInfo().dwUserID, handler(self.parent, self.parent.reqRecordSound) )
	self.m_voiceLayer:set_voice_image("res/mic.png")
	self.m_voiceLayer:set_voice_postion(Image_voice:getPosition())
	--self.m_voiceLayer:setZOrder(1) 
	self.rootNode:addChild(self.m_voiceLayer)
end
--收到有人加分请求
function GameBaseLayer:onHasApplyInfo()
	local Image_tip  = seekNodeByName(self.Button_message,"Image_tip")
	Image_tip:setVisible(true)
	if self.maskAddCoin ~= nil and self.maskAddCoin.updateList ~= nil then
		self.maskAddCoin:updateList();
		Image_tip:setVisible(false)
	end
end
--显示当前战绩
function GameBaseLayer:showNowZhanji(data)
	
	self.parent:addChild(GameRecordLayer.new(self.parent,data),100)
	
end
--游戏开始，更新当前局数
function GameBaseLayer:game_start(resp_json)
	
	self:updateDataByJson(resp_json)
end
function GameBaseLayer:updateDataByJson(resp_json)
	if resp_json ~= nil and resp_json.iCurRounds ~= nil and resp_json.iMaxRounds ~= nil then
		self:updateFangJu(resp_json.iCurRounds,resp_json.iMaxRounds)
	end
	if resp_json ~= nil and resp_json.iDizhu ~= nil then
		self:updateDanzhu(resp_json.iDizhu)
	end
	if resp_json ~= nil and resp_json.iTotalNoteLimit ~= nil then
		self:updateFengDing(resp_json.iTotalNoteLimit)
	end
	if resp_json ~= nil and resp_json.iTurnCount ~= nil and resp_json.iTotalTurnLimit ~= nil then
		self:updateLunNum(resp_json.iTurnCount,resp_json.iTotalTurnLimit)
	end
end

--更新局数
function GameBaseLayer:updateFangJu(curRounds,maxRounds)
	if curRounds == nil or maxRounds == nil or curRounds=="" or maxRounds=="" then
		return;
	end
	local Text_fangju = seekNodeByName(self.rootNode,"Text_fangju")
	Text_fangju:setString(string.format("局数:%d/%d",curRounds,maxRounds))
end
--更新单注
function GameBaseLayer:updateDanzhu(danZhuNum)
	if danZhuNum == nil or danZhuNum == "" then
		return;
	end
	local Text_danzhu = seekNodeByName(self.rootNode,"Text_danzhu")
	Text_danzhu:setString(string.format("底注:%d",danZhuNum))
end
--更新封顶
function GameBaseLayer:updateFengDing(fengDingNum)
	if fengDingNum == nil or fengDingNum == "" then
		return;
	end
	local Text_fengding = seekNodeByName(self.rootNode,"Text_fengding")
	Text_fengding:setString(string.format("单注封顶:%d",fengDingNum))
end
--更新轮数
function  GameBaseLayer:updateLunNum(num,totalLunLimit)
	if num == nil or num == "" then
		return 
	end
	local Text_lunNum = seekNodeByName(self.rootNode,"Text_lunNum")
	if Text_lunNum ~= nil then
		Text_lunNum:setString(string.format("轮数:%d/%d",num,totalLunLimit))
	end
end

--更新总注数
function GameBaseLayer:updateAllCoin(coinTotal)
	if coinTotal~= nil then
		local Image_allCoin = seekNodeByName(self.rootNode,"Image_allCoin")
		if Image_allCoin ~= nil then
			local Text_allnum = seekNodeByName(Image_allCoin,"Text_allnum")
			Text_allnum:setString("总注:"..coinTotal)
		end
		
	end
end
	
--显示配排器
function GameBaseLayer:showPeipai()
	local path = "game/configLayer.csb"
	local configLayer = cc.CSLoader:createNode(path)--cc.Sprite:create("res/chouma/100.png")
	self.parent:addChild(configLayer)
	local Panel_1 = seekNodeByName(configLayer,"Panel_1")
	local index = 1;
	local cardlist = {}
	for i=1,4 do
		for j=1,13 do
			local cardItem = seekNodeByName(Panel_1,string.format("Image_%d_%d",i,j))
			cardItem:loadTexture(string.format("res/card/card_%d_%d.png",i,j))
			cardItem:addClickEventListener(function()
				if index>3 then
					return 
				end
				local Image_x = seekNodeByName(Panel_1,"Image_x_"..index)
				Image_x:loadTexture(string.format("res/card/card_%d_%d.png",i,j))
				local clicknum = 0;
				if j == 1 then
					clicknum=(i-1)*16+13
				else
					clicknum=(i-1)*16+j-1
				end
				table.insert(cardlist,index,clicknum)
				dump(cardlist,"cardlist:")
				index=index+1;
			end)
		end
	end
	for i = 1,3 do
		local Image_x = seekNodeByName(Panel_1,"Image_x_"..i)
		Image_x:loadTexture("res/card/cardback_0.png")
		Image_x:addClickEventListener(function()
			table.remove(cardlist,index)
			dump(cardlist,"cardlist:")
			index=index-1;
			Image_x:loadTexture("res/card/cardback_0.png")
		end)
	end
	local Button_cancle = seekNodeByName(Panel_1,"Button_cancle")
	Button_cancle:addClickEventListener(function()
		configLayer:removeFromParent();
	end)
	local Button_ok = seekNodeByName(Panel_1,"Button_ok")
	Button_ok:addClickEventListener(function()
		dump(cardlist,"cardlist:")
		index=1;
		GameSceneModule:getInstance():request_usercard(cardlist)
		configLayer:removeFromParent();
		
	end)
	
end


function GameBaseLayer:response_sendCard(resp_json)
	if resp_json ~= nil and resp_json.allCountZhu ~= nil then
		self:updateAllCoin(resp_json.allCountZhu)
	end
end
--结算时候，更新轮数
function GameBaseLayer:response_showOver(resp_json)
	--更新轮数
	if resp_json ~= nil and resp_json.iTurnNum ~= nil and resp_json.iTotalTurnLimit ~= nil  then
		self:updateLunNum(resp_json.iTurnNum,resp_json.iTotalTurnLimit)
	end
end
--新一局重新开始的时候，清空部分数据
function GameBaseLayer:response_resetGame(resp_json)
	self:updateAllCoin(0)
	self:updateLunNum(0,10);
end

--某一个玩家下注
function GameBaseLayer:response_startXiazhu(resp_json)
	if resp_json ~= nil and resp_json.allCountZhu ~= nil then
		self:updateAllCoin(resp_json.allCountZhu)
	end
	--更新轮数
	if resp_json ~= nil and resp_json.iTurnNum ~= nil and resp_json.iTotalTurnLimit ~= nil  then
		self:updateLunNum(resp_json.iTurnNum,resp_json.iTotalTurnLimit)
	end
end
--某玩家下了多少注
function GameBaseLayer:response_userXiaZhu(resp_json)
	if resp_json ~= nil and resp_json.allCountZhu ~= nil then
		self:updateAllCoin(resp_json.allCountZhu)
	end
end
--比牌后，更新当前桌面总注数
function GameBaseLayer:response_compairCard(resp_json)
	if resp_json ~= nil and resp_json.allCountZhu then
		self:updateAllCoin(resp_json.allCountZhu)
	end
end
--断线重连
function GameBaseLayer:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().gameUnStartStation or
		resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE  then
		self:updateDataByJson(resp_json)
		
		self:updateAllCoin(0)
		

	elseif resp_json.GameStation == self.parent:getGameStationEnum().GS_XIAZHU  then
		self:updateDataByJson(resp_json)
		if resp_json ~= nil and resp_json.allCountZhu then
			self:updateAllCoin(resp_json.allCountZhu)
		end
		
	end
	if resp_json.iCurRounds ~= nil and resp_json.iMaxRounds ~= nil then
		self:updateFangJu(resp_json.iCurRounds,resp_json.iMaxRounds)
	end
end


return GameBaseLayer


--endregion
