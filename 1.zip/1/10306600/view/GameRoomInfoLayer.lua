--[[
显示房间信息界面
]]
local GameAddCoinLayer = import(".GameAddCoinLayer")
local GameRoomInfoLayer = class("GameRoomInfoLayer",function()
	return cc.CSLoader:createNode("game/messageinfo.csb")
end)

function GameRoomInfoLayer:ctor(parent)
    self.parent = parent
	
	--关闭按钮
	local btn_close = seekNodeByName(self,"btn_close") 
	if btn_close ~= nil then
		btn_close:addClickEventListener(function()
			self:removeFromParent();
		end)
	end
	--解散房间
	local Button_jiesan = seekNodeByName(self,"Button_jiesan")
	if Button_jiesan ~= nil then
		Button_jiesan:addClickEventListener(function()
			local function relase_groom()
				self.parent:reqDissmisDesk(0)
				self:removeFromParent()
			end
			Msg:showMsg(2, "是否解散房间?", relase_groom)
		end)
	end
	--允许聊天
	local Button_allow_chat = seekNodeByName(self,"Button_allow_chat")
	if Button_allow_chat ~= nil then
		Button_allow_chat:addClickEventListener(function()
			
		end)
	end
	--允许加入
	local Button_allow_join = seekNodeByName(self,"Button_allow_join")
	if Button_allow_join ~= nil then
		Button_allow_join:addClickEventListener(function()
			
		end)
	end
	--联系房主
	local Button_touchmast = seekNodeByName(self,"Button_touchmast")
	if Button_touchmast ~= nil then
		Button_touchmast:addClickEventListener(function()
			--self.parent:addChild()
			--self:removeFromParent()
			self:showAskMaskAddCoin()
		end)
	end
	--分享
	local Image_share = seekNodeByName(self,"Image_share")
	if Image_share ~= nil then
		Image_share:addClickEventListener(function()
			local str = "一齐来嗨拼三张!";
			if self.parent:isQzProject() == true then
				local deskInfo = self.parent:getDeskInfo();
				str = string.format("一齐来嗨拼三张!%s","房号:"..deskInfo.roomKey)
			end
			self.parent:reqShareToWXSession(lua_to_plat:get_app_name().."[拼三张]",str);
		end)
	end
	
	self:update_Panel_text()
	self:setTextTime()
	self:registerScriptHandler(handler(self,self.onNodeEvent))
end
--联系房主界面
function GameRoomInfoLayer:showAskMaskAddCoin()
	self:setVisible(false)
	self.parent:addChild(GameAddCoinLayer.new(self.parent,10000),100)
end
--界面上的倒计时
function GameRoomInfoLayer:setTextTime()
	local Panel_text = seekNodeByName(self,"Panel_text")
	local Text_room_time = seekNodeByName(Panel_text,"Text_room_time")
	local Text_room_timestr = seekNodeByName(Text_room_time,"Text_2")
	local deskInfo = self.parent:getDeskInfo();
	local time_s = deskInfo.leaveTime%60
	local time_m = (deskInfo.leaveTime-time_s)/60%60
	local time_h = ((deskInfo.leaveTime-time_s)/60-time_m)/60
	Text_room_timestr:setString(string.format("%02d:%02d:%02d", time_h, time_m, time_s))
end

function GameRoomInfoLayer:onNodeEvent(event)
    if event == "enter" then
        g_pushBombBox(self)
        self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
           self:setTextTime()
			local deskInfo = self.parent:getDeskInfo();
           if deskInfo.leaveTime<=0 then
               if self.schedule_handle~=nil then
                   g_scheduler:unscheduleScriptEntry(self.schedule_handle)
                   self.schedule_handle = nil
               end
            end
        end,
        1.0, 
        false)
    elseif event == "exit" then
        g_popBombBox(self)
        if self.schedule_handle~=nil then
            g_scheduler:unscheduleScriptEntry(self.schedule_handle)
            self.schedule_handle = nil
        end
    end

end
--[["config" = {
    "Round" = {
        "RoomCard" = 1
        "Round"    = 4
        "desc"     = "4局（房卡*1）"
        "id"       = 1
    }
    "item1" = {
        "baozijiangli" = 30
        "isbaozi"      = true
        "roomname"     = "chenchao的房间"
    }
    "item3" = {
        "bipai"    = 1
        "menpaibi" = true
    }
    "item4" = {
        "kanpai" = 1
    }
    "item5" = {
        "dizhunum" = 2
        "startFen" = 220
    }
    "item6" = {
        "danZhu"   = 5
        "lunLimit" = 5
    }
    "item7" = {
        "sitNum" = 30
    }
}]]
--更新Panel_text中的文字显示部分
function GameRoomInfoLayer:update_Panel_text()
	local Panel_text = seekNodeByName(self,"Panel_text")
	--房间名称
	local Text_roomname = seekNodeByName(Panel_text,"Text_roomname")
	local Text_roomnamestr = seekNodeByName(Text_roomname,"Text_2")
	local deskInfo = self.parent:getDeskInfo();
	dump(deskInfo,"deskInfo:")
	if deskInfo ~= nil then
		if deskInfo.config ~= nil and deskInfo.config.item1 ~= nil and deskInfo.config.item1.roomname~= nil then
			Text_roomnamestr:setString(deskInfo.config.item1.roomname)
		end 
	end
	--房主
	local Text_room_mast = seekNodeByName(Panel_text,"Text_room_mast")
	local Text_room_maststr = seekNodeByName(Text_room_mast,"Text_2")
	if deskInfo ~= nil and deskInfo.mastUserNick ~= nil then
		Text_room_maststr:setString(deskInfo.mastUserNick)
	end
	--房号
	local Text_room_roomkey = seekNodeByName(Panel_text,"Text_room_roomkey")
	local Text_room_roomkeystr = seekNodeByName(Text_room_roomkey,"Text_2")
	if deskInfo ~= nil and deskInfo.roomKey ~= nil then
		Text_room_roomkeystr:setString(deskInfo.roomKey)
	end 
	--玩家
	local Text_room_player = seekNodeByName(Panel_text,"Text_room_player")
	local Text_room_playerstr = seekNodeByName(Text_room_player,"Text_2")
	
	--封顶
	local Text_room_fengding = seekNodeByName(Panel_text,"Text_room_fengding")
	local Text_room_fengdingstr = seekNodeByName(Text_room_fengding,"Text_2")
	if deskInfo ~= nil and deskInfo.config ~= nil and deskInfo.config.item6 ~= nil and deskInfo.config.item6.danZhu ~= nil then
		Text_room_fengdingstr:setString(deskInfo.config.item6.danZhu)
	end
	--倒计时
	local Text_room_time = seekNodeByName(Panel_text,"Text_room_time")
	local Text_room_timestr = seekNodeByName(Text_room_time,"Text_2")
	
	--初始分数
	local Text_room_startscore = seekNodeByName(Panel_text,"Text_room_startscore")
	local Text_room_startscorestr = seekNodeByName(Text_room_startscore,"Text_2")
	if deskInfo ~= nil and deskInfo.config ~= nil and deskInfo.config.item5 ~= nil and deskInfo.config.item5.startFen ~= nil then
		Text_room_startscorestr:setString(deskInfo.config.item5.startFen)
	end
	--局数
	local Text_room_junum = seekNodeByName(Panel_text,"Text_room_junum")
	local Text_room_junumstr = seekNodeByName(Text_room_junum,"Text_2")
	if deskInfo ~= nil and deskInfo.config ~= nil and deskInfo.config.Round ~= nil and deskInfo.config.Round.Round ~= nil then
		Text_room_junumstr:setString(deskInfo.config.Round.Round)
	end
	--底注
	local Text_room_dizhu = seekNodeByName(Panel_text,"Text_room_dizhu")
	local Text_room_dizhustr = seekNodeByName(Text_room_dizhu,"Text_2")
	if deskInfo ~= nil and deskInfo.config ~= nil and deskInfo.config.item5 ~= nil and deskInfo.config.item5.dizhunum ~= nil then
		Text_room_dizhustr:setString(deskInfo.config.item5.dizhunum)
	end
	--轮数
	local Text_room_limitlun = seekNodeByName(Panel_text,"Text_room_limitlun")
	local Text_room_limitlunstr = seekNodeByName(Text_room_limitlun,"Text_2")
	if deskInfo ~= nil and deskInfo.config ~= nil and deskInfo.config.item6 ~= nil and deskInfo.config.item6.lunLimit ~= nil then
		Text_room_limitlunstr:setString(deskInfo.config.item6.lunLimit)
	end
	--三条玩法规则
	local Text_bi = seekNodeByName(Panel_text,"Text_bi")
	local Text_kan = seekNodeByName(Panel_text,"Text_kan")
	local Text_menbi = seekNodeByName(Panel_text,"Text_menbi")
	if deskInfo ~= nil and deskInfo.config ~= nil and deskInfo.config.item3 ~= nil and deskInfo.config.item3.bipai ~= nil then
		local bipai = deskInfo.config.item3.bipai
		if bipai == 1 then
			Text_bi:setString("一回合后可比牌")
		elseif bipai == 2 then
			Text_bi:setString("三回合后可比牌")
		end
		local menpaibi = deskInfo.config.item3.menpaibi
		if menpaibi ~= nil then
			if menpaibi == true then
				Text_menbi:setString("可以和闷牌比牌")
			else
				Text_menbi:setString("不可以和闷牌比牌")
			end
		end
	end
	if deskInfo ~= nil and deskInfo.config ~= nil and deskInfo.config.item4 ~= nil and deskInfo.config.item4.kanpai ~= nil then
		local kanpai = deskInfo.config.item4.kanpai
		if kanpai == 1 then
			Text_kan:setString("随时可以看牌")
		elseif kanpai == 2 then
			Text_kan:setString("一回合后可以看牌")
		elseif kanpai == 3 then
			Text_kan:setString("三回合后可以看牌")
		else
			Text_kan:setString("随时可以看牌")
		end
	end
	
end

return GameRoomInfoLayer


--endregion
