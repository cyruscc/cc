--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_download = import("....common.download")

local GamePlayerLayer = class("GamePlayerLayer")

local TAG_PLAYER={}
TAG_PLAYER.Tag_zhang = 101;---庄
function GamePlayerLayer:ctor(parent,rootNode)
    self.parent = parent

    self.playerRootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	--self:onPlayerSitShow(true)
	--self.selectPlayer={};
	self.userPlayer = {}
	self.Image_1 = seekNodeByName(rootNode,"Image_1")
	self.Image_1:setVisible(false)
	self:init();
	self.playerTime = -1;
end
function GamePlayerLayer:init()
	for i = 1,self.playerCount do
		local Image_playerx = seekNodeByName(self.playerRootNode,"Image_player"..i)
		Image_playerx:setVisible(false)
		table.insert(self.userPlayer,i,Image_playerx)
	end
	
end
--对外接扣，根据服务端位置获取当前座位位置
function GamePlayerLayer:getPositionByChair(dDeskIndex)
	local user_chair = self.parent:getHelper():DeskStation2View(dDeskIndex)
	if user_chair >0 and user_chair<=self.playerCount then
		return self.userPlayer[user_chair]:getPosition();
	end
end

function GamePlayerLayer:showUserSit()
	self:resetUserPlayer()

	self:showUserSitdownPlayer()
end
--重置所有座位号
function GamePlayerLayer:resetUserPlayer()
	self.Image_1:setVisible(false)
	for i = 1,self.playerCount do
		self.userPlayer[i]:setVisible(false)
	end
end
function GamePlayerLayer:setUserSit(viewChair,visible)
	if viewChair>0 and viewChair<=self.playerCount then
		self.userPlayer[viewChair]:setVisible(visible)
		if viewChair == 1 then
			self.Image_1:setVisible(visible)
		end
	end
end
--超时加时，头像置灰
function GamePlayerLayer:response_outOfXiaZhuTime(resp_json)
	if resp_json ~= nil and resp_json.CurrentXiaZhustation ~= nil then
		local user_chair = self.parent:getHelper():DeskStation2View(resp_json.CurrentXiaZhustation)
		self:removeAllTimes();
		self.userPlayer[user_chair]:setOpacity(80)
	end
end
--结束超时加时
function GamePlayerLayer:response_outOfTimeOver(resp_json)
	if resp_json ~= nil and resp_json.CurrentXiaZhustation ~= nil then
		local user_chair = self.parent:getHelper():DeskStation2View(resp_json.CurrentXiaZhustation)
		self.userPlayer[user_chair]:setOpacity(255)
	end
end
--显示左右坐下玩家
function GamePlayerLayer:showUserSitdownPlayer()
	local playerDeskMap = self.parent:getSitDownPlayerMap()
	for k,v in pairs(playerDeskMap) do
		self:showOneUser(v)
	end
end
function GamePlayerLayer:showOneUser(userinfo)
	local user_chair = self.parent:getHelper():DeskStation2View(userinfo.bDeskStation)--userinfo.bDeskStation
	print("user_chair:"..user_chair)
	print("userinfo.avatarUrl:"..userinfo.avatarUrl)
	if user_chair >0 and user_chair<=self.playerCount then
		self.userPlayer[user_chair]:setVisible(true)
		if user_chair == 1 then
			self.Image_1:setVisible(true)
		end
		--更新用户的Image_head
		local Image_head = seekNodeByName(self.userPlayer[user_chair],"Image_head")
		if Image_head ~= nil and userinfo.avatarUrl ~= nil and userinfo.avatarUrl ~= "" then
			m_download:get_instance():set_head_image_and_auto_update( Image_head , userinfo.avatarUrl , userinfo.dwUserID)
		else
			Image_head:loadTexture("res/boy0.png")
		end
		--更新用户昵称
		local Text_name = seekNodeByName(self.userPlayer[user_chair],"Text_name")
		if Text_name ~= nil then
			Text_name:setString(api_get_ascll_sub_str_by_ui(userinfo.nickName,9))
		end
		--更新用户的Text_userid
		local Text_userid = seekNodeByName(self.userPlayer[user_chair],"Text_userid")
		if Text_userid ~= nil then
			Text_userid:setString(userinfo.dwUserID)
		end
	end
end
--用户弃牌的时候，头像置灰
function GamePlayerLayer:response_showQiCard(resp_json)
	if resp_json ~= nil and resp_json.chair ~= nil then
		local user_chair = self.parent:getHelper():DeskStation2View(resp_json.chair)
		self.userPlayer[user_chair]:setOpacity(80)
	end	
end
--开始新一局，游戏头像要还原
function GamePlayerLayer:response_resetGame(resp_json)
	print("GamePlayerLayer:response_resetGame")
	for i =1, self.playerCount do
		local isvis = self.userPlayer[i]:isVisible()
		if self.userPlayer[i]:isVisible() == true then
			self.userPlayer[i]:setOpacity(255)
		end
	end
end
--准备状态，刷新用户分数
function GamePlayerLayer:gameReady(resp_json)
	
end
function GamePlayerLayer:selectPlayerCallBack(callback)
	self.selectPlayer = nil;
	self.selectPlayer={}
	self.selectPlayerCallBack = callback;
end

function GamePlayerLayer:ready(resp_json)
	--self:init()
	--self:game_start(resp_json)
end


function GamePlayerLayer:HeadWaitTime(playerbg,iThinkTime,iTotalTime)
	local actionTo = CCProgressFromTo:create(iThinkTime, (iThinkTime/iTotalTime)*100,0)
	local progress = CCProgressTimer:create(CCSprite:create('res/time/daojishi.png'))--gameres/b05.png
	progress:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
	progress:setAnchorPoint(0,0)
	progress:setReverseDirection(true); 
	--progress:setMidpoint(cc.p(0, 0.5))
	local sequence = cc.Sequence:create(actionTo,cc.CallFunc:create(
		function() 
			print("移除进度条")
			progress:removeFromParent()
            if callback ~= nil then
				callback()
			end
        end))
	sequence:setTag(107)
	progress:runAction(sequence)
	progress:setBarChangeRate(cc.p(0, 1))
	progress:setPosition(7,30)
	progress:setTag(109)
	playerbg:addChild(progress)
end
--移除所有倒计时
function GamePlayerLayer:removeAllTimes()
	for i=1,self.playerCount do
		if self.userPlayer[i]:isVisible() == true and self.userPlayer[i]:getChildByTag(109) ~= nil then
			self.userPlayer[i]:removeChildByTag(109)
			self.playerTime = -1;
		end
	end
end

--收到服务器通知下注时候要显示倒计时
function GamePlayerLayer:response_startXiazhu(resp_json)
	print("GamePlayerLayer....response_startXiazhu")
	if resp_json ~= nil and resp_json.CurrentXiaZhustation ~= nil and resp_json.iThinkTime ~= nil then
		local currentIndex = resp_json.CurrentXiaZhustation;
		local currentView = self.parent:getHelper():DeskStation2View(currentIndex)
		local time = resp_json.iThinkTime
		print("开始进行倒计时："..currentView)
		--self.playerTime = currentIndex;
		self:HeadWaitTime(self.userPlayer[currentView],time,time)
	end
end
--收到有人下注时，停止当前所有倒计时
function GamePlayerLayer:response_userXiaZhu(resp_json)
	self:removeAllTimes()
end
--收到比牌消息时，停止当前所有倒计时
function GamePlayerLayer:response_compairCard(resp_json)
	self:removeAllTimes()
	performWithDelay(self.playerRootNode, function ()
		if resp_json ~= nil and resp_json.failPlayer ~= nil then
			local user_chair = self.parent:getHelper():DeskStation2View(resp_json.failPlayer)
			self.userPlayer[user_chair]:setOpacity(80)
		end
	end, 1)
end
--排队场用户金币变化
function GamePlayerLayer:user_score_change(code,score_info)
	dump(score_info,"score_info:")
	local userinfo =self.parent:getPlayerInfoByUserID(score_info.dwUserID)
	dump(userinfo,"userinfo:")
	local user_chair = self.parent:getHelper():DeskStation2View(userinfo.bDeskStation)
	local Panel_itemPlayer = seekNodeByName(self.playerRootNode,"Panel_itemPlayer"..(user_chair))
	--local userinfo = self.parent:getPlayerInfoByChairID(playerData[i].chair)
	if Panel_itemPlayer ~= nil then
		local text_money_num = seekNodeByName(Panel_itemPlayer,"text_money_num")
		local money = userinfo.dwMoney
		text_money_num:setString(money)
	end
end
--当局总结算，总结算时候，需要在当前用户头像上显示牌型动画
--[[{
    "cards" = {
        1 = {
            card = *MAX NESTING*
            "cardtype" = 2
            "chair"    = 0
        }
        2 = {
            card = *MAX NESTING*
            "cardtype" = 2
            "chair"    = 1
        }
    }
    "points" = {
        1 = {
            "chair"  = 0
            "npoint" = 990
        }
        2 = {
            "chair"  = 1
            "npoint" = 1010
        }
    }
    "winPlayer" = 1
}]]
function GamePlayerLayer:response_showOver(resp_json)
	dump(resp_json,"resp_json:")
	self:response_resetGame()
	self:removeAllTimes();
end
--更加数据获取当前赢家的牌型
function GamePlayerLayer:getCardTypeByWinPalyer(baseData,winPlayer)
	if baseData ~= nil and #baseData>0 and winPlayer ~= nil then
		for i = 1,#baseData do
			if baseData[i].chair ~= nil and baseData[i].chair == winPlayer then
				return baseData[i].cardtype
			end
		end
	end
	return nil
end

--断线重连
function GamePlayerLayer:onGameStation(resp_json)
	--if resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_YAOTOUZI
		--or resp_json.GameStation == self.parent:getGameStationEnum().DH_WAIT_XUANZHAI then
		print("GamePlayerLayer  onGameStation")
		
		--self:game_start(resp_json)
		
	if resp_json.GameStation == self.parent:getGameStationEnum().GS_XIAZHU then
		--如果是下注状态，检查当前是否需要显示倒计时
		if resp_json.nowXiazhuType ~= nil and resp_json.nowXiazhuType == 0 
			and resp_json.iLeaverTime ~= nil and resp_json.iLeaverTime>0 
			and resp_json.iThinkTime ~= nil and resp_json.iThinkTime >0 
			and resp_json.CurrentXiaZhustation ~= nil and resp_json.CurrentXiaZhustation>=0 then
			self:removeAllTimes();
			local iLeaverTime = resp_json.iLeaverTime;
			local iThinkTime = resp_json.iThinkTime
			local currentstation = resp_json.CurrentXiaZhustation
			local currentView = self.parent:getHelper():DeskStation2View(currentstation)
			self:HeadWaitTime(self.userPlayer[currentView],iLeaverTime,iThinkTime)
		end
	else
		self:removeAllTimes();
	end
end
return GamePlayerLayer


--endregion
