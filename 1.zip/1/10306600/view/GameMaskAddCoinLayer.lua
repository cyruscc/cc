--[[
游戏内房主申请加分信息显示界面
]]
local m_clientmain = import("....room.clientmain")
local m_download = import("....common.download")
local GameMaskAddNumCoinLayer = import(".GameMaskAddNumCoinLayer")
local GameMaskAddCoinLayer = class("GameMaskAddCoinLayer",function()
	return cc.CSLoader:createNode("game/askmessageLayer.csb")
end)

function GameMaskAddCoinLayer:ctor(parent)
    self.parent = parent
	
	--关闭按钮
	local Image_close = seekNodeByName(self,"Image_close")
	Image_close:addClickEventListener(function()
		self:removeFromParent();
	end)
	self.ListView_1= seekNodeByName(self,"ListView_1")
	if self.ListView_1 ~= nil then
		self.ListView_1:removeAllChildren()
	end
	self.Image_Item = seekNodeByName(self,"Image_Item")
	if self.Image_Item ~= nil then
		self.Image_Item:setVisible(false)
	end
	self.Text_no_tips = seekNodeByName(self,"Text_no_tips")
	if self.Text_no_tips ~= nil then
		self.Text_no_tips:setVisible(true)
	end
	
	self:updateList();
end
--[["apply_list:" = {
    1 = {
        "apply_content" = {
            "addPoint" = 6068
        }
        "apply_desc"            = ""
        "apply_id"              = 180
        "apply_time"            = 1495521749
        "apply_type"            = 1
        "apply_user_headStr"    = ""
        "apply_user_id"         = 87608
        "apply_user_nickName"   = "111"
        "apply_user_tablePoint" = 0
        "desk_game_id"          = 10306600
        "desk_id"               = 9058
        "desk_ip"               = "192.168.0.32"
        "desk_key"              = "810251"
        "desk_name"             = "2222222"
        "desk_port"             = 8425
    }
}]]
function GameMaskAddCoinLayer:updateList()
	self.apply_list = m_clientmain:get_instance():get_desk_mgr():get_apply_list()
	if self.ListView_1 == nil or self.Image_Item == nil then
		return;
	end
	self.ListView_1:removeAllChildren()
	local apply_list = self.apply_list;
	dump(apply_list,"apply_list:")
	if apply_list == nil or #apply_list<1 then
		self.Text_no_tips:setVisible(true)
		return 
	else
		self.Text_no_tips:setVisible(false)
	end
	local Image_head = nil;
	local Text_name = nil;
	local Text_Id = nil;
	local Text_roomkey = nil;
	local Text_score = nil
	local Text_askScore = nil;
	local Image_addFen = nil;
	local Image_enterRoom = nil
	local Image_deleteMessage = nil;
	for i = 1,#apply_list do
		local panel_Item = self.Image_Item:clone()
        panel_Item:setVisible(true)
		--更新头像
		Image_head = seekNodeByName(panel_Item,"Image_head")
		Text_name = seekNodeByName(panel_Item,"Text_name")
		Text_Id = seekNodeByName(panel_Item,"Text_Id")
		Text_roomkey = seekNodeByName(panel_Item,"Text_roomkey")
		Text_score = seekNodeByName(panel_Item,"Text_score")
		Text_askScore = seekNodeByName(panel_Item,"Text_askScore")
		Image_addFen = seekNodeByName(panel_Item,"Image_addFen")
		Image_enterRoom = seekNodeByName(panel_Item,"Image_enterRoom")
		Image_deleteMessage = seekNodeByName(panel_Item,"Image_deleteMessage")
		if Image_head ~= nil and apply_list[i].apply_user_headStr ~= nil and #(apply_list[i].apply_user_headStr)>0 then
			m_download:get_instance():set_head_image_and_auto_update( Image_head , apply_list[i].apply_user_headStr , apply_list[i].apply_user_id)
		end
		if Text_name ~= nil then
			if apply_list[i].apply_user_nickName ~= nil then
				Text_name:setString(apply_list[i].apply_user_nickName)
			else
				Text_name:setVisible(false)
			end
		end
		if Text_Id ~= nil then
			if apply_list[i].apply_user_id ~= nil then
				Text_Id:setString("ID:"..apply_list[i].apply_user_id)
			else
				Text_Id:setVisible(false)
			end
		end
		if Text_roomkey ~= nil then
			if apply_list[i].desk_key ~= nil then
				Text_roomkey:setString("房间:"..apply_list[i].desk_key)
			else
				Text_roomkey:setVisible(false)
			end
		end
		if Text_score ~= nil then
			if apply_list[i].apply_user_tablePoint ~= nil then
				Text_score:setString("他的分数:"..apply_list[i].apply_user_tablePoint)
			else
				Text_score:setVisible(false)
			end
		end
		if Text_askScore ~= nil then
			if apply_list[i].apply_content ~= nil and apply_list[i].apply_content.addPoint ~= nil then
				Text_askScore:setString(string.format("我要上%d分",apply_list[i].apply_content.addPoint))
			else
				Text_askScore:setVisible(false)
			end
		end
		if Image_addFen ~= nil then
			Image_addFen:addClickEventListener(function()
				print("2222")
				self:addUserCoinLayer(apply_list[i])
			end)
		end
		if Image_enterRoom ~= nil then
			Image_enterRoom:addClickEventListener(function()
				print("Image_enterRoom")
			end)
		end
		if Image_deleteMessage ~= nil then
			Image_deleteMessage:addClickEventListener(function()
				print("Image_deleteMessage")
				Music:playEffect_click()
				api_show_loading_ext( 1 )
				m_clientmain:get_instance():get_desk_mgr():request_remove_apply_item( apply_list[i].apply_id )
				table.remove(self.apply_list,i)
				self:updateList()
			end)
		end
        self.ListView_1:pushBackCustomItem(panel_Item)
	end
	
end

function GameMaskAddCoinLayer:addUserCoinLayer(data)
	self:addChild(GameMaskAddNumCoinLayer.new(self.parent,data))
end


return GameMaskAddCoinLayer


--endregion
