--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local GameSetLayer = import(".GameSetLayer")
local GameRuleLayer = import(".GameRuleLayer")
local GameMenuLayer = class("GameMenuLayer",function()
	return cc.CSLoader:createNode("game/menuLayer.csb")
end)

function GameMenuLayer:ctor(parent)
	self.parent = parent
    local Panel_bg = seekNodeByName(self,"Panel_bg")
	Panel_bg:addClickEventListener(function()
		self:removeFromParent()
	end)
	
	local btn_setting = seekNodeByName(self,"btn_setting")
	btn_setting:addClickEventListener(function()
		local gamesetlayer = GameSetLayer.new(self.parent)
		self.parent:addChild(gamesetlayer)
		self:removeFromParent()
	end)
	local btn_paixing = seekNodeByName(self,"btn_paixing")
	btn_paixing:addClickEventListener(function()
		self.parent:addChild(GameRuleLayer.new(self.parent))
		self:removeFromParent()
	end)
	local btn_situp = seekNodeByName(self,"btn_situp")
	if self.parent:isAlreadySitdown() == true then
		if self.parent:getGameStation() == self.parent:getGameStationEnum().gameUnStartStation
				or self.parent:getGameStation() == self.parent:getGameStationEnum().GS_WAIT_ARGEE then	
			btn_situp:setOpacity(255)
			btn_situp:addClickEventListener(function()
				if self.parent:getGameStation() == self.parent:getGameStationEnum().gameUnStartStation
					or self.parent:getGameStation() == self.parent:getGameStationEnum().GS_WAIT_ARGEE then
					self.parent.isSendSitUp = true;
					self.parent:reqStandupDesk()
					self:removeFromParent() 
				else
					api_show_Msg_Tip("游戏中禁止玩家站起")
				end
			end)
		else
			btn_situp:setOpacity(80)
			btn_situp:addClickEventListener(function() end)
		end
	else
		btn_situp:setOpacity(80)
		btn_situp:addClickEventListener(function() end)
	end
	local btn_dismiss = seekNodeByName(self,"btn_dismiss")
	if self.parent:isMast() == true then
		btn_dismiss:setOpacity(255)
		btn_dismiss:addClickEventListener(function()
			
			if self.parent:getGameStation() == self.parent:getGameStationEnum().gameUnStartStation
				or self.parent:getGameStation() == self.parent:getGameStationEnum().GS_WAIT_ARGEE then
				api_show_Msg_Box("确认解散房间吗?",function()
					self.parent:reqDissmisDesk(0)
					self:removeFromParent()
				end)
			else
				api_show_Msg_Box("游戏进行中，不能结算房间。",function()
					--self.parent:reqDissmisDesk(0)
					self:removeFromParent()
				end)
			end
			
		end)
	else
		btn_dismiss:setOpacity(80)
		btn_dismiss:addClickEventListener(function()
			--api_show_Msg_Box_one("非房主不能解散房间")
		end)
	end
	local Image_menubg = seekNodeByName(self,"Image_menubg")
	if self.parent:isQzProject() == false then
		Image_menubg:setSize(Image_menubg:getSize().width,200)
		btn_setting:setPosition(cc.p(btn_dismiss:getPositionX(),btn_dismiss:getPositionY()))
		btn_dismiss:setVisible(false)
		btn_situp:setVisible(false)
	end
	local btn_exit = seekNodeByName(self,"btn_exit")
	if self.parent:getGameStation() == self.parent:getGameStationEnum().gameUnStartStation
			or self.parent:getGameStation() == self.parent:getGameStationEnum().GS_WAIT_ARGEE 
			or self.parent.userIsQi == true then	
		btn_exit:setOpacity(255)
		btn_exit:addClickEventListener(function()
			if self.parent:getGameStation() == self.parent:getGameStationEnum().gameUnStartStation
				or self.parent:getGameStation() == self.parent:getGameStationEnum().GS_WAIT_ARGEE 
				or self.parent.userIsQi == true then
				self.parent.isSendSitUp = true;
				self.parent:reqStandupDesk()
				self.parent:Exit_game()
				self:removeFromParent() 
			else
				api_show_Msg_Tip("游戏中禁止玩家离开")
			end
		end)
	else
		btn_exit:setOpacity(80)
		btn_exit:addClickEventListener(function() end)
	end
		
	
end


return GameMenuLayer


--endregion
