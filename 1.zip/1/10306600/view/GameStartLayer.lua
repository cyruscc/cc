--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameStartLayer = class("GameStartLayer")

function GameStartLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	
	self:init()
end

function GameStartLayer:init()
	self.Image_tip = seekNodeByName(self.rootNode,"Image_tip")
	if self.Image_tip ~= nil then
		self.Image_tip:setVisible(false)
	end
	self.Button_kaizuo = seekNodeByName(self.rootNode,"Button_kaizuo")
	if self.Button_kaizuo ~= nil then
		self.Button_kaizuo:setVisible(false)
		self.Button_kaizuo:addClickEventListener(function()
			self.parent:reqStartDesk();
			self.Button_kaizuo:setVisible(false)
		end)
	end
	self.Button_zhunbei = seekNodeByName(self.rootNode,"Button_zhunbei")
	if self.Button_zhunbei ~= nil then
		self.Button_zhunbei:setVisible(false)
		self.Button_zhunbei:addClickEventListener(function()
			print("check_ready")
			self.parent:check_ready()
		end)
	end
end
--更新当前界面层显示
function GameStartLayer:updateButton(buttonname)
	if buttonname ~= nil and buttonname ~= "" then
		self.Image_tip:setVisible(buttonname=="Image_tip")
		self.Button_kaizuo:setVisible(buttonname=="Button_kaizuo")
		self.Button_zhunbei:setVisible(buttonname=="Button_zhunbei")
	else
		self.Image_tip:setVisible(false)
		self.Button_kaizuo:setVisible(false)
		self.Button_zhunbei:setVisible(false)
	end
end
--房主开桌消息返回
function GameStartLayer:deskStart()
	if self.parent:isAlreadySitdown() then
		self:updateButton("Button_zhunbei")
	else
		self:updateButton()
	end

end
--收到玩家准备
function GameStartLayer:resp_player_ready(resp_json)
	local userinfo = self.parent:getSelfInfo()
	if self.parent:getUserIsReady(userinfo.dwUserID)==true  then
		self:updateButton()
	else
		self:updateButton("Button_zhunbei")
	end
	--如果自己没有坐下，这个层不显示任何东西
	if self.parent:isAlreadySitdown() == false then
		self:updateButton()
	end
end
--收到结算时候的操作
function GameStartLayer:response_showOver(resp_json)
	
end
function GameStartLayer:response_resetGame(resp_json)
	self:updateButton("Button_zhunbei")
	--如果自己没有坐下，这个层不显示任何东西
	if self.parent:isAlreadySitdown() == false then
		self:updateButton()
	end
end
--断线重连
function GameStartLayer:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().gameUnStartStation or
		resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE  then
		if self.parent:isAlreadySitdown() == true then
			if resp_json.deskActive ~= nil then
				if resp_json.deskActive == false then
					if self.parent:isMast() == true then
						self:updateButton("Button_kaizuo")
					else
						self:updateButton("Image_tip")
					end
				else
					--检查自己是否已经准备，如果准备了
					local userinfo = self.parent:getSelfInfo()
					if self.parent:getUserIsReady(userinfo.dwUserID)==true  then
						self:updateButton()
					else
						self:updateButton("Button_zhunbei")
					end
				end
			end
		else
			self:updateButton()
		end
	elseif resp_json.GameStation == self.parent:getGameStationEnum().GS_XIAZHU  then
		self:updateButton()
	end
end

return GameStartLayer
