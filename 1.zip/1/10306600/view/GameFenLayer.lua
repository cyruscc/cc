--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameFenLayer = class("GameFenLayer")

function GameFenLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.ImageJiaofen = {}
	self:init()
end

function GameFenLayer:init()
	for i = 1,self.playerCount do
		local fenbg = seekNodeByName(self.rootNode,"Image_fenbg"..i)
		fenbg:setVisible(false)
		table.insert(self.ImageJiaofen,i,fenbg)
	end
end
function GameFenLayer:closeAll()
	for i = 1,self.playerCount do
		self.ImageJiaofen[i]:setVisible(false)
	end
end
--叫分时，当前层的操作
--[[{"jiaofenStation":1,"m_TouziJiaofenTime":15,"userFenData":[{"chair":0,
"jiaofenDian":4,"jiaofenNum":3},{"chair":1,"jiaofenDian":0,"jiaofenNum":0}]}]]
function GameFenLayer:start_jiaofen(resp_table)
	self:closeAll()
	if resp_table == nil or resp_table.userFenData == nil or #(resp_table.userFenData)<1 then return end
	
	local listdata = resp_table.userFenData
	for i = 1,#listdata do
		local datachair = listdata[i].chair
		if resp_table.jiaofenStation ~= datachair then
			local user_chair = self.parent:getViewPosition(datachair)
			local jiaoFenNum = listdata[i].jiaofenNum
			local jiaofenDian = listdata[i].jiaofenDian
			if user_chair>0 and jiaoFenNum>0 or jiaofenDian>0 then
				self.ImageJiaofen[user_chair]:setVisible(true)
				local text_num = seekNodeByName(self.ImageJiaofen[user_chair],"text_num")
				local Image_dian = seekNodeByName(self.ImageJiaofen[user_chair],"Image_dian")
				text_num:setString(jiaoFenNum.."个")
				local pathtmp = string.format("gameres/touzinum/shaizi%d.png",jiaofenDian)
				--print("pathtmp:"..pathtmp)
				Image_dian:loadTexture(pathtmp)
			end 
		end
	end
end
function GameFenLayer:start_KaiResult(resp_table)
	self:closeAll()
end

return GameFenLayer


--endregion
