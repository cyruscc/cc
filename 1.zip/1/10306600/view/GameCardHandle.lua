--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
--牌的操作状态显示（看牌，弃牌，比牌输状态控制）


local GameCardHandle = class("GameCardHandle")

function GameCardHandle:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.Image_kan={}
	self.Image_qi={}
	self.Image_bishu={}
	self:init()
	self.sign={};
	self.sign["kan"] = self.Image_kan
	self.sign["qi"] = self.Image_qi
	self.sign["bishu"] = self.Image_bishu
	
end

function GameCardHandle:init()
	for i = 1,self.playerCount do
		local Image_kanx = seekNodeByName(self.rootNode,"Image_kan"..i)
		table.insert(self.Image_kan,i,Image_kanx)
		local Image_qiItem = seekNodeByName(self.rootNode,"Image_qi"..i)
		table.insert(self.Image_qi,i,Image_qiItem)
		local Image_bishuItem = seekNodeByName(self.rootNode,"Image_bishu"..i)
		table.insert(self.Image_bishu,i,Image_bishuItem)
	end
	self:closeKanAll();
	self:closeQiAll();
	self:closeBishuAll();
end
--关闭所有看牌显示
function GameCardHandle:closeKanAll()
	for i = 1,self.playerCount do
		self.Image_kan[i]:setVisible(false)
	end
end
--关闭所有弃牌显示
function GameCardHandle:closeQiAll()
	for i = 1,self.playerCount do
		self.Image_qi[i]:setVisible(false)
	end
end
--关闭所有比牌输显示
function GameCardHandle:closeBishuAll()
	for i = 1,self.playerCount do
		self.Image_bishu[i]:setVisible(false)
	end
end
--根据座位号显示某位置上的状态station代表状态，
function GameCardHandle:showHandleByPosition(chair,str)
	local list = self.sign[str];
	if chair == nil or chair=="" then
		return;
	end
	local userViewChair = self.parent:getHelper():DeskStation2View(chair)
	if userViewChair>0 and userViewChair<=self.playerCount then
		list[userViewChair]:setVisible(true)
	end
end
--[["<var>" = {
    "firstPlayer"  = 1
    "secondPlayer" = 0
    "winPlayer"    = 0
	"failPlayer"   = 1
}]]
function GameCardHandle:response_compairCard(resp_json)
	if resp_json ~= nil and resp_json.failPlayer ~= nil then
		self:showHandleByPosition(resp_json.failPlayer,"bishu")
	end
end
--看牌
function GameCardHandle:response_showLookCard(resp_json)
	if resp_json ~= nil and resp_json.chair ~= nil then
		self:showHandleByPosition(resp_json.chair,"kan")
	end
end

--有玩家弃牌
function GameCardHandle:response_showQiCard(resp_json)
	if resp_json ~= nil and resp_json.chair ~= nil then
		self:showHandleByPosition(resp_json.chair,"qi")
	end
end

--重新开始下一局
function GameCardHandle:response_resetGame(resp_json)
	self:closeKanAll();
	self:closeQiAll();
	self:closeBishuAll();
end

function GameCardHandle:onGameStation(resp_json)
	--首先检查是否看牌
	if resp_json ~= nil and resp_json.player ~= nil and resp_json.player.chairinfo ~= nil and #resp_json.player.chairinfo>0 then
		for i = 1,#resp_json.player.chairinfo do
			local looCard = resp_json.player.chairinfo[i].lookCard
			local chair = resp_json.player.chairinfo[i].chair
			local haveDiu = resp_json.player.chairinfo[i].haveDiu
			if looCard ~= nil and looCard == true and chair ~= nil then
				self:showHandleByPosition(chair ,"kan")
			end
			if chair ~= nil and haveDiu ~= nil and haveDiu>0 then
				if haveDiu == 1 then
					self:showHandleByPosition(chair ,"qi")
				elseif haveDiu == 2 then
					self:showHandleByPosition(chair ,"bishu")
				end
			end
		end
	end
end

return GameCardHandle
