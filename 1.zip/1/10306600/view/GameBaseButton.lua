--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameBaseButton = class("GameBaseButton")
local m_download = import("....common.download")

local GameSceneModule = import("..gameSceneModule")
function GameBaseButton:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self:init()
	self.rootNode:setVisible(false);
end
function GameBaseButton:init()
	self.btn_qi = seekNodeByName(self.rootNode,"btn_qi")
	
	self.btn_bi = seekNodeByName(self.rootNode,"btn_bi")
	self.btn_bi:addClickEventListener(function()

		self:addCompareSelectLayer(function(selectIndex)
			GameSceneModule:getInstance():request_player_compare(selectIndex);
		end)
	end)
	self.btn_kan = seekNodeByName(self.rootNode,"btn_kan")
	self.btn_kan:addClickEventListener(function()
		GameSceneModule:getInstance():request_player_Look();
	end)
	self.btn_jia = seekNodeByName(self.rootNode,"btn_jia")
	self.btn_jia:addClickEventListener(function()
		self:addShowCoinLayer()
	end)
	self.btn_gen = seekNodeByName(self.rootNode,"btn_gen")
	
	self.btn_gendaodi = seekNodeByName(self.rootNode,"btn_gendaodi")
	local Image_gen_selected = seekNodeByName(self.btn_gendaodi,"Image_gen_selected")
	Image_gen_selected:setVisible(false)
	self.btn_gendaodi:addClickEventListener(function()
		if Image_gen_selected:isVisible() == true then
			Image_gen_selected:setVisible(false)
		else
			Image_gen_selected:setVisible(true)
			local currentAction = self.buttonstation.CurrentXiaZhustation
			if currentAction == self.parent:getSelfInfo().bDeskStation then
				GameSceneModule:getInstance():request_player_Gen()
			end
		end
	end)
	self.Panel_addNumbg = seekNodeByName(self.rootNode,"Panel_addNumbg") 
	self.Panel_addNumbg:setVisible(false)
	self.Panel_addNumbg:addClickEventListener(function()
		if self.Panel_addNumbg:isVisible() == true then
			self.Panel_addNumbg:setVisible(false);
		end
	end)
	--self.Image_addnumbg = seekNodeByName(self.rootNode,"Image_addnumbg")
	--self.Image_addnumbg:setVisible(false);
end
--添加比牌选择用户的layer界面
function GameBaseButton:addCompareSelectLayer(callback)
	local nowGameCount = self:getNowGameCount()
	print("-----------------------------nowGameCount:"..nowGameCount)
	--如果当前只有两人，直接返回另外一个人的桌子号
	if nowGameCount == 2 then
		local compairUser = self:getNowGameCompair()
		if compairUser ~= nil then
			callback(compairUser)
			return;
		end
	end
	local path = "game/bipaiLayer.csb"
	local bipaiLayer = cc.CSLoader:createNode(path)
	
	self.parent:addChild(bipaiLayer)
	local Panel_bg = seekNodeByName(bipaiLayer,"Panel_bg")
	for i = 2,5 do
		local Image_persion = seekNodeByName(Panel_bg,"Image_"..i)
		--判断当前是否有人
		local bodyUser = self:getHaveUser(i)
		if bodyUser == nil then
			Image_persion:setVisible(false)
		else
			Image_persion:setVisible(true)
			--Image_persion:loadTxture()
			m_download:get_instance():set_head_image_and_auto_update( Image_persion , bodyUser.avatarUrl , bodyUser.dwUserID)
		end
		Image_persion:addClickEventListener(function()
			
			local deskStation = self.parent:getHelper():ViewStation2DeskStation(i)
			if callback~= nil then
				callback(deskStation)
			end
			bipaiLayer:removeFromParent();
		end)
	end
end
--查询该位置上是否有人
function GameBaseButton:getHaveUser(chair)
	if chair == nil or chair == "" then
		return;
	end
	local playerDeskMap = self.parent:getSitDownPlayerMap()
	for k,v in pairs(playerDeskMap) do
		local user_chair = self.parent:getHelper():DeskStation2View(v.bDeskStation)
		if chair == user_chair then
			return v;
		end
	end
end
--游戏开始时候，重置自动跟注
function GameBaseButton:game_start(resp_json)
	local Image_gen_selected = seekNodeByName(self.btn_gendaodi,"Image_gen_selected")
	Image_gen_selected:setVisible(false)
	self.rootNode:setVisible(true)
end

--
function GameBaseButton:addShowCoinLayer()
	if self.buttonstation ~= nil and self.buttonstation.addnums ~= nil then
		self.Panel_addNumbg:setVisible(true)
		--self.Image_addnumbg:setVisible(true);
		for i = 1,4 do
			local Image_item = seekNodeByName(self.Panel_addNumbg,"Image_item"..i)
			if self.buttonstation.nowlimit ~= nil and i<=self.buttonstation.nowlimit then
				Image_item:setOpacity(80)
				Image_item:addClickEventListener(function() end)
			else
				Image_item:setOpacity(255)
				Image_item:addClickEventListener(function()
					GameSceneModule:getInstance():request_player_Add(i)
				end)
			end
			local num = seekNodeByName(Image_item,"num")
			num:setString(self.buttonstation.addnums[i])
		end
	end
end
--隐藏当前所有button
function GameBaseButton:setAddLayer(isVisible)
	if type(isVisible) == "boolean" then
		self.Panel_addNumbg:setVisible(isVisible)
	end
end
--隐藏当前所有button
function GameBaseButton:setButtonVisible(isVisible)
	if type(isVisible) == "boolean" then
		self.rootNode:setVisible(isVisible)
	end
end
--服务器通知客户端进行加注或跟注
function GameBaseButton:response_userXiaZhu(resp_json)
	self:updateShowButton()
end
--按钮组在这里进行统一管理，每次只显示一组，不会多组同时显示
function GameBaseButton:updateShowButton()
	local userinfo = self.parent:getSelfInfo()
	if self.parent:isAlreadySitdown() == false or self.parent:checkUserInGame(userinfo.bDeskStation) == false then
		self.rootNode:setVisible(false)
	end
	--self:setButtonVisible(true)
	self.btn_qi:setVisible(true)
	self.btn_qi:setOpacity(80)
	self.btn_qi:addClickEventListener(function() end);
	
	self.btn_bi:setVisible(true)
	self.btn_bi:setOpacity(80)
	self.btn_bi:addClickEventListener(function() end);
	
	self.btn_kan:setVisible(true)
	self.btn_kan:setOpacity(80)
	self.btn_kan:addClickEventListener(function() end);
	
	self.btn_jia:setVisible(true)
	self.btn_jia:setOpacity(80)
	self.btn_jia:addClickEventListener(function() end);
	
	self.btn_gen:setVisible(true)
	self.btn_gen:setOpacity(80)
	self.btn_gen:addClickEventListener(function() end);
	
	if self.buttonstation ~= nil  then
		if self.buttonstation.isQi ~= nil and self.buttonstation.isQi == true then
				self.btn_qi:setOpacity(255)
				self.btn_qi:addClickEventListener(function() 
					self.Panel_addNumbg:setVisible(false)
					GameSceneModule:getInstance():request_player_Diu();
				end);
			end 
		local currentAction = self.buttonstation.CurrentXiaZhustation
		print("currentAction:"..currentAction..",,,,self.parent:getSelfInfo().bDeskStation:"..self.parent:getSelfInfo().bDeskStation)
		if currentAction ~= nil and currentAction == self.parent:getSelfInfo().bDeskStation then
			if self.buttonstation.isBi ~= nil then
				if  self.buttonstation.isBi == true then
					self.btn_bi:setOpacity(255)
					self.btn_bi:addClickEventListener(function()
						self:addCompareSelectLayer(function(selectIndex)
							self.Panel_addNumbg:setVisible(false)
							GameSceneModule:getInstance():request_player_compare(selectIndex);
						end)
					end)
				end
			end 
			if self.buttonstation.isAdd ~= nil and self.buttonstation.isAdd == true then
				if self.buttonstation.nowlimit ~= nil and self.buttonstation.nowlimit == 4 then
					self.btn_jia:setOpacity(255)
					self.btn_jia:loadTextures("res/btn/yifengding_btn.png","res/btn/yifengding_btn.png")
					self.btn_jia:addClickEventListener(function() end)
				else
					self.btn_jia:setOpacity(255)
					self.btn_jia:loadTextures("res/btn/jiazhu_btn.png","res/btn/jiazhu_btn_02.png")
					self.btn_jia:addClickEventListener(function()
						self:addShowCoinLayer()
					end)
				end
			end 
			if self.buttonstation.isGen ~= nil and self.buttonstation.isGen == true then
				self.btn_gen:setVisible(true)
				self.btn_gen:setOpacity(255)
				self.btn_gen:addClickEventListener(function()
					self.Panel_addNumbg:setVisible(false)
					GameSceneModule:getInstance():request_player_Gen()
				end)
			end 
			self.btn_gendaodi:setVisible(false)
		else
			self.btn_gendaodi:setVisible(true)
			self.btn_gen:setVisible(false)
		end
		if self.buttonstation.isLook ~= nil and self.buttonstation.isLook == true then
			self.btn_kan:setOpacity(255)
			self.btn_kan:addClickEventListener(function()
				self.Panel_addNumbg:setVisible(false)
				GameSceneModule:getInstance():request_player_Look();
			end)
		end 
	end
end

--[["<var>" = {
    "allCountZhu" = 20
    "chairinfo" = {
        1 = {
            "chair"      = 0
            "point"      = 990
            "tablePoint" = 10
        }
        2 = {
            "chair"      = 1
            "point"      = 990
            "tablePoint" = 10
        }
    }
    "isAdd"       = true
    "isBi"        = true
    "isGen"       = true
    "isLook"      = true
    "isQi"        = true
}]]
function GameBaseButton:response_sendCard(resp_json)
	self.buttonstation = resp_json
	self:setButtonVisible(true)
	self:updateShowButton();
end
--[[{
    "CurrentXiaZhustation" = 1
    "addnums" = {
        1 = 20
        2 = 30
        3 = 40
        4 = 50
    }
    "allCountZhu"          = 40
    "chairinfo" = {
        1 = {
            "chair"      = 0
            "point"      = 970
            "tablePoint" = 30
            "userdiu"    = 0
        }
        2 = {
            "chair"      = 1
            "point"      = 990
            "tablePoint" = 10
            "userdiu"    = 0
        }
    }
    "iDizhu"               = 10
    "iTurnNum"             = 2
    "isAdd"                = true
    "isBi"                 = true
    "isGen"                = true
    "isLook"               = true
    "isQi"                 = true
    "nowlimit"             = 0
}]]
function GameBaseButton:response_startXiazhu(resp_json)
	self.buttonstation = resp_json
	self:setAddLayer(false)
	self:setButtonVisible(true)
	self:updateShowButton();
	local currentAction = self.buttonstation.CurrentXiaZhustation
	if currentAction == self.parent:getSelfInfo().bDeskStation then
		performWithDelay(self.rootNode, function ()
			local Image_gen_selected = seekNodeByName(self.btn_gendaodi,"Image_gen_selected")
			if Image_gen_selected:isVisible() == true then
				if self.buttonstation ~= nil and self.buttonstation.CurrentXiaZhustation ~= nil then
					local currentAction = self.buttonstation.CurrentXiaZhustation
					if currentAction == self.parent:getSelfInfo().bDeskStation then
						GameSceneModule:getInstance():request_player_Gen()
					end
				end
			end
		end, 1)
	end
		
end
--计算当前没有丢牌的游戏中人数
function GameBaseButton:getNowGameCount()
	local nowgameCount = 0;
	if self.buttonstation ~= nil and self.buttonstation.chairinfo ~= nil then
		local chairs = self.buttonstation.chairinfo
		for i=1,#chairs do
			if chairs[i].chair ~= nil and chairs[i].userdiu ~= nil and chairs[i].userdiu == 0 then
				nowgameCount = nowgameCount+1;
			end
		end
	end
	return nowgameCount;
end
--获取当前比牌的对象
function GameBaseButton:getNowGameCompair()
	local nowgameCount = 0;
	if self.buttonstation ~= nil and self.buttonstation.chairinfo ~= nil then
		local chairs = self.buttonstation.chairinfo
		for i=1,#chairs do
			if chairs[i].chair ~= nil and chairs[i].userdiu ~= nil and chairs[i].userdiu == 0 then
				if chairs[i].chair  ~= self.parent:getSelfInfo().bDeskStation then
					return chairs[i].chair;
				end
			end
		end
	end
end
--看牌返回
function GameBaseButton:response_showUserCard(resp_json)
	--如果当前自己正在加注，要更新加注显示的数字
	if self.buttonstation ~= nil and self.buttonstation.isAdd ~= nil and self.buttonstation.isAdd == true then
		if self.Panel_addNumbg:isVisible()==true then
			self.buttonstation = resp_json;
			self:addShowCoinLayer()
		end
	end
	self.buttonstation = resp_json;
	self:updateShowButton();
end
--当局总结算
function GameBaseButton:response_showOver(resp_json)
	self.buttonstation=nil
	self:updateShowButton();
	self.rootNode:setVisible(false)
end
--断线重连
--[["resp_json:" = {
    "GameStation"       = 4
    "allCountZhu"       = 20
    "bPlaying"          = true
    "iCountXiaZhuLimit" = -1163005939
    "iCurRounds"        = 1
    "iCurXiaZhuStation" = 1
    "iDizhu"            = 10
    "iLeaverTime"       = -1
    "iMaxRounds"        = 4
    "iNtStation"        = 1
    "iTotalNoteLimit"   = 100
    "iTurnCount"        = -1163005939
    "iVersion"          = 2
    "iVersion2"         = 0
}]]
function GameBaseButton:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().gameUnStartStation or
		resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE  then
		self:setButtonVisible(false)
	elseif resp_json.GameStation == self.parent:getGameStationEnum().GS_XIAZHU  then
		--当前为下注状态
		self.buttonstation = resp_json.player
		self:setButtonVisible(true)
		self:updateShowButton();
		local currentAction = self.buttonstation.CurrentXiaZhustation
		if currentAction == self.parent:getSelfInfo().bDeskStation then
			performWithDelay(self.rootNode, function ()
				local Image_gen_selected = seekNodeByName(self.btn_gendaodi,"Image_gen_selected")
				if Image_gen_selected:isVisible() == true then
					local currentAction = self.buttonstation.CurrentXiaZhustation
					if currentAction == self.parent:getSelfInfo().bDeskStation then
						GameSceneModule:getInstance():request_player_Gen()
					end
				end
			end, 1)
		end
	elseif resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_NEXT  then
		self.buttonstation = nil
		self:setButtonVisible(false)
		self:updateShowButton();
	end
end

return GameBaseButton


--endregion
