--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameMusic = class("GameMusic")

function GameMusic:ctor(parent)
	Music:stopMusic()  
	self.parent = parent
    self.musicisOpen = false;
	self.voiceisOpen = false;
	self.language = "music/ch_pt"
	if UserData:getMusic() == 0 then
		self.musicisOpen = false
	else
		self.musicisOpen = true
	end
	if UserData:getSound() == 0 then
		self.voiceisOpen = false;
	else
		self.voiceisOpen = true;
	end
	local language = UserData:getSetSwitch(3)
		
	if language == 0  then
		self:setLanguage(true)
	else
		self:setLanguage(false)
	end
	self:playbg();
end
function GameMusic:setMusic(musicOpen)
	self.musicisOpen = musicOpen
	if self.musicisOpen == true then
		self:playbg();
	else
		AudioEngine.stopMusic(false)
	end
end
function GameMusic:setVoice(voiceOpen)
	self.voiceisOpen = voiceOpen
end
function GameMusic:getMusic()
	return self.musicisOpen
end
function GameMusic:getVoice()
	return self.voiceisOpen
end
function GameMusic:setLanguage(isPutong)
	if isPutong == true then
		self.language="music/ch_pt"
	else
		self.language="music/ch_yue"
	end
	print("self.language:"..self.language)
end
--播放音效，如果带有性别，搜索性别下音频，如果没有搜索外面的音频
function GameMusic:playNormalVoice(musicname,man)
	if self.voiceisOpen == false then
		return;
	end
	local path = string.format("music/%s.mp3",musicname)
	if man ~= nil then
		local persion = "man"
		if type(man)== "boolean" then
			if man == false then
				persion="woman"
			end
		else
			if tonumber(man) == 0 then
				persion="woman"
			end
		end
		path = string.format("music/%s/%s.mp3",persion,musicname)
	end
	print("path:"..path)
	AudioEngine.playEffect(path)
end

function GameMusic:playbg()
	if self.musicisOpen == false then
		return;
	end
	AudioEngine.stopMusic();
	local path="music/bg.mp3"
	AudioEngine.preloadMusic(path)
	AudioEngine.playMusic(path,true)
end
--火拼音效单独拿出来，播放火拼音效时，要停止背景音乐，获拼音效进行循环播放
function GameMusic:playFireAllMusic()
	if self.voiceisOpen == false then
		return;
	end
	AudioEngine.stopMusic();
	local path="music/huopinbgm.mp3"
	--AudioEngine.preloadMusic(path)
	AudioEngine.playEffect(path,true)
end
function GameMusic:stopFireAllMusic()
	
	AudioEngine.stopAllEffects()
	self:playbg()
end

return GameMusic


--endregion
