--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local GameRuleLayer = class("GameRuleLayer",function()
	return cc.CSLoader:createNode("game/ruleLayer.csb")
end)

function GameRuleLayer:ctor(parent)
	self.parent = parent
    local Panel_bg = seekNodeByName(self,"Panel_bg")
	Panel_bg:addClickEventListener(function ()
		self:removeFromParent();
	end)
end


return GameRuleLayer


--endregion
