--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GamePlayerCoinLayer = class("GamePlayerCoinLayer")

function GamePlayerCoinLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.Image_jinbi={}
	self:init()
	self.indexnum=0;
end

function GamePlayerCoinLayer:init()
	for i = 1,self.playerCount do
		local Image_jinbix = seekNodeByName(self.rootNode,"Image_jinbi"..i)
		--print("i:"..i)
		Image_jinbix:setVisible(false)
		table.insert(self.Image_jinbi,i,Image_jinbix)
	end
	self.Panel_tableCoin = {}
	for i = 1,self.playerCount do
		local Panel_tableCoinx = seekNodeByName(self.rootNode,"Panel_tableCoin"..i)
		table.insert(self.Panel_tableCoin,i,Panel_tableCoinx)
	end
	
end
function GamePlayerCoinLayer:getTableCoinPosition(userViewChair)
	local tablecoinWidth = self.Panel_tableCoin[1]:getContentSize().width;
	local tablecoinHeight = self.Panel_tableCoin[1]:getContentSize().height;
	local tablecoinPositionx = self.Panel_tableCoin[1]:getPositionX();
	local tablecoinPositiony = self.Panel_tableCoin[1]:getPositionY();
	if userViewChair ~= nil then
		tablecoinWidth = self.Panel_tableCoin[userViewChair]:getContentSize().width;
		tablecoinHeight = self.Panel_tableCoin[userViewChair]:getContentSize().height;
		tablecoinPositionx = self.Panel_tableCoin[userViewChair]:getPositionX();
		tablecoinPositiony = self.Panel_tableCoin[userViewChair]:getPositionY();
	end
	local positionx = math.random(tablecoinPositionx,tablecoinPositionx+tablecoinWidth)
	local positiony = math.random(tablecoinPositiony,tablecoinPositiony+tablecoinHeight)
	print(string.format("positionx:%d,positiony:%d",positionx,positiony))
	return positionx,positiony
end

--关闭所有显示
function GamePlayerCoinLayer:closeAll()
	for i = 1,self.playerCount do
		self.Image_jinbi[i]:setVisible(false)
	end
end
function GamePlayerCoinLayer:showUserCoin()
	self:closeAll()
	self:showUserSitdownCoin()

end
function GamePlayerCoinLayer:showUserSitdownCoin()
	local playerDeskMap = self.parent:getSitDownPlayerMap()
	for k,v in pairs(playerDeskMap) do
		self:showOneUser(v)
	end
end
function GamePlayerCoinLayer:showOneUser(userinfo)
	
	self:updateUserCoinByChair(userinfo.bDeskStation,userinfo.dwMoney)
	
end
--更新某一位置上，玩家的金币
function GamePlayerCoinLayer:updateUserCoinByChair(chair,coin)
	print("更新用户金币：chair:"..chair..",coin:"..coin)
	if chair == nil or coin == nil or chair=="" or coin=="" then
		return;
	end
	local userViewChair = self.parent:getHelper():DeskStation2View(chair)
	if userViewChair>0 and userViewChair<=self.playerCount then
		self.Image_jinbi[userViewChair]:setVisible(true)
		--更新用户的金币
		local Text_num = seekNodeByName(self.Image_jinbi[userViewChair],"Text_num")
		Text_num:setString(coin)
	end
end

--更新某一位置上，投放到桌子上的玩家金币,chair:座位号，coin：筹码数，diZhubg背景图索引[1-5]
function GamePlayerCoinLayer:updateTableCoinByChair(chair,coin,diZhubg)
	if chair == nil or coin == nil or chair=="" or coin=="" or coin == 0 then
		return;
	end
	local userViewChair = self.parent:getHelper():DeskStation2View(chair)
	if userViewChair>0 and userViewChair<=self.playerCount then
		--self.Image_jinbi[userViewChair]
		local path = "game/miniCoin.csb"
		local sprite1 = cc.CSLoader:createNode(path)--cc.Sprite:create("res/chouma/100.png")
		local bg = seekNodeByName(sprite1,"Image_bg")
		if diZhubg ~= nil and diZhubg>0 then
			bg:loadTexture(string.format("res/chouma/%d.png",diZhubg))
		end
		local coinnumItem = seekNodeByName(bg,"coinnum")
		coinnumItem:setString(coin)
		local pointx = self.Image_jinbi[userViewChair]:getPositionX();
		local pointy = self.Image_jinbi[userViewChair]:getPositionY();
		if userViewChair == 1 then
			pointy = pointy-100
		else
			pointy = pointy+100
		end
		sprite1:setPosition(pointx,pointy)
		local tabelPx,tablePy = self:getTableCoinPosition(userViewChair)
		local scale = cc.EaseExponentialOut:create(cc.MoveTo:create(1.0,cc.p(tabelPx,tablePy)))
		sprite1:runAction(scale)
		
		sprite1:setTag(1000+self.indexnum);
		self.indexnum=self.indexnum+1;
		self.rootNode:addChild(sprite1)
	end
end
--桌上筹码动画--收归一个人
function GamePlayerCoinLayer:actionTableCoin(chair)
	local userViewChair = self.parent:getHelper():DeskStation2View(chair)
	local itemPx = self.Image_jinbi[userViewChair]:getPositionX()
	local itemPy = self.Image_jinbi[userViewChair]:getPositionY()
	if userViewChair == 1 then
		itemPy = itemPy-100
	else
		itemPy = itemPy+100
	end
	local length = 1000+self.indexnum-1
	for i =1000,length do
		local item = self.rootNode:getChildByTag(i)
		if item ~= nil then
			local scale = cc.EaseExponentialOut:create(cc.MoveTo:create(1.2,cc.p(itemPx,itemPy)))
			local callfunc = cc.CallFunc:create(function()
				item:removeFromParent();
			end)
			local sequence = cc.Sequence:create(scale, callfunc)
			item:runAction(sequence)
		end
	end
end
--桌上筹码动画--收归多人
function GamePlayerCoinLayer:actionTableCoinToManey(chairs)
	if chairs == nil or #chairs<2 then return end
	local maneys = #chairs
	for i = 1,maneys do
		local userViewChair = self.parent:getHelper():DeskStation2View(chairs[i])
		local itemPx = self.Image_jinbi[userViewChair]:getPositionX()
		local itemPy = self.Image_jinbi[userViewChair]:getPositionY()
		local length = 1000+self.indexnum-1
		for j =1000,length do
			if j%maneys+1 == i then
				local item = self.rootNode:getChildByTag(j)
				if item ~= nil then
					local scale = cc.EaseExponentialOut:create(cc.MoveTo:create(1.0,cc.p(itemPx,itemPy)))
					local callfunc = cc.CallFunc:create(function()
						item:removeFromParent();
					end)
					local sequence = cc.Sequence:create(scale, callfunc)
					item:runAction(sequence)
				end
			end
		end
	end
	
end

--游戏开始
--[[{
    "NtStation"  = 1
    "iCurRounds" = 1
    "iDingZhu"   = 100
    "iDizhu"     = 10
    "iMaxXiaZhu" = -1163005939
    "iSkin"      = 10
    "playerData" = {
        1 = {
            "chair" = 0
            "point" = 1000
        }
        2 = {
            "chair" = 1
            "point" = 1000
        }
    }
}]]
function GamePlayerCoinLayer:game_start(resp_json)
	if resp_json ~= nil and resp_json.playerData ~= nil and #(resp_json.playerData)>0 then
		for i = 1,#(resp_json.playerData) do
			local chair = resp_json.playerData[i].chair;
			local coin = resp_json.playerData[i].point;
			self:updateUserCoinByChair(chair,coin)
		end
	end
end
--开始下注，更新所有玩家当前的筹码数
--[["<var>" = {
    "allCountZhu" = 20
    "chairinfo" = {
        1 = {
            "chair"      = 0
            "point"      = 990
            "tablePoint" = 10
        }
        2 = {
            "chair"      = 1
            "point"      = 990
            "tablePoint" = 10
        }
    }
    "isAdd"       = true
    "isBi"        = true
    "isGen"       = true
    "isLook"      = true
    "isQi"        = true
}]]
function GamePlayerCoinLayer:response_sendCard(resp_json)
	if resp_json ~= nil and resp_json.chairinfo ~= nil then
		for i = 1,#resp_json.chairinfo do
			local chair = resp_json.chairinfo[i].chair;
			local coin = resp_json.chairinfo[i].point;
			local tablecoin = resp_json.chairinfo[i].tablePoint;
			self:updateUserCoinByChair(chair,coin)
			--底注：背景图索引使用1
			self:updateTableCoinByChair(chair,tablecoin,1)
			self.parent.music:playNormalVoice("feijinbi")
		end
	end
end
--某一个玩家下注了
function GamePlayerCoinLayer:response_startXiazhu(resp_json)
	--更新坐下用户手上的金币数量
	if resp_json ~= nil and resp_json.chairinfo ~= nil then
		for i = 1,#resp_json.chairinfo do
			local chair = resp_json.chairinfo[i].chair;
			local coin = resp_json.chairinfo[i].point;
			--local tablecoin = resp_json.chairinfo[i].tablePoint;
			self:updateUserCoinByChair(chair,coin)
			--self:updateTableCoinByChair(chair,tablecoin)
		end
	end
end
--收到某一个玩家下注或者加注消息
function GamePlayerCoinLayer:response_userXiaZhu(resp_json)
	--更新当前下注用户放桌子上的筹码数
	if resp_json ~= nil and resp_json.nowlimit ~= nil and resp_json.CurrentXiaZhustation ~= nil and resp_json.CurrentXiaZhuNum then
		--执行一个下注动画
		self:updateTableCoinByChair(resp_json.CurrentXiaZhustation,resp_json.CurrentXiaZhuNum,resp_json.nowlimit)
		self.parent.music:playNormalVoice("feijinbi")
	end
end
--收到比牌消息后，需要刷新用户金币
function GamePlayerCoinLayer:response_compairCard(resp_json)
	if resp_json ~= nil and resp_json.points ~= nil and #resp_json.points>0 then
		local points = resp_json.points
		for i = 1,#points do
			if points[i] ~= nil then
				local chair = points[i].chair;
				local coin = points[i].point;
				--local tablecoin = resp_json.chairinfo[i].tablePoint;
				self:updateUserCoinByChair(chair,coin)
			end
		end
	end
end
--游戏结束
function GamePlayerCoinLayer:response_showOver(resp_json)
	--更新玩家身上的金币
	if resp_json ~= nil and resp_json.points ~= nil and #resp_json.points>0 then
		for i=1,#resp_json.points do
			local chair = resp_json.points[i].chair;
			local coin = resp_json.points[i].npoint;
			--local tablecoin = resp_json.chairinfo[i].tablePoint;
			self:updateUserCoinByChair(chair,coin)
		end
		--桌上的筹码动画
	end
	if resp_json ~= nil and resp_json.winPlayerlist ~= nil then
		performWithDelay(self.rootNode, function()
			local winList = resp_json.winPlayerlist
			if #winList == 1 then
				self:actionTableCoin(winList[1])
			elseif #winList > 1 then
				self:actionTableCoinToManey(winList)	
			end
		end, 1)
		
	end
	if resp_json ~= nil and resp_json.winPlayer ~= nil then
		self:actionTableCoin(resp_json.winPlayer)
	end
	
end
--断线重连
--[["player" = {
    1 = {
        card = *MAX NESTING*
        "chair"      = 0
        "point"      = 980
        "tablePoint" = 20
    }
    2 = {
        card = *MAX NESTING*
        "chair"      = 1
        "point"      = 970
        "tablePoint" = 30
    }
}]]
function GamePlayerCoinLayer:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().gameUnStartStation or
		resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE  then
		if resp_json ~= nil and resp_json.player and resp_json.player.chairinfo ~= nil then
			dump(resp_json.player.chairinfo,"resp_json.player.chairinfo:")
			for i = 1,#resp_json.player.chairinfo do
				local chair = resp_json.player.chairinfo[i].chair;
				local coin = resp_json.player.chairinfo[i].point;
				local tablecoin = resp_json.player.chairinfo[i].tablePoint;
				self:updateUserCoinByChair(chair,coin)
				--底注：背景图索引使用1
				self:updateTableCoinByChair(chair,tablecoin,1)
			end
		end
	elseif resp_json.GameStation == self.parent:getGameStationEnum().GS_XIAZHU  then
		if resp_json ~= nil and resp_json.player and resp_json.player.chairinfo ~= nil then
			dump(resp_json.player.chairinfo,"resp_json.player.chairinfo:")
			for i = 1,#resp_json.player.chairinfo do
				local chair = resp_json.player.chairinfo[i].chair;
				local coin = resp_json.player.chairinfo[i].point;
				local tablecoin = resp_json.player.chairinfo[i].tablePoint;
				self:updateUserCoinByChair(chair,coin)
				--底注：背景图索引使用1
				self:updateTableCoinByChair(chair,tablecoin,1)
			end
		end
	elseif resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_NEXT  then
		if resp_json ~= nil and resp_json.player and resp_json.player.chairinfo ~= nil then
			dump(resp_json.player.chairinfo,"resp_json.player.chairinfo:")
			for i = 1,#resp_json.player.chairinfo do
				local chair = resp_json.player.chairinfo[i].chair;
				local coin = resp_json.player.chairinfo[i].point;
				local tablecoin = resp_json.player.chairinfo[i].tablePoint;
				self:updateUserCoinByChair(chair,coin)
				if tablecoin>0 then
					--底注：背景图索引使用1
					self:updateTableCoinByChair(chair,tablecoin,1)
				end
			end
		end
	end
	
	
end

return GamePlayerCoinLayer
