--[[
游戏内房主申请加分信息显示界面
]]
local m_clientmain = import("....room.clientmain")
local m_download = import("....common.download")

local GameMaskAddNumCoinLayer = class("GameMaskAddNumCoinLayer",function()
	return cc.CSLoader:createNode("game/tipAddScore.csb")
end)

function GameMaskAddNumCoinLayer:ctor(parent,data)
    self.parent = parent
	
	local Image_close = seekNodeByName(self,"Image_close")
	Image_close:addClickEventListener(function()
		self:removeFromParent();
	end)
	local Text_tip = seekNodeByName(self,"Text_tip")
	Text_tip:setString(string.format("%s 玩家当前分数为%d",data.apply_user_nickName,data.apply_user_tablePoint))
	local TextField = seekNodeByName(self,"TextField_1")
    self.TextField = MyEditBox:TextFiled_to_EditBox(TextField)
    TextField:setMaxLength(30)
	--确定按钮
	local btn_ok = seekNodeByName(self,"btn_ok") 
	btn_ok:addClickEventListener(function()
		local number = tonumber( self.TextField:getText() )
		if  not number or number<=0 then
			Msg:showTips("输入的分数不正确哦！")
		   return nil
		end
		if number + data.apply_user_tablePoint > 100000 then
			api_show_tips("添加后的分数不能超过10万")
			return nil
		end
		self.add_point = number            
		m_clientmain:get_instance():get_game_manager():get_game_room_mgr():request_apply_addPoint_to_player_in_game( data , number )
		self:removeFromParent();
	end)
end


return GameMaskAddNumCoinLayer


--endregion
