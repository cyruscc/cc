--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameSetLayer = class("GameSetLayer",function()
	return cc.CSLoader:createNode("game/setLayer.csb")
end)

function GameSetLayer:ctor(parent)
	self.parent = parent
    local Panel_bg = seekNodeByName(self,"Panel_bg")
	Panel_bg:addClickEventListener(function()
		--self:removeFromParent()
	end)
	
	local btn_close = seekNodeByName(self,"btn_close")
	btn_close:addClickEventListener(function()
		self:removeFromParent()
	end)
	local btn_music = seekNodeByName(self,"btn_music")
	local btn_effect = seekNodeByName(self,"btn_effect")
	btn_music:addClickEventListener(function()
		if UserData:getMusic() == 0 then
			UserData:setMusic(1)
			self.parent.music:setMusic(true)
		else
			UserData:setMusic(0)
			self.parent.music:setMusic(false)
		end
		
		self:updateSetButtonState()
	end)
	btn_effect:addClickEventListener(function()
		if UserData:getSound() == 0 then
			UserData:setSound(1)
			self.parent.music:setVoice(true)
		else
			UserData:setSound(0)
			self.parent.music:setVoice(false)
		end
		self:updateSetButtonState()
	end)

	self:updateSetButtonState()
	
	self:updateBgType()
	self:updateCardBgType();
end
--背景进行更换
function GameSetLayer:updateBgType()
	local Image_bg = seekNodeByName(self,"Image_bg")
	local btn_setbgTypeLeft = seekNodeByName(Image_bg,"btn_setbgType0")
	local btn_setbgTypeRight = seekNodeByName(Image_bg,"btn_setbgType1")
	local Image_setbgstyle = seekNodeByName(Image_bg,"Image_setbgstyle")
	local function updateBgTypeButtonStyle()
		local bgColor = UserData:getBgColor();
		if bgColor == 1 then
			btn_setbgTypeLeft:loadTextures("res/set/btn_left_02.png","res/set/btn_left_02.png")
			btn_setbgTypeRight:loadTextures("res/set/btn_right_01.png","res/set/btn_right_01.png")
			Image_setbgstyle:loadTexture("res/set/sl_bg01.png")
		else
			btn_setbgTypeLeft:loadTextures("res/set/btn_left_01.png","res/set/btn_left_01.png")
			btn_setbgTypeRight:loadTextures("res/set/btn_right_02.png","res/set/btn_right_02.png")
			Image_setbgstyle:loadTexture("res/set/sl_bg02.png")
		end
	end
	updateBgTypeButtonStyle()
	btn_setbgTypeLeft:addClickEventListener(function()
		local bgColor = UserData:getBgColor();
		if bgColor == 1 then
			return;
		end
		UserData:setBgColor(1);
		updateBgTypeButtonStyle()
		self.parent:updateSceneBg()
	end)
	btn_setbgTypeRight:addClickEventListener(function()
		local bgColor = UserData:getBgColor();
		if bgColor == 2 then
			return;
		end
		UserData:setBgColor(2);
		updateBgTypeButtonStyle()
		self.parent:updateSceneBg()
	end)
end
--牌背进行更换
function GameSetLayer:updateCardBgType()
	local Image_bg = seekNodeByName(self,"Image_bg")
	local btn_setCardbgTypeLeft = seekNodeByName(Image_bg,"btn_setCardbgType0")
	local btn_setCardbgTypeRight = seekNodeByName(Image_bg,"btn_setCardbgType1")
	local Image_setCardbgstyle = seekNodeByName(Image_bg,"Image_setCardbgstyle")
	local function updateCardBgTypeButtonStyle()
		local cardBgColor = UserData:getCardColor();
		if cardBgColor == 1 then
			btn_setCardbgTypeLeft:loadTextures("res/set/btn_left_02.png","res/set/btn_left_02.png")
			btn_setCardbgTypeRight:loadTextures("res/set/btn_right_01.png","res/set/btn_right_01.png")
			Image_setCardbgstyle:loadTexture("res/set/cardback_001.png")
		else
			btn_setCardbgTypeLeft:loadTextures("res/set/btn_left_01.png","res/set/btn_left_01.png")
			btn_setCardbgTypeRight:loadTextures("res/set/btn_right_02.png","res/set/btn_right_02.png")
			Image_setCardbgstyle:loadTexture("res/set/cardback_002.png")
		end
		
	end
	updateCardBgTypeButtonStyle()
	btn_setCardbgTypeLeft:addClickEventListener(function()
		local cardBgColor = UserData:getCardColor();
		if cardBgColor == 1 then
			return;
		end
		UserData:setCardColor(1);
		updateCardBgTypeButtonStyle()
		self.parent:updateSceneCardBg()
	end)
	btn_setCardbgTypeRight:addClickEventListener(function()
		local cardBgColor = UserData:getCardColor();
		if cardBgColor == 2 then
			return;
		end
		UserData:setCardColor(2);
		updateCardBgTypeButtonStyle()
		self.parent:updateSceneCardBg()
	end)
end
function GameSetLayer:updateSetButtonState()
	local btn_music = seekNodeByName(self,"btn_music")
	local btn_effect = seekNodeByName(self,"btn_effect")
	if UserData:getMusic() == 0 then
		btn_music:loadTextures("res/set/btn_close.png","res/set/btn_close.png")
	else
		btn_music:loadTextures("res/set/btn_open.png","res/set/btn_open.png")
	end
	if UserData:getSound() == 0 then
		btn_effect:loadTextures("res/set/btn_close.png","res/set/btn_close.png")
	else
		btn_effect:loadTextures("res/set/btn_open.png","res/set/btn_open.png")
	end
end
function GameSetLayer:updateLaguage_ButtonState()
	local Image_laguage = seekNodeByName(self,"Image_laguage")
	local language = UserData:getSetSwitch(3)
	print("Image_laguage,,,,language:"..language)
	if language == 0 then
		Image_laguage:loadTexture("gameres/set/c05.png")
	else
		Image_laguage:loadTexture("gameres/set/c06.png")
	end
end


return GameSetLayer


--endregion
