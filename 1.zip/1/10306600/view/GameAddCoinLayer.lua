--[[
显示申请加分界面
]]

local GameAddCoinLayer = class("GameAddCoinLayer",function()
	return cc.CSLoader:createNode("game/askAddCoin.csb")
end)

function GameAddCoinLayer:ctor(parent,max_number)
    self.parent = parent
	self.max_number = max_number
	--关闭按钮
	local btn_close = seekNodeByName(self,"btn_close")
	btn_close:addClickEventListener(function()
		self:removeFromParent();
	end)
	self.LoadingBar_1 = seekNodeByName(self,"LoadingBar_1")
	self.Image_rollbtn = seekNodeByName(self.LoadingBar_1,"Image_rollbtn")
	
	self.Text_currentCoin = seekNodeByName(self.Image_rollbtn,"Text_currentCoin")
	local TextField = seekNodeByName(self,"TextField_1")
    self.TextField = MyEditBox:TextFiled_to_EditBox(TextField)
    TextField:setMaxLength(30)
	--发送按钮监听
	local btn_send = seekNodeByName(self,"btn_send")
	btn_send:addClickEventListener(function()
		local addpoint = tonumber(self.Text_currentCoin:getString())
		self.parent:reqApplyAddPointByMaster(addpoint, self.TextField:getText())
        self:removeFromParent()
	end)
	
	local width = self.LoadingBar_1:getSize().width;
	
	local touch_listener = cc.EventListenerTouchOneByOne:create()
    touch_listener:setSwallowTouches(true) 
    touch_listener:registerScriptHandler(handler(self, self.onTouchBegan), cc.Handler.EVENT_TOUCH_BEGAN)
    touch_listener:registerScriptHandler(handler(self, self.onTouchMoved), cc.Handler.EVENT_TOUCH_MOVED)        
    touch_listener:registerScriptHandler(handler(self, self.onTouchEnded), cc.Handler.EVENT_TOUCH_ENDED)  
    touch_listener:registerScriptHandler(handler(self, self.onTouchCancelled), cc.Handler.EVENT_TOUCH_CANCELLED)      
    local eventDispatcher = self:getEventDispatcher()      
    eventDispatcher:addEventListenerWithSceneGraphPriority(touch_listener, self)
	self.begin_p = nil 
	self.start_positionX = self.Image_rollbtn:getPositionX()
	self.end_positionX = self.LoadingBar_1:getSize().width
	self.percent = (self.start_positionX )/(self.end_positionX)
	self:updateViewbyPercent()
end
function GameAddCoinLayer:onTouchBegan(touch, event)
	local touchPoint = touch:getLocation()
	local p= self.Image_rollbtn:convertToNodeSpace(touch:getLocation())
	print("touchPoint:"..touchPoint.x..","..touchPoint.y)
	local  rect = cc.rect(0, 0, self.Image_rollbtn:getContentSize().width, self.Image_rollbtn:getContentSize().height)
	--startPointx = touchPoint.x
	if cc.rectContainsPoint(rect, p) then
		--print("1111111111111111111")
		self.start_positionX = self.Image_rollbtn:getPositionX()
        self.begin_p = self:convertToNodeSpace(touch:getLocation())
        return true
    end 
	return false
end

function GameAddCoinLayer:onTouchMoved(touch, event)
	if self.begin_p == nil then
		return;
	end
	local touchPoint = touch:getLocation()
	local end_p = self:convertToNodeSpace(touch:getLocation())
    local p = self.Image_rollbtn:convertToNodeSpace(touch:getLocation())
    local moveX = end_p.x-self.begin_p.x
	--print("moveX:"..moveX)
	local current_positionX = self.start_positionX+moveX
	if current_positionX <= 0 then
		current_positionX = 0
	elseif current_positionX >= self.end_positionX then
		current_positionX = self.end_positionX
	end
    
	self.Image_rollbtn:setPositionX(current_positionX)
	self.percent = (current_positionX)/(self.end_positionX)
    --print("percent:"..self.percent)
    self:updateViewbyPercent();
	--]]
end
function GameAddCoinLayer:updateViewbyPercent()
	self.Text_currentCoin:setString(tostring(self:floatToInt(self.percent*self.max_number)))
    if self.LoadingBar_1~=nil then
		self.LoadingBar_1:setPercent(self.percent*100)
    end
end

function GameAddCoinLayer:onTouchEnded(touch, event)
	self.begin_p = nil
end

function GameAddCoinLayer:onTouchCancelled(touch, event)
	self.begin_p = nil
end
function GameAddCoinLayer:floatToInt(x)
    if x <= 0 then
       return math.ceil(x)
    end
    if math.ceil(x) == x then
       x = math.ceil(x)
    else
       x = math.ceil(x) - 1
    end
    return x
end

return GameAddCoinLayer


--endregion
