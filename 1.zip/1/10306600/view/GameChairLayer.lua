--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameChairLayer = class("GameChairLayer")

function GameChairLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.Image_zuoyi={}
	self:init()
	
end

function GameChairLayer:init()
	--print("self.playerCount:"..self.playerCount)
	for i = 1,self.playerCount do
		local Image_zuoyix = seekNodeByName(self.rootNode,"Image_zuoyi_"..i)
		--print("i:"..i)
		Image_zuoyix:setVisible(false)
		table.insert(self.Image_zuoyi,i,Image_zuoyix)
	end
end
--关闭显示所有座椅
function GameChairLayer:closeAll()
	for i = 1,self.playerCount do
		self.Image_zuoyi[i]:setVisible(false)
	end
end
function GameChairLayer:updateUser()
	if self.parent:isAlreadySitdown() == false and self.parent:isQzProject() == true then
		--自己如果没有坐下，显示当前座椅，而且能够进行点击
		for i = 1,self.playerCount do
			self.Image_zuoyi[i]:setVisible(true)
			self.Image_zuoyi[i]:addClickEventListener(function()
				print("i:"..i)
				local deskInfo = self.parent:getDeskInfo()
				local limitSitNum = 1;
				if deskInfo ~= nil and deskInfo.config ~= nil and deskInfo.config.item7 ~= nil and deskInfo.config.item7.sitNum ~= nil then
					limitSitNum = deskInfo.config.item7.sitNum
				end
				dump(deskInfo,"deskinfo:")
				if self.parent:getSelfInfo().dwMoney < limitSitNum then
					self.parent:pointLease()
					return;
				end
				local chairsit = (i+3)%5
				self.parent:reqSitdownDesk(chairsit,false)
			end)
		end
		local playerDeskMap = self.parent:getSitDownPlayerMap()
		for k,v in pairs(playerDeskMap) do
			local user_chair = self.parent:getHelper():DeskStation2View(v.bDeskStation)
			self.Image_zuoyi[user_chair]:setVisible(false)
		end
	end
	if self.parent:isAlreadySitdown() == true then
		self:closeAll();
	end
end
function GameChairLayer:onGameStation(resp_json)
	if resp_json.GameStation ~= nil then
		
	end
	

end
return GameChairLayer


--endregion
