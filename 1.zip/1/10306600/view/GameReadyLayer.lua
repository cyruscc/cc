--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameReadyLayer = class("GameReadyLayer")

function GameReadyLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.ImageReady = {}
	self:init()
end

function GameReadyLayer:init()
	for i = 1,self.playerCount do
		local Image_ready = seekNodeByName(self.rootNode,"Image_ready"..i)
		Image_ready:setVisible(false)
		table.insert(self.ImageReady,i,Image_ready)
	end
end
function GameReadyLayer:closeAll()
	for i = 1,self.playerCount do
		self.ImageReady[i]:setVisible(false)
	end
end
--更新用户当前的准备状态值
function GameReadyLayer:updateUser()
	self:closeAll();
	
	local playerDeskMap = self.parent:getSitDownPlayerMap()
	for k,v in pairs(playerDeskMap) do
		self:showUserReady(v)
	end
end
function GameReadyLayer:showUserReady(userinfo)
	local user_chair = self.parent:getHelper():DeskStation2View(userinfo.bDeskStation)--userinfo.bDeskStation
	if user_chair >0 and user_chair<=self.playerCount then
		local isReady = self.parent:getUserIsReady(userinfo.dwUserID)
		print("---------------------user_chair:"..user_chair..",userinfo.dwUserID:"..userinfo.dwUserID)
		dump(isReady,"isReady:")
		self.ImageReady[user_chair]:setVisible(isReady)
	end
end
--断线重连
function GameReadyLayer:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().gameUnStartStation or
		resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE  then
		self:updateUser()
	else
		self:closeAll();
	end
end
--游戏开始
function GameReadyLayer:game_start(resp_json)
	self:closeAll()
	
end
return GameReadyLayer


--endregion
