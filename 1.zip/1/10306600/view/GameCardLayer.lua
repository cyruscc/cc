--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_download = import("....common.download")

local GameCardLayer = class("GameCardLayer")

function GameCardLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.playerCard={}
	self:init()
end
function GameCardLayer:init()
	for i = 1,self.playerCount do
		local Panel_cardx = seekNodeByName(self.rootNode,"Panel_card"..i)
		if Panel_cardx ~= nil then
			Panel_cardx:setVisible(false)
			table.insert(self.playerCard,i,Panel_cardx)
		end
	end
end
--隐藏所有玩家的牌
function GameCardLayer:closeAll()
	for i = 1,self.playerCount do
		self.playerCard[i]:setVisible(false)
	end
end

function GameCardLayer:updateCardBg()
	
end
function GameCardLayer:getCardPath()
	local path = "res/card/cardback_0.png"
	if UserData:getCardColor() == 2 then
		path = "res/card/cardback_01.png"
	end
	return path;
end

--更新某一位置上，玩家的金币
function GameCardLayer:updateUserCardByChair(chair,cardlist,cardType)
	if chair == nil or cardlist == nil or chair=="" or cardlist=="" then
		return;
	end
	local userViewChair = self.parent:getHelper():DeskStation2View(chair)
	if userViewChair>0 and userViewChair<=self.playerCount then
		self.playerCard[userViewChair]:setVisible(true)
		--更新用户牌型
		local Text_cardType = seekNodeByName(self.playerCard[userViewChair],"Text_cardType")
		if cardType ~= nil and cardType ~= "" and self:getCardTypeById(cardType) ~= nil then
			Text_cardType:setVisible(true)
			local typeString = self:getCardTypeById(cardType)
			print("typeString:"..typeString)
			if typeString ~= nil then
				Text_cardType:setString(typeString)
			end
		else
			Text_cardType:setVisible(false)
		end
		--更新用户牌
		if cardlist ~= nil and #cardlist>0 then
			self:openUserCard(userViewChair,cardlist)
		end
	end
end
--[[//扑克出牌类型
#define SH_THREE					7				//三条
#define SH_SAME_HUA_CONTINUE		6				//同花顺
#define SH_SAME_HUA					5				//同花
#define SH_CONTINUE					4				//顺子
#define SH_DOUBLE					3				//对子
#define SH_SPECIAL					1				//特殊235
#define SH_OTHER					2				//单牌
#define UG_ERROR_KIND				0				//错误]]
local Card_Type = {}
Card_Type.SH_THREE = 7
Card_Type.SH_SAME_HUA_CONTINUE = 6
Card_Type.SH_SAME_HUA = 5
Card_Type.SH_CONTINUE = 4
Card_Type.SH_DOUBLE = 3
Card_Type.SH_SPECIAL = 1
Card_Type.SH_OTHER = 2

local Card_Typestr = {}
Card_Typestr.SH_THREE = "三条"
Card_Typestr.SH_SAME_HUA_CONTINUE = "同花顺"
Card_Typestr.SH_SAME_HUA = "同花"
Card_Typestr.SH_CONTINUE = "顺子"
Card_Typestr.SH_DOUBLE = "对子"
Card_Typestr.SH_SPECIAL = "特殊牌型"
Card_Typestr.SH_OTHER = "单牌"

function GameCardLayer:getCardTypeById(cardTypeid)
	print(type(cardTypeid))
	if cardTypeid ~= nil and cardTypeid ~= "" and type(cardTypeid)== "number" then
		print("cardTypeid:"..cardTypeid)
		if cardTypeid == Card_Type.SH_THREE then
			return Card_Typestr.SH_THREE
		elseif cardTypeid == Card_Type.SH_SAME_HUA_CONTINUE then
			return Card_Typestr.SH_SAME_HUA_CONTINUE
		elseif cardTypeid == Card_Type.SH_SAME_HUA then
			return Card_Typestr.SH_SAME_HUA
		elseif cardTypeid == Card_Type.SH_CONTINUE then
			return Card_Typestr.SH_CONTINUE 
		elseif cardTypeid == Card_Type.SH_DOUBLE then
			return Card_Typestr.SH_DOUBLE
		elseif cardTypeid == Card_Type.SH_SPECIAL then
			return Card_Typestr.SH_SPECIAL
		elseif cardTypeid == Card_Type.SH_OTHER then
			return Card_Typestr.SH_OTHER
		end
	end
end
--[["<var>" = {
    "CurrentXiaZhustation" = 1
    "allCountZhu"          = 20
    "chairinfo" = {
        1 = {
            card = *MAX NESTING*
            "chair"      = 0
            "point"      = 990
            "tablePoint" = 10
        }
        2 = {
            card = *MAX NESTING*
            "chair"      = 1
            "point"      = 990
            "tablePoint" = 10
        }
    }
    "isAdd"                = true
    "isBi"                 = true
    "isGen"                = true
    "isLook"               = true
    "isQi"                 = true
}]]
function GameCardLayer:response_sendCard(resp_json)
	print("--------GameCardLayer-------response_sendCard")
	if resp_json ~= nil and resp_json.chairinfo ~= nil and  #(resp_json.chairinfo)>0 then
		print("开始发牌")
		for i = 1,#resp_json.chairinfo do
			--self:updateUserCardByChair(resp_json.chairinfo[i].chair,resp_json.chairinfo[i].card)
			self:updateUserCardByChairAnimal(i,resp_json.chairinfo[i].chair,resp_json.chairinfo[i].card,true)
		end
	end
end
--发牌动画
function GameCardLayer:updateUserCardByChairAnimal(index,chair,cardlist,animal)
	if chair == nil or cardlist == nil or chair=="" or cardlist=="" then
		return;
	end
	local userViewChair = self.parent:getHelper():DeskStation2View(chair)
	if userViewChair>0 and userViewChair<=self.playerCount then
		self.playerCard[userViewChair]:setVisible(true)
		local Text_cardType = seekNodeByName(self.playerCard[userViewChair],"Text_cardType")
		Text_cardType:setVisible(false)
		if animal ~= nil and animal == true then
			if cardlist ~= nil and #cardlist>0 then
				for i= 1,#cardlist do
					local imagecard = seekNodeByName(self.playerCard[userViewChair],"Image_index"..i)
					imagecard:setVisible(false)
					imagecard:loadTexture(self:getCardPath())
					performWithDelay(imagecard, function()
						local sprite1 = cc.Sprite:create(self:getCardPath())
						sprite1:setPosition(cc.p(640,320))
						local move1 = cc.MoveTo:create(0.2,cc.p(self:getCardPosition(self.playerCard[userViewChair],i)))
						local callfunc1 = cc.CallFunc:create(function()
							imagecard:setVisible(true)
							sprite1:removeFromParent()
						end)
						local sequence = cc.Sequence:create(move1,callfunc1)
						
						sprite1:runAction(sequence)
						self.parent:addChild(sprite1)
					end,0.2*i+index*0.07)
				end
			end
		end
	end
end
--开牌动画
function GameCardLayer:openUserCard(userViewChair,cardlist)
	--[[local imagecard1 = seekNodeByName(self.playerCard[userViewChair],"Image_index"..1)
	local imagecard2 = seekNodeByName(self.playerCard[userViewChair],"Image_index"..2)
	local imagecard3 = seekNodeByName(self.playerCard[userViewChair],"Image_index"..3)
	imagecard1:setVisible(false)
	imagecard2:setVisible(false)
	imagecard3:setVisible(false)
	--]]
	for i = 1,3 do
		local imagecardx = seekNodeByName(self.playerCard[userViewChair],"Image_index"..i)
		if cardlist[i] > 0 then
			local cardhua = math.floor(cardlist[i]/16)
			local cardnum = cardlist[i]%16+1
			if cardnum == 14 then
				cardnum=1
			end
			imagecardx:setVisible(false)
			imagecardx:loadTexture(string.format("res/card/card_%d_%d.png",(cardhua+1),cardnum))
		else
			imagecardx:loadTexture(self:getCardPath())
			imagecardx:setVisible(true)
		end
	end
	--如果没有牌点，不执行下面的动画
	if cardlist[1] <= 0 then
		return;
	end
	local path = "action/fanpai_BIG.csb"
	local openCardNode = cc.CSLoader:createNode(path)
	local openCardAction = cc.CSLoader:createTimeline(path)
	openCardAction:setTimeSpeed(36/60)
	if userViewChair ~= 1 then
		openCardNode:setScale(0.6)
	end
	for i = 1,3 do
		local Image_cardx = seekNodeByName(openCardNode,"Image_card"..i)
		local cardhua = math.floor(cardlist[i]/16)
		local cardnum = cardlist[i]%16+1
		if cardnum == 14 then
			cardnum=1
		end
		Image_cardx:loadTexture(string.format("res/card/card_%d_%d.png",(cardhua+1),cardnum))
	end
	--更新当前动画的牌背
	for i = 1,3 do
		local Image_paibeix = seekNodeByName(openCardNode,"Image_paibei"..i)
		--if Image_paibeix ~= nil then
			Image_paibeix:loadTexture(self:getCardPath())
		--end
	end
	
	local ImageCard2 = seekNodeByName(self.playerCard[userViewChair],"Image_index"..2)
	openCardNode:runAction(openCardAction)
	openCardAction:gotoFrameAndPlay(0,false)
	openCardNode:setPosition(ImageCard2:getPositionX(),ImageCard2:getPositionY())
	self.playerCard[userViewChair]:addChild(openCardNode)
	openCardAction:setLastFrameCallFunc(function()
		openCardNode:removeFromParent();
		for i = 1,3 do
			local imagecardx = seekNodeByName(self.playerCard[userViewChair],"Image_index"..i)
			imagecardx:setVisible(true)
		end
	end)
end
function GameCardLayer:getCardPosition(panel,index)
	local panelx = panel:getPositionX()
	local panely = panel:getPositionY()
	local indexItem = seekNodeByName(panel,"Image_index"..index)
	local indexItemx = indexItem:getPositionX()
	local indexItemy = indexItem:getPositionY()
	return panelx+indexItemx,panely+indexItemy;
end
--玩家看牌返回
function GameCardLayer:response_showUserCard(resp_json)
	if resp_json ~= nil and resp_json.chair ~= nil and resp_json.card ~= nil then
		self:updateUserCardByChair(resp_json.chair,resp_json.card,resp_json.cardType)
	end
end
--收到某用户弃牌
function GameCardLayer:response_showQiCard(resp_json)
	if resp_json ~= nil and resp_json.chair ~= nil then
		local card = {};
		--如果比牌输，直接赋值三张空牌，直接显示牌背
		table.insert(card,0)
		table.insert(card,0)
		table.insert(card,0)
		self:updateUserCardByChair(resp_json.chair,card)
	end
end
--玩家比牌后牌状态
--[["<var>" = {
    "firstPlayer"  = 1
    "secondPlayer" = 0
    "winPlayer"    = 0
	"failPlayer"   = 1
}]]
function GameCardLayer:response_compairCard(resp_json)
	if resp_json ~= nil and resp_json.failPlayer ~= nil then
		local card = {};
		--如果比牌输，直接赋值三张空牌，直接显示牌背
		table.insert(card,0)
		table.insert(card,0)
		table.insert(card,0)
		self:updateUserCardByChair(resp_json.failPlayer,card)
	end
end
--结算结果服务端返回
--[["<var>" = {
    1 = {
        "card" = {
            1 = 6
            2 = 13
            3 = 52
        }
        "chair" = 0
    }
    2 = {
        "card" = {
            1 = 58
            2 = 61
            3 = 23
        }
        "chair" = 1
    }
}]]
function GameCardLayer:response_showOver(resp_json)
	if resp_json ~= nil and resp_json.cards ~= nil and #resp_json.cards>0 then
		for i =1,#resp_json.cards do
			self:updateUserCardByChair(resp_json.cards[i].chair,resp_json.cards[i].card,resp_json.cards[i].cardtype)
		end
	end
end
--重新开始下一局
function GameCardLayer:response_resetGame(resp_json)
	self:closeAll()
end
--[["player" = {
    1 = {
        card = *MAX NESTING*
        "chair"      = 0
        "point"      = 980
        "tablePoint" = 20
    }
    2 = {
        card = *MAX NESTING*
        "chair"      = 1
        "point"      = 970
        "tablePoint" = 30
    }
}]]
function GameCardLayer:updateUserCard()
	self:closeAll()
	local playerDeskMap = self.parent:getSitDownPlayerMap()
	for k,v in pairs(playerDeskMap) do
		self:showUserCard(v)
	end
end
function GameCardLayer:showUserCard(userinfo)
	local user_chair = self.parent:getHelper():DeskStation2View(userinfo.bDeskStation)--userinfo.bDeskStation
	if user_chair >0 and user_chair<=self.playerCount then
		local isReady = self.parent:getUserIsReady(userinfo.dwUserID)
		print("------------showUserCard---------user_chair:"..user_chair..",userinfo.dwUserID:"..userinfo.dwUserID)
		dump(isReady,"showUserCard----isReady:")
		self.playerCard[user_chair]:setVisible(isReady)
	end
end
--断线重连
function GameCardLayer:onGameStation(resp_json)
	if resp_json.GameStation == self.parent:getGameStationEnum().gameUnStartStation or
		resp_json.GameStation == self.parent:getGameStationEnum().GS_WAIT_ARGEE  then
		self:closeAll()
	else
		self:closeAll();
		if resp_json ~= nil and resp_json.player ~= nil and resp_json.player.chairinfo ~= nil and #resp_json.player.chairinfo>0 then
			for i = 1,#resp_json.player.chairinfo do
				if resp_json.player.chairinfo[i].card ~= nil and resp_json.player.chairinfo[i].chair then
					self:updateUserCardByChair(resp_json.player.chairinfo[i].chair,resp_json.player.chairinfo[i].card)
				end
			end
		end
	end
end
return GameCardLayer


--endregion
