--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
--每个位置上的倒计时控制，中间时间倒计时，中间的倒计时不能喝各用户的倒计时同时使用，


local GameTimeLayer = class("GameTimeLayer")

function GameTimeLayer:ctor(parent,rootNode)
    self.parent = parent

    self.rootNode = rootNode;
	self.playerCount = self.parent:getHelper():getPlayerContainNum()
	self.Image_timeType = {}
	self:init()
	self.timeCenter = seekNodeByName(self.rootNode,"Image_time")
	self.timeCenter:setVisible(false)
	--记录当前定时器服务端座位号
	self.timeChair = -1;
end

function GameTimeLayer:init()
	for i = 1,self.playerCount do
		local Image_timeTypeX = seekNodeByName(self.rootNode,"Image_timeType"..i)
		Image_timeTypeX:setVisible(false)
		table.insert(self.Image_timeType,i,Image_timeTypeX)
	end
end
function GameTimeLayer:noteUser_ready(resp_json)
	if resp_json ~= nil and resp_json.time ~= nil then
		self:gameTipActon("点击准备开始游戏",resp_json.time);
	end
end
function GameTimeLayer:game_start(resp_json)
	self:stopTimer();
end
--当中途有人重新坐下的时候，更新当前定时器显示位置
function GameTimeLayer:updateUserTime()
	
end
--人员重新回来了
function GameTimeLayer:playerJoinDesk(user_info)	
	local user_chair = self.parent:getHelper():DeskStation2View(user_info.bDeskStation)
	if self.Image_timeType[user_chair]:isVisible() == true then
		local Image_lixian = seekNodeByName(self.Image_timeType[user_chair],"Image_lixian")
		local Image_chaoshi = seekNodeByName(self.Image_timeType[user_chair],"Image_chaoshi")
		Image_lixian:setVisible(false)
		Image_chaoshi:setVisible(true)
	end
end
--进行加时等待
function GameTimeLayer:response_outOfXiaZhuTime(resp_json)
	if resp_json ~= nil and resp_json.CurrentXiaZhustation ~= nil and resp_json.outTimeWaitting ~= nil then
		local user_chair = self.parent:getHelper():DeskStation2View(resp_json.CurrentXiaZhustation)
		self:setUserTime(user_chair,resp_json.outTimeWaitting,resp_json.timeType)
	end
end
--结束超时倒计时
function GameTimeLayer:response_outOfTimeOver(resp_json)
	if resp_json ~= nil and resp_json.CurrentXiaZhustation ~= nil then
		local user_chair = self.parent:getHelper():DeskStation2View(resp_json.CurrentXiaZhustation)
		self:setUserTime(user_chair,-1)
	end
end
--用户头像上的倒计时---timeType,当前的类型，1，超时倒计时，2离线倒计时
function GameTimeLayer:setUserTime(viewIndex,time,timeType,callback)
	self.Image_timeType[viewIndex]:setVisible(false)
	if not time or time<=0 or time>1000 then
		if time<=0 and call_function~=nil then
			call_function()
		end
		return
	end
	if self.schedule_handle~=nil then
		g_scheduler:unscheduleScriptEntry(self.schedule_handle)
	end
	self.Image_timeType[viewIndex]:setVisible(true)
	local timeNum = seekNodeByName(self.Image_timeType[viewIndex],"timeNum")
	if timeNum ~= nil then
		timeNum:setString(time)
	end
	local Image_lixian = seekNodeByName(self.Image_timeType[viewIndex],"Image_lixian")
	local Image_chaoshi = seekNodeByName(self.Image_timeType[viewIndex],"Image_chaoshi")
	Image_lixian:setVisible(false)
	Image_chaoshi:setVisible(false)
	if timeType ~= nil then
		if timeType == 1 then
			Image_chaoshi:setVisible(true)
		else
			Image_lixian:setVisible(true)
		end
	end
	self.time = time
	self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
		self.time = self.time-1
		if timeNum ~= nil and timeNum.setString ~= nil then
			timeNum:setString(self.time)
		end
		if self.time<=0 then
			self:stopTimer()
			if callback~=nil then
			   callback()
			end
		end
	end,
	1, 
	false)
end
--中心的倒计时,,,,,中心倒计时只在等待游戏开始的时候有等待时间
function GameTimeLayer:gameTipActon(tipmessage,time,callback,position)
	self.timeCenter:setVisible(false)
	if not time or time<=0 or time>600 then
		if time<=0 and call_function~=nil then
			call_function()
		end
		return
	end
	if self.schedule_handle~=nil then
		g_scheduler:unscheduleScriptEntry(self.schedule_handle)
	end
	local timeTip = seekNodeByName(self.timeCenter,"Text_tip")
	if tipmessage ~= nil then
		timeTip:setString(tipmessage)
	else
		timeTip:setVisible(false)
	end
	self.timeCenter:setVisible(true)
	local timeNum = seekNodeByName(self.timeCenter,"timeNum")
	if timeNum ~= nil then
		timeNum:setString(time)
	end
	self.time = time
	print("time:"..time)
	self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
		self.time = self.time-1
		print(self.time)
		local timeNum = seekNodeByName(self.timeCenter,"timeNum")
		timeNum:setString(self.time )
		if self.time<=0 then
			self:stopTimer()
			if callback~=nil then
			   callback()
			end
		end
	end,
	1, 
	false)
end
function GameTimeLayer:stopTimer()
    if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
        self.schedule_handle = nil
    end
    self.time = 0
	self.timeCenter:setVisible(false)
	for i = 1,self.playerCount do
		self.Image_timeType[i]:setVisible(false)
	end
end
function GameTimeLayer:onGameStation(resp_json)
	if resp_json ~= nil and resp_json.GameStation == self.parent:getGameStationEnum().GS_XIAZHU  then
		if resp_json.nowXiazhuType ~= nil and resp_json.nowXiazhuType>0 then
			print("resp_json.iLeaverTime:"..resp_json.iLeaverTime..",CurrentXiaZhustation:"..resp_json.CurrentXiaZhustation)
			local user_chair = self.parent:getHelper():DeskStation2View(resp_json.CurrentXiaZhustation)
			self:setUserTime(user_chair,resp_json.iLeaverTime,1)
		end
	end
end
return GameTimeLayer

