--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
--require("app/platform/game/80002800/handleGameMessage")

--local GameScene = import(".view.GameScene")
local GameSceneModule = class(".gameSceneModule")
local GameMessage_MainID = 180

local TouziGameStation={
	gameUnStartStation=0,--游戏未开始状态
	GS_WAIT_ARGEE = 1,---等待开始状态
	gameResultStation=19,
}

local Table_GameMessage_ASSID = 
{
    --消息接收和发送ID相同
	ASS_PLAYER_READY = 20,         --发送准备消息
	ASS_MSG_QI_RSP 	 = 55,              --玩家弃牌请求
	ASS_MSG_KAN_RSP  = 56,          --玩家发送看牌请求
	ASS_MSG_GEN_RSP	 = 67,			--玩家发送跟注请求
	ASS_BIPAI_MSG    = 68,			--玩家发送比牌请求
	ASS_MSG_PEIPAI   = 99,			--玩家项服务器发送配牌消息
	
	ASS_GET_GAEMERECORD = 81,		--获取当前游戏的战绩
	
	
	T_GAME_READY_TIMER_CANCEL = 47,--准备倒计时取消
    T_GAME_READY_TIMER = 48,		--准备倒计时
	
    T_PLAYER_READY = 49,			--玩家准备
	ASS_SHAIZI_JIAOZHAI = 90,         --玩家开始叫斋
	ASS_SHAIZI_JIAOZHAI_RSP = 91,        --玩家开始叫斋
	ASS_SHAIZI_JIAOFEN == 92,           --玩家开始叫分
	ASS_SHAIZI_ADDFEN=93,               --玩家叫分返回
	ASS_SHAIZI_QIANGPI=94,               --发送的抢劈命令
	ASS_SHAIZI_Kai=95,               --玩家叫开
	ASS_SHAIZI_Pi=96,               --玩家叫劈
	ASS_SHAIZI_Pi_Kai = 97,         --被劈的人叫的开或者反劈
	ASS_YAODONG_START = 56,        --通知服务器，玩家已经摇动完毕
	
    T_GAME_START = 51,--游戏开始
    T_GAME_BANKER_NOTIFY = 52,--通知玩家叫庄
    T_PLAYER_BANKER = 53,--玩家叫庄
    T_GAME_BANKER_END = 54,--叫庄结束
    --T_GAME_BANKER_RAND = 62,--随机庄
    T_GAME_BET_NOTIFY = 55,--通知玩家下注
    --T_PLAYER_BET = 56,--玩家下注
    T_GAME_CARD_SEND = 57,--发牌
    T_GAME_CARD_OPEN = 59,--开始开牌
    T_PLAYER_CARD_OPEN = 60,--玩家开牌
    T_GAME_END = 61,--结算
    T_GAME_RECORD = 62 , --游戏结束战绩
    T_GAME_REBIND = 2,--断线重连
    T_PLAYER_POINT_LEASE = 210
}
function GameSceneModule:getInstance()
    if not self.GameSceneModule then
       self.GameSceneModule = self.new()
    end
    return self.GameSceneModule
end

function GameSceneModule:onDestroy()
    --self.GameSceneModule = nil
end

function GameSceneModule:init(GameScene)
    self.GameScene = GameScene
    --handleGameMessage.setGameMessageHandler(self)
end

function GameSceneModule:getGameScene()
    return self.GameScene
end

--通知玩家准备，显示倒计时，进行准备
function GameSceneModule:resp_gameReady(resp_json)    
    --dump(resp_json,"resp_json")
	if self.GameScene ~= nil and self.GameScene.resp_gameReady ~= nil then
		self.GameScene:resp_gameReady(resp_json)
	end
end
    --玩家准备
function GameSceneModule:request_player_ready()    
    local request = {}
    request.chair  = self:getGameScene():getSelfInfo().bDeskStation
    self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_PLAYER_READY, request)

    print("玩家请求准备------------------------------------------------------------------------------%d", request.chair)

end
    --收到玩家准备
function GameSceneModule:resp_player_ready(resp_json)    
    self.GameScene:resp_player_ready(resp_json)
end
--向服务器发送丢牌消息
function GameSceneModule:request_player_Diu()
	local request = {}
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_MSG_QI_RSP, request)
end
--向服务器发送看牌消息
function GameSceneModule:request_player_Look()
	local request = {}
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_MSG_KAN_RSP, request)
end
--向服务器发送跟注消息
function GameSceneModule:request_player_Gen()
	local request = {}
	request.addindex = 0
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_MSG_GEN_RSP, request)
end
--向服务器发送加注消息---addnum:加注的索引[1-4]
function GameSceneModule:request_player_Add(addnum)
	local request = {}
	request.addindex = addnum
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_MSG_GEN_RSP, request)
end

--向服务器发送比牌消息
function GameSceneModule:request_player_compare(secondIndex)
	local request = {}
	request.selectIndex = secondIndex
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_BIPAI_MSG, request)
end
--向服务器发送配牌
function GameSceneModule:request_usercard(cardlist)
	local request = {}
	request.cardlist = cardlist
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_MSG_PEIPAI, request)
end
--获取当前游戏的战绩
function GameSceneModule:getGameRecord()
	local request = {}
	self:getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.ASS_GET_GAEMERECORD, request)
end


function GameSceneModule:noteUser_ready(resp_json)
	self.GameScene:noteUser_ready(resp_json)
end
--游戏开始
function GameSceneModule:resp_gameBegin(resp_json)

    print("------------------------------------------GameSceneModule:response_game_start recv game start")
   
    self.GameScene:game_start(resp_json)
end
--下发用户手中的牌
--[["<var>" = {
    1 = {
        "card" = {
            1 = 0
            2 = 0
            3 = 0
        }
        "chair" = 1
        "point" = 1000
    }
    2 = {
        "card" = {
            1 = 53
            2 = 44
            3 = 56
        }
        "chair" = 1
        "point" = 1000
    }
}]]
function GameSceneModule:response_sendCard(resp_json)
	print("--------GameSceneModule-------response_sendCard")
	self.GameScene:response_sendCard(resp_json)
end

--发牌	
function GameSceneModule:response_game_card_send(resp_json)
    local resp_table = {}
    for i=1, #resp_json do
        local user_json = resp_json[i]
        local resp_user_crad = {}
        for j=1, #user_json.cards do
           resp_user_crad[j] = user_json.cards[j]
        end
        resp_table[user_json.chair]=resp_user_crad
    end
    self.GameScene:game_card_send(resp_table)
end
--某一个玩家下了多少注，下一个玩家的操作按钮控制
function GameSceneModule:response_startXiazhu(resp_json)
	print("--------GameSceneModule-------response_startXiazhu")
	self.GameScene:response_startXiazhu(resp_json)
end
--开始下注
function GameSceneModule:response_userXiaZhu(resp_json)
	self.GameScene:response_userXiaZhu(resp_json)
end

--下注超时，进行加时等待
function GameSceneModule:response_outOfXiaZhuTime(resp_json)
	self.GameScene:response_outOfXiaZhuTime(resp_json)
end
--结束下注超时
function GameSceneModule:response_outOfTimeOver(resp_json)
	self.GameScene:response_outOfTimeOver(resp_json)
end
--看牌返回
function GameSceneModule:response_showUserCard(resp_json)
	self.GameScene:response_showUserCard(resp_json)
end
--通知所有用户，有人看牌了
function GameSceneModule:response_showLookCard(resp_json)
	self.GameScene:response_showLookCard(resp_json)
end
--通知用户，有人弃牌了
function GameSceneModule:response_showQiCard(resp_json)
	self.GameScene:response_showQiCard(resp_json)
end
--比牌结果返回
function GameSceneModule:response_compairCard(resp_json)
	self.GameScene:response_compairCard(resp_json)
end

function GameSceneModule:response_showOver(resp_json)
	
	self.GameScene:response_showOver(resp_json)
end
--开始新一局
function GameSceneModule:response_resetGame(resp_json)
	self.GameScene:response_resetGame(resp_json)
end


--游戏局数完成，显示战绩
function GameSceneModule:response_allGameResult(resp_json)
	self.GameScene:response_allGameResult(resp_json)
end
function GameSceneModule:response_gameRecord(resp_json)
	self.GameScene:response_gameRecord(resp_json)
end

--断线重连
function GameSceneModule:response_game_station(resp_json)
    --dump(resp_json)
	
	if resp_json.GameStation ~= nil then
		self.GameStation = resp_json.GameStation
	end

	--self.GameScene:game_rebind(resp_json)
    --各层断线重连
	self.GameScene:onGameStation(resp_json)
   
end

--获取当前游戏状态
function GameSceneModule:getGameStation()
    return self.GameStation
end
return GameSceneModule

--endregion
