

local DESK_COUNT = 5  --游戏桌子数量

local GameSceneModule = require("app/platform/game/10306600/gameSceneModule")
local m_gameHelperBase = import("app.platform.game.gameHelperBase")
local CGameHelper = class("CGameHelper" , m_gameHelperBase )
function CGameHelper:ctor( game_room )

    self.super:ctor( DESK_COUNT )
end

--获取当人场次可以容纳的人数
function CGameHelper:getPlayerContainNum()
	return DESK_COUNT
end
--@Override
-- 客户端发送游戏消息
function CGameHelper:sendGameMessage( AssistantID , request )
    self.super:sendGameMessage( AssistantID , request )
end

--@Override
--desc 自己进入游戏桌子成功的通知 用于切换场景
function CGameHelper:selfJoinDesk( hcode , room_info )
	
    
    local game_scene = GameApp:enterScene("game.10306600.view.GameScene")   -- 进入游戏
	print("selfJoinDesk-----------")
    game_scene:reqDeskRebind()
    self.super:init_game( game_scene )
	self.gameSceneModule = GameSceneModule:getInstance()
	self.gameSceneModule:init(game_scene)
	self:addGameListener()
	
end
local Table_GameMessage_ASSID = 
{
	ASS_PLAYER_READY = 20,       --玩家准备
	ASS_NOTE_READY = 22,		--通知玩家准备倒计时
	ASS_GAME_BEGIN   = 51,       --游戏开始
	ASS_SEND_CARD_MSG = 52,      --发送玩家手中的牌
	ASS_MSG_XIAZHU    = 53,      --开始下注按钮状态,
	
	ASS_MSG_GEN_RSPONSE = 73,	---某一家下注或者跟注的返回
	ASS_MSG_USERCARD  = 54,      --显示一家用户的牌
	ASS_BIPAI_RESULT  = 69,		 --用户比牌结果
	ASS_MSG_LOOKCARDAll = 61,				--通知所有玩家有人看牌了
	ASS_MSG_QICARDAll	= 62,				--通知所有玩家有人弃牌了
	ASS_RESULT_RESULT	= 70,				--总结算结果
	ASS_RESETGAME_START = 71,				--开始新一局	
	ASS_RESULT_ALLRESULT = 72,				--达到局数的总结算
	ASS_MSG_OUTOFXIAZHUTIME = 82,			--下注超时，进行加时等待
	ASS_MSG_OUTTIMEOVER     = 83,			--结束下注超时倒计时
	
	ASS_GET_GAEMERECORD	= 81, 				--获取当前游戏的战绩

    ASS_GM_GAME_STATION = 2                     --断线重连

}
local Table_Action_Handler = {}
function CGameHelper:addGameListener()
	print("-----start addGameListener")
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_GM_GAME_STATION]=self.gameSceneModule.response_game_station
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_PLAYER_READY]=self.gameSceneModule.resp_player_ready
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_NOTE_READY]=self.gameSceneModule.noteUser_ready
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_GAME_BEGIN]=self.gameSceneModule.resp_gameBegin
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_SEND_CARD_MSG]=self.gameSceneModule.response_sendCard
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_MSG_XIAZHU]=self.gameSceneModule.response_startXiazhu
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_MSG_OUTOFXIAZHUTIME]=self.gameSceneModule.response_outOfXiaZhuTime
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_MSG_OUTTIMEOVER]=self.gameSceneModule.response_outOfTimeOver
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_MSG_GEN_RSPONSE]=self.gameSceneModule.response_userXiaZhu
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_MSG_USERCARD]=self.gameSceneModule.response_showUserCard
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_MSG_LOOKCARDAll]=self.gameSceneModule.response_showLookCard
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_MSG_QICARDAll]=self.gameSceneModule.response_showQiCard
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_RESULT_RESULT]=self.gameSceneModule.response_showOver
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_RESETGAME_START]=self.gameSceneModule.response_resetGame
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_RESULT_ALLRESULT]=self.gameSceneModule.response_allGameResult
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_BIPAI_RESULT]=self.gameSceneModule.response_compairCard
	
	Table_Action_Handler[Table_GameMessage_ASSID.ASS_GET_GAEMERECORD]=self.gameSceneModule.response_gameRecord
end
--@Override
--desc 具体游戏消息（180）的游戏接口
function CGameHelper:handleGameMessage( AssistantID , message )
    print("CGameHelper:handleGameMessage" , AssistantID , message )
    dump(message)
	if Table_Action_Handler[AssistantID]~=nil then
		Table_Action_Handler[AssistantID](self.gameSceneModule, message)
	else
		print("---gamehelper-Table_Action_Handler["..AssistantID.."]---nil")
	end
end
-- 获取服务端位置---重写父类函数
function CGameHelper:ViewStation2DeskStation(viewStation)
	print("self.desk_count:"..self.desk_count)
	local deskStation = (viewStation-6+self.game_scene:getSelfInfo().bDeskStation + self.desk_count)%self.desk_count
	return deskStation
end

return CGameHelper