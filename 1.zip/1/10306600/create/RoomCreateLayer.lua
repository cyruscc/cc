﻿--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_clientmain = import("....room.clientmain")
local m_def = import("....room.module.basicnotifydef")
--local IllegalString = import("....room.common.IllegalString")
--local HelpLayer = import("..help.HelpLayer")

local RoomCreateLayer = class("RoomCreateLayer", function()
	cc.FileUtils:getInstance():addSearchPath(cc.FileUtils:getInstance():getWritablePath().."upd/res/game_res/10306600/",true)
	cc.FileUtils:getInstance():addSearchPath(cc.FileUtils:getInstance():getWritablePath().."res/game_res/10306600/",true)
	cc.FileUtils:getInstance():addSearchPath("upd/res/game_res/10306600/",true)
	cc.FileUtils:getInstance():addSearchPath("res/game_res/10306600/",true)
    return cc.CSLoader:createNode("createNew/RoomCreateLayer.csb")
end)


local m_desk_config_select = nil
local game_desk_config = nil

local function setGameDeskConfig()
    UserData:setGameDeskConfig( g_config.game_id_list[1] , m_desk_config_select )
end

function RoomCreateLayer:ctor()  
    self:registerScriptHandler(handler(self,self.onNodeEvent))
	print("10306600------------------")
	self:init();
end

function RoomCreateLayer:init()
	--local serviceConfig = m_clientmain:get_instance():get_desk_mgr():get_desk_config(10306600)
	
	local ListView_1 = seekNodeByName(self,"ListView_1")
	self.Panel_item1 = seekNodeByName(ListView_1,"Panel_item1")
	self.Panel_item2 = seekNodeByName(ListView_1,"Panel_item2")
	self.Panel_item3 = seekNodeByName(ListView_1,"Panel_item3")
	self.Panel_item4 = seekNodeByName(ListView_1,"Panel_item4")
	self.Panel_item5 = seekNodeByName(ListView_1,"Panel_item5")
	self.Panel_item6 = seekNodeByName(ListView_1,"Panel_item6")
	self.Panel_item7 = seekNodeByName(ListView_1,"Panel_item7")
	--开始每条目进行监听
	self:initItem1()
	self:initItem2()
	self:initItem3()
	self:initItem4()
	self:initItem5()
	self:initItem6()
	self:initItem7()
	--确定按钮监听
	local Image_bg = seekNodeByName(self,"Image_bg")
	local btn_create = Image_bg:getChildByName("btn_create")
	btn_create:addClickEventListener(function()
		local config = self:getItemConfig()
		dump(config,"config:")
		--gameID , init_point , roomName , roomDesc , config )
		m_clientmain:get_instance():get_desk_mgr():send_async_request_create_desk(10306600,self.startFen,self:getItem1().roomname,"",config)
	end)
end
-- "title"   = "Round"
function RoomCreateLayer:getServiceConfigByTitle(titlereq)
	local serviceConfig = m_clientmain:get_instance():get_desk_mgr():get_desk_config(10306600)
	if serviceConfig ~= nil and #serviceConfig > 0 then
		for i = 1,#serviceConfig do
			if serviceConfig[i].title == titlereq then
				return serviceConfig[i]
			end
		end
	end
end
function RoomCreateLayer:getItemConfig()
	local config = {}
	local serviceConfig = self:getServiceConfigByTitle("Round")
	config["item1"]=self:getItem1();
	--config["item2"]=self:getItem2();
	config["Round"] = serviceConfig.cell[self:getItem2()]
	config["item3"]=self:getItem3();
	config["item4"]=self:getItem4();
	config["item5"]=self:getItem5();
	config["item6"]=self:getItem6();
	config["item7"]=self:getItem7();
	return config;
end
--初始化item1
function RoomCreateLayer:initItem1()
	--条目1
	local Image_roomname = seekNodeByName(self.Panel_item1,"Image_roomname")
	local TextField_1 = seekNodeByName(Image_roomname,"TextField_1")
	self.TextField_roomName = MyEditBox:TextFiled_to_EditBox(TextField_1)
	self.TextField_roomName:setMaxLength( 25 )
	local Image_baozi = seekNodeByName(self.Panel_item1,"Image_baozi")
	local Image_baozi_selected = seekNodeByName(Image_baozi,"Image_baozi_selected")
	local Text_jiangli_label = seekNodeByName(self.Panel_item1,"Text_jiangli")
	local Image_baozi_givefen = seekNodeByName(self.Panel_item1,"Image_baozi_givefen")
	
	Image_baozi:addClickEventListener(function()
		Image_baozi_selected:setVisible(not Image_baozi_selected:isVisible())
		if Image_baozi_selected:isVisible() == true then
			Text_jiangli_label:setVisible(true)
			Image_baozi_givefen:setVisible(true)
		else
			Text_jiangli_label:setVisible(false)
			Image_baozi_givefen:setVisible(false)
		end
	end)
	
	local TextField_2 = seekNodeByName(Image_baozi_givefen,"TextField_2")
	self.TextField_baozi_jiangli = MyEditBox:TextFiled_to_EditBox(TextField_2)
	self.TextField_baozi_jiangli:setMaxLength( 10 )
end
--获取当前创建房间配置
function RoomCreateLayer:getItem1()
	local item1config = {}
	local roomname = self.TextField_roomName:getText();
	if roomname == nil or roomname == "" then
		roomname=self.TextField_roomName:getPlaceHolder()
	end
	item1config["roomname"]=roomname;
	local Image_baozi = seekNodeByName(self.Panel_item1,"Image_baozi")
	local Image_baozi_selected = seekNodeByName(Image_baozi,"Image_baozi_selected")
	item1config["isbaozi"]=Image_baozi_selected:isVisible();
	if Image_baozi_selected:isVisible() == true then
		local jianglinum = self.TextField_baozi_jiangli:getText()
		if jianglinum == nil or jianglinum == "" then
			jianglinum = self.TextField_baozi_jiangli:getPlaceHolder()
		end
		item1config["baozijiangli"]=tonumber(jianglinum)
	end
	return item1config
end

function RoomCreateLayer:initItem2()
	--条目2，局数选择
	local Image_jushubg = seekNodeByName(self.Panel_item2,"Image_jushubg")
	local Panel_jushu = {}
	local Image_selected = {}
	local Text_jushu = {}
	local Text_jushu_selected ={}
	local serviceConfig = self:getServiceConfigByTitle("Round")
	
	for i = 1,6 do
		local Text_jushux = Image_jushubg:getChildByName("Text_jushu"..i)
		
		table.insert(Text_jushu,i,Text_jushux)
		local Text_jushu_selectedx = Image_jushubg:getChildByName("Text_jushu_selected"..i)
		if serviceConfig.cell[i] ~= nil then
			Text_jushux:setString(serviceConfig.cell[i].Round)
			Text_jushu_selectedx:setString(serviceConfig.cell[i].Round)
		end
		table.insert(Text_jushu_selected,i,Text_jushu_selectedx)
		Text_jushu_selected[i]:setVisible(false)
		local Image_selectx = Image_jushubg:getChildByName("Image_select"..i)
		Image_selectx:setVisible(false)
		table.insert(Image_selected,i,Image_selectx)
		local Panel_jushux = Image_jushubg:getChildByName("Panel_jushu"..i)
		table.insert(Panel_jushu,i,Panel_jushux)
		Panel_jushux:addClickEventListener(function()
			for j = 1,6 do
				Image_selected[j]:setVisible(false)
				Text_jushu_selected[j]:setVisible(false);
				Text_jushu[j]:setVisible(true);
			end
			Image_selected[i]:setVisible(true)
			Text_jushu[i]:setVisible(false);
			Text_jushu_selected[i]:setVisible(true);
		end)
	end
	--默认第一个选中
	Image_selected[1]:setVisible(true)
	Text_jushu[1]:setVisible(false);
	Text_jushu_selected[1]:setVisible(true);
end
--获取条目2的fangjain配置
function RoomCreateLayer:getItem2()
	--local item2config = {}
	local Image_jushubg = seekNodeByName(self.Panel_item2,"Image_jushubg")
	for i = 1,6 do
		local Image_selectx = Image_jushubg:getChildByName("Image_select"..i)
		if Image_selectx:isVisible() == true then
			return i
		end
	end
	--return item2config;
end
function RoomCreateLayer:initItem3()
	--条目3，比牌
	local checkboxbi = {}
	for i = 1,2 do
		local checkbox_bix = seekNodeByName(self.Panel_item3,"checkbox_bi"..i)
		table.insert(checkboxbi,i,checkbox_bix)
		checkbox_bix:setSelected(i == 1)
		local function selectedEvent(sender,eventType)
			for j = 1,2 do
				checkboxbi[j]:setSelected(false)
			end
			checkboxbi[i]:setSelected(true)
         end
        checkbox_bix:addEventListenerCheckBox(selectedEvent)
	end
	local Image_bi = seekNodeByName(self.Panel_item3,"Image_bi")
	local Image_19 = seekNodeByName(Image_bi,"Image_19")
	Image_bi:addClickEventListener(function()
		Image_19:setVisible(not Image_19:isVisible())
	end)
end
--获取条目3的fangjain配置
function RoomCreateLayer:getItem3()
	local item3config = {}
	for i = 1,2 do
		local checkbox_bix = seekNodeByName(self.Panel_item3,"checkbox_bi"..i)
		if checkbox_bix:isSelected() == true then
			item3config["bipai"]=i;
			break;
		end
	end
	local Image_bi = seekNodeByName(self.Panel_item3,"Image_bi")
	local Image_19 = seekNodeByName(Image_bi,"Image_19")
	item3config["menpaibi"]=Image_19:isVisible()
	return item3config;
end
function RoomCreateLayer:initItem4()
	--条目4，看牌
	local checkboxkan={}
	for i = 1,3 do
		local checkbox_kanx = seekNodeByName(self.Panel_item4,"checkbox_kan"..i)
		table.insert(checkboxkan,i,checkbox_kanx)
		checkboxkan[i]:setSelected(i == 1)
		local function selectedEvent2(sender,eventType)
			for j = 1,3 do
				checkboxkan[j]:setSelected(false)
			end
			checkboxkan[i]:setSelected(true)
         end
        checkbox_kanx:addEventListenerCheckBox(selectedEvent2)
	end
end
--获取条目4
function RoomCreateLayer:getItem4()
	local item4config = {}
	for i = 1,3 do
		local checkbox_kanx = seekNodeByName(self.Panel_item4,"checkbox_kan"..i)
		if checkbox_kanx:isSelected() == true then
			item4config["kanpai"]=i;
			break;
		end
	end
	return item4config;
end
function RoomCreateLayer:initItem5()
	--条目5，
	local Image_gamedizhubg = seekNodeByName(self.Panel_item5,"Image_gamedizhubg")
	local Text_dizhu_num = seekNodeByName(Image_gamedizhubg,"Text_dizhu_num")
	local Image_dizhu_jian = seekNodeByName(Image_gamedizhubg,"Image_dizhu_jian")
	local Image_dizhu_jia = seekNodeByName(Image_gamedizhubg,"Image_dizhu_jia")
	self.dizhuShowNum = 1--tonumber(Text_dizhu_num:getString())
	Text_dizhu_num:setString(self.dizhuShowNum)
	Image_dizhu_jian:addClickEventListener(function()
		if self.dizhuShowNum>1 then
			self.dizhuShowNum=self.dizhuShowNum-1;
		end
		Text_dizhu_num:setString(self.dizhuShowNum)
		self.TextField_sitnum:setPlaceHolder(self.dizhuShowNum*self.item6nowDanZhu*3)
	end)
	Image_dizhu_jia:addClickEventListener(function()
		self.dizhuShowNum = self.dizhuShowNum+1
		Text_dizhu_num:setString(self.dizhuShowNum)
		self.TextField_sitnum:setPlaceHolder(self.dizhuShowNum*self.item6nowDanZhu*3)
	end)
	
	local Image_ganefenshubg = seekNodeByName(self.Panel_item5,"Image_ganefenshubg")
	local Text_fen_num = seekNodeByName(Image_ganefenshubg,"Text_fen_num")
	local Image_fen_jian = seekNodeByName(Image_ganefenshubg,"Image_fen_jian")
	local Image_fen_jia = seekNodeByName(Image_ganefenshubg,"Image_fen_jia")
	self.startFen = 10--tonumber(Text_fen_num:getString())
	Text_fen_num:setString(self.startFen)
	Image_fen_jian:addClickEventListener(function()
		if self.startFen>=10 then
			self.startFen=self.startFen-10;
		end
		Text_fen_num:setString(self.startFen)
	end)
	Image_fen_jia:addClickEventListener(function()
		self.startFen = self.startFen+10
		Text_fen_num:setString(self.startFen)
	end)
end
--获取条目5
function RoomCreateLayer:getItem5()
	local item5config = {}
	item5config["dizhunum"]=self.dizhuShowNum
	item5config["startFen"]=self.startFen
	return item5config;
end
function RoomCreateLayer:initItem6()
	--条目6，
	local Image_danzhutop = seekNodeByName(self.Panel_item6,"Image_danzhutop")
	local Image_danzhu_jian = seekNodeByName(Image_danzhutop,"Image_danzhu_jian")
	local Image_danzhu_jia = seekNodeByName(Image_danzhutop,"Image_danzhu_jia")
	local Text_danzhu_num = seekNodeByName(Image_danzhutop,"Text_danzhu_num")
	self.item6nowDanZhu = 5;
	Text_danzhu_num:setString(self.item6nowDanZhu.."倍")
	Image_danzhu_jian:addClickEventListener(function()
		if self.item6nowDanZhu>5 then
			self.item6nowDanZhu = self.item6nowDanZhu-5
		end
		Text_danzhu_num:setString(self.item6nowDanZhu.."倍")
		self.TextField_sitnum:setPlaceHolder(self.dizhuShowNum*self.item6nowDanZhu*3)
	end)
	Image_danzhu_jia:addClickEventListener(function()
		self.item6nowDanZhu = self.item6nowDanZhu+5
		Text_danzhu_num:setString(self.item6nowDanZhu.."倍")
		self.TextField_sitnum:setPlaceHolder(self.dizhuShowNum*self.item6nowDanZhu*3)
	end)
	local Image_lunNumtop = seekNodeByName(self.Panel_item6,"Image_lunNumtop")
	local Image_lun_jian = seekNodeByName(Image_lunNumtop,"Image_lun_jian")
	local Image_lun_jia = seekNodeByName(Image_lunNumtop,"Image_lun_jia")
	local Text_lun_num = seekNodeByName(Image_lunNumtop,"Text_lun_num")
	self.item6nowLunNum = 10;
	Text_lun_num:setString(self.item6nowLunNum)
	Image_lun_jian:addClickEventListener(function()
		if self.item6nowLunNum>1 then
			self.item6nowLunNum = self.item6nowLunNum-1
		end
		Text_lun_num:setString(self.item6nowLunNum)
	end)
	Image_lun_jia:addClickEventListener(function()
		self.item6nowLunNum = self.item6nowLunNum+1
		Text_lun_num:setString(self.item6nowLunNum)
	end)
end
--获取条目6
function RoomCreateLayer:getItem6()
	local item6config = {}
	item6config["danZhu"]=self.item6nowDanZhu
	item6config["lunLimit"]=self.item6nowLunNum
	return item6config;
end
function RoomCreateLayer:initItem7()
	--条目7
	local Image_sitnum = seekNodeByName(self.Panel_item7,"Image_sitnum")
	local TextField_sitnum = seekNodeByName(Image_sitnum,"TextField_sitnum")
	self.TextField_sitnum = MyEditBox:TextFiled_to_EditBox(TextField_sitnum)
	self.TextField_sitnum:setPlaceHolder(self.dizhuShowNum*self.item6nowDanZhu*3)
	self.TextField_sitnum:setMaxLength( 10 )
end
--获取条目7
function RoomCreateLayer:getItem7()
	local item7config = {}
	local sitnum = self.TextField_sitnum:getText()
	if sitnum == nil or sitnum == "" then
		sitnum = self.TextField_sitnum:getPlaceHolder()
	end
	item7config["sitNum"]=tonumber(sitnum)
	return item7config;
end

function RoomCreateLayer:request_desk_config()
    api_show_loading_ext( 10 )
    m_clientmain:get_instance():get_desk_mgr():request_desk_config( g_config.game_id_list[1] )
end

function RoomCreateLayer:updateRoomConfig( )
    if self.isUpdate then
        return nil
    end
    self.isUpdate = true
    
    local room_config = m_clientmain:get_instance():get_desk_mgr():get_desk_config( g_config.game_id_list[1] )
    for i = 1 , 2 do
        DESK_CONFIG[ROLE[i]].initGameRound = { }  -- 固定底注 可选择的局数
        DESK_CONFIG[ROLE[i]].RoundToCard   = { }  -- 固定底注 选择的局数对应需要消耗的房卡
    end

    for key , var in pairs( room_config ) do
        if var.title == 'Round' then
            for key1 , var1 in pairs(var.cell) do
                for i = 1 , 2 do
                    table.insert( DESK_CONFIG[ROLE[i]].initGameRound , var1.Round )
                    table.insert( DESK_CONFIG[ROLE[i]].RoundToCard , var1.RoomCard )
                end
            end
        end
    end

    local userinfo = m_clientmain:get_instance():get_user_mgr():get_user_info()
    m_desk_config_select = UserData:getGameDeskConfig( g_config.game_id_list[1] )

    if m_desk_config_select == nil then
        m_desk_config_select = {}
    end
    set_value( m_desk_config_select , "Role" , {} )
    set_value( m_desk_config_select , "selectRoleID" , m_dufault_role )
    
    local roomName = userinfo.NickName --api_get_sub_utf8_str( userinfo.NickName , MAX_ROOM_LEN)
    
    for i = 1 , #ROLE do        
        set_value( m_desk_config_select.Role , ROLE[i] , {} )
        local role = m_desk_config_select.Role[ ROLE[i] ]
        set_value( role , 'desk_name' , roomName )
        set_value( role , 'desk_desc' , "" )
        set_value( role , 'desk_init_point' ,  DESK_CONFIG[ ROLE[i] ].initPoints[1] )
        set_value( role , 'config' , {} )
        local config = role.config
        set_value( config , 'NoteType' , tonumber(tostring(ROLE[i])) )
        set_value( config , 'bankerType' , 1 )    -- 0.轮庄 1.随机庄
        set_value( config , 'maxRounds' , DESK_CONFIG[ ROLE[i] ].initGameRound[1])
        set_value( config , 'antes' , DESK_CONFIG[ ROLE[i] ].initBets[1])
        set_value( config , 'bullPointBet' , clone( DESK_CONFIG[ ROLE[1] ].bullBet ) )
        
    end

    self.Panel_plat_set = self.Image_bg:getChildByName("Panel_plat_set")
    local Panel_set = self.Panel_plat_set:getChildByName("Panel_set")
    ------------------------------------------------------------------------------------------------
	--房间名称
    local Image_room_name = Panel_set:getChildByName("Image_room_name")
    local TextField_roomName = Image_room_name:getChildByName("TextField_roomName")
	self.TextField_roomName = MyEditBox:TextFiled_to_EditBox(TextField_roomName)
	self.TextField_roomName:setMaxLength( MAX_ROOM_LEN )
	------------------------------------------------------------------------------------------------
    --房间局数
	local Image_game_play_count = Panel_set:getChildByName("Image_game_play_count")
		self.init_point_select_item = {}
		for i=1,6,1 do
            self.init_point_select_item[i] = {}
            self.init_point_select_item[i].Text_item = Image_game_play_count:getChildByName("Text_item_"..i-1)
			self.init_point_select_item[i].Button_item = Image_game_play_count:getChildByName("Button_item_"..i-1)
			self.init_point_select_item[i].Button_item:addClickEventListener( function( )
                Music:playEffect_click()
				self:setGamePlayCountItem( i )
                setGameDeskConfig()
			end)
		end
    ------------------------------------------------------------------------------------------------
	--底注
	local Image_game_bet = Panel_set:getChildByName("Image_game_bet")
		self.Text_game_bet = Image_game_bet:getChildByName("Text_game_bet")
    	self.Button_bet_add = Image_game_bet:getChildByName("Button_add")
		self.Button_bet_add:addClickEventListener( function()
            Music:playEffect_click()
			self:addGameBet_index(1)
		end)
		self.Button_bet_subtraction = Image_game_bet:getChildByName("Button_subtraction")
		self.Button_bet_subtraction:addClickEventListener( function()
            Music:playEffect_click()
			self:addGameBet_index(-1)
		end)
	------------------------------------------------------------------------------------------------
    --初始分数
	local Image_init_point = Panel_set:getChildByName("Image_init_point")
		self.Text_init_point = Image_init_point:getChildByName("Text_init_point")
		self.Button_point_add = Image_init_point:getChildByName("Button_add")
		self.Button_point_add:addClickEventListener( function()
            Music:playEffect_click()
			self:addInitPointIndex( 1 )
		end)
		self.Button_point_subtraction = Image_init_point:getChildByName("Button_subtraction")
		self.Button_point_subtraction:addClickEventListener( function()
            Music:playEffect_click()
			self:addInitPointIndex( -1 )
		end)
	
	------------------------------------------------------------------------------------------------
    -- 选庄方式
    self.Image_banker_type = Panel_set:getChildByName("Image_banker_type")
    self.Button_banker_type = {}
    for i = 0 , 1 do        
        self.Button_banker_type[i] = Panel_set:getChildByName("Button_banker_"..i)
        self.Button_banker_type[i]:addClickEventListener( function()
            Music:playEffect_click()
            self:select_banker_type(i)
            setGameDeskConfig()
        end)
    end
    
    ------------------------------------------------------------------------------------------------
	--需要的房卡
	self.Text_neet_room_count = self.Panel_plat_set:getChildByName("Text_neet_room_count")
    if g_config.has_shop == false then
        self.Text_neet_room_count:setVisible( false )
    end
	--现有的房卡
	self.Text_my_room_card_count = self.Panel_plat_set:getChildByName("Text_my_room_card_count")
    if g_config.has_shop == false then
        self.Text_my_room_card_count:setVisible( false )
    end
	

    ------------------------------------------------------------------------------------------------
    local Image_game_set = self.Panel_plat_set:getChildByName("Image_game_set")
    Panel_game_set_rect = Image_game_set:getChildByName("Panel_game_set_rect")
    self.Text_game_set = Panel_game_set_rect:getChildByName("Text_game_set")
    
 

    -- 修改游戏配置（牛点的倍率）
    self.Button_modif_game = Panel_set:getChildByName("Button_modif_game")
        self.Button_modif_game:addClickEventListener( function()
            self.Panel_plat_set:setVisible(false)
            self.Panel_game_set:setVisible(true)
        end)

    self.Panel_game_set = self.Image_bg:getChildByName("Panel_game_set")
    self.Panel_game_set:setVisible( false )
    
    ------------------------------------------------------------------------------------------------
    -- 创建房间的按钮
	local Button_create = self.Panel_plat_set:getChildByName("Button_create")
		Button_create:addClickEventListener(function()
        local goods_list = m_clientmain:get_instance():get_goods_mgr():get_goods_list(g_payType)
        local props_list = m_clientmain:get_instance():get_goods_mgr():get_props_list_by_roomCard()
            Music:playEffect_click()
            game_desk_config.desk_name                 = self.TextField_roomName:getText()
            if game_desk_config.desk_name=="" or IllegalString:stringIsLegal(desk_name)==false  then
                api_show_tips("您输入的房间名称不符合规范")
                return nil
            end
            game_desk_config.desk_desc                 = ""
            if IllegalString:stringIsLegal(game_desk_config.desk_desc)==false then
               api_show_tips("您输入的房间介绍不符合规范")
               return nil
            end
            local needRoomCard = tonumber(self.Text_neet_room_count:getString())
            if needRoomCard > userinfo.RoomCard then
                local less_room_card = needRoomCard - userinfo.RoomCard
                if props_list  then
                    for key , var in pairs(props_list) do
                        if var.PropCount >= less_room_card then
                            if var.Price <= userinfo.Treasure then
                                self:create_room_card_small( less_room_card )
                            else
                                self:create_diamond_small( var.Price - userinfo.Treasure)
                            end
                            return nil
                        end
                    end
                end
                self:create_room_card_small()
                return nil 
            end  
            api_show_loading_ext( 10 )

            setGameDeskConfig()

            --进行 base64 加密 ， 有些特殊的符号会导致 w解析 json 出错 如 L'andti
            game_desk_config.desk_name = ToBase64( game_desk_config.desk_name )
            m_clientmain:get_instance():get_desk_mgr():send_async_request_create_desk( g_config.game_id_list[1] , game_desk_config.desk_init_point , game_desk_config.desk_name , game_desk_config.desk_desc ,  game_desk_config.config )

		end)
	
    ------------------------------------------------------------------------------------------------
    -- 玩法选择
	local Image_select_role = self.Panel_plat_set:getChildByName("Image_select_role")
		self.Button_role = {}
		for key , var in pairs(ROLE) do
			local str = "Button_role_"..var
            print( str )
			self.Button_role[var] = Image_select_role:getChildByName( str )
			self.Button_role[var] :addClickEventListener(function()
                Music:playEffect_click()
				self:setSelectRole( var )
                setGameDeskConfig()
			end)
		end
	local Panel_no_open = Image_select_role:getChildByName('Panel_no_open')
	if Panel_no_open then
		for i = 1 , 100 do
			local Button_role = Panel_no_open:getChildByName('Button_role_'..i)
			if Button_role then
				Button_role:addClickEventListener(function()
					api_show_tips("游戏即将上线，敬请期待！")
				end)
			else
				break
			end
		end
	end

    local Panel_set = self.Panel_plat_set:getChildByName("Panel_set")

    self:setSelectRole( m_desk_config_select.selectRoleID )
        local Button_desc  = Image_select_role:getChildByName( "Button_desc" )
        Button_desc:addClickEventListener( function()
            local scene = CCDirector:getInstance():getRunningScene()
            scene:addChild ( HelpLayer:create(game_desk_config.config.bankerType+2) )
        end)

    self:updateSelfInfo()
end

function RoomCreateLayer:recvKeyBack()
    self:removeFromParent()
end

function RoomCreateLayer:onNodeEvent(event)
    if event == "enter" then
        --[[m_clientmain:get_instance():get_desk_mgr():get_event_mgr():BsAddNotifyEvent( m_def.NOTIFY_DESK_EVENT , handler( self , self.onDeskEvent ) , self)
        m_clientmain:get_instance():get_game_manager():get_game_room_mgr():get_event_mgr():BsAddNotifyEvent(  m_def.NOTIFY_DESK_EVENT , handler( self , self.onDeskEvent ) , self )
        local room_config = m_clientmain:get_instance():get_desk_mgr():get_desk_config( g_config.game_id_list[1] )
        if room_config == nil then
            self:request_desk_config()
        else
            self:updateRoomConfig()
        end
        if g_config.has_once_game then
            g_pushBombBox(self)
        end
		--]]
    elseif event == "exit" then
        m_clientmain:get_instance():get_desk_mgr():get_event_mgr():BsRemoveNotifyEvent( m_def.NOTIFY_DESK_EVENT , self )
        m_clientmain:get_instance():get_game_manager():get_game_room_mgr():get_event_mgr():BsRemoveNotifyEvent(  m_def.NOTIFY_DESK_EVENT , self )
        if g_config.has_once_game then
            g_popBombBox(self)
        end
    end
end

function RoomCreateLayer:select_banker_type( type )
    game_desk_config.config.bankerType = type
    self.Image_banker_type:setPosition(self.Button_banker_type[type]:getPosition())
    for i = 0 , #self.Button_banker_type do
        self.Button_banker_type[i]:setTouchEnabled( type ~= i )
    end
end

------------------------------------------------------------------------------------------------
-- 牛点倍率的设置 （无牛-牛牛-五小牛的倍率设置）层
function RoomCreateLayer:bull_point_bet_set_panel()
    local datas = ""
    local function g(index)
        return game_desk_config.config.bullPointBet[index+1-IN_1]
    end

    local text_game_set_items = {}

    -- 检查某一项的 加 按钮是否可点击
    local function check_add_button_is_click( index )
        if IN_1 <= index and index <= IN_2 then
            -- 最后一个按钮没有达到上限就可以点击
            -- 只要比上一个按钮的数值少 2 以上就可以点击
            if (index == IN_2 and g(index)<MAX_BET ) or ( index < IN_2 and g(index) < g(index+1) ) then
                text_game_set_items[index].Button_add:setTouchEnabled(true)
                text_game_set_items[index].Button_add:setBright(true)
            else
                text_game_set_items[index].Button_add:setTouchEnabled(false)
                text_game_set_items[index].Button_add:setBright(false)
            end
        end
    end

    -- 检查某一项的 减 按钮是否可点击
    local function check_sub_button_is_click( index )
        if IN_1 <= index and index <=IN_2 then
            if (index == IN_1 and g(index)>MIN_BET) or ( index > IN_1 and g(index) > g(index-1) ) then
                text_game_set_items[index].Button_subtraction:setTouchEnabled(true)
                text_game_set_items[index].Button_subtraction:setBright(true)
            else
                text_game_set_items[index].Button_subtraction:setTouchEnabled(false)
                text_game_set_items[index].Button_subtraction:setBright(false)
            end
        end       
    end

    local function set_item_value( index , value )
        if MIN_BET <= value and value <= MAX_BET then
            game_desk_config.config.bullPointBet[index+1] = value
            setGameDeskConfig()
            text_game_set_items[index].Text_data:setString( g(index) )
            check_sub_button_is_click( index )
            check_add_button_is_click( index )
        end
    end

    local function update_game_config_value()
        datas = ""
        for i=IN_1 , IN_2 do
            datas = datas..game_set_names[i+1].."x"..g(i)
            if i<IN_2 then
                datas = datas.." "
            end
        end
        self.Text_game_set:setString( datas )
    end

        -- 初始化牛点的倍率
    local function init_bull_point()
        for i=IN_1 ,IN_2 do
            set_item_value( i , g(i) )
        end
        update_game_config_value()
    end

    local Text_clone = self.Panel_game_set:getChildByName("Text_clone")

    for i=IN_1 ,IN_2 do
        text_game_set_items[i] = {}
        local Text_ = nil
        if Text_clone then
            Text_ =    Text_clone:clone()
            self.Panel_game_set:addChild( Text_ )
            Text_:setText( game_set_names[i+1] )
            local x = math.floor( math.mod( i , 3 ) ) *  ( 400 - 76 ) +  Text_clone:getPositionX() 
            local y = Text_clone:getPositionY() -( math.floor( i / 3 ) * 97.5 )
            Text_:setPositionX( x )
            Text_:setPositionY( y )
        else
            Text_ = self.Panel_game_set:getChildByName("Text_"..i)
        end
        text_game_set_items[i].Button_subtraction = Text_:getChildByName("Button_subtraction")
            text_game_set_items[i].Button_subtraction:addClickEventListener( function()
                Music:playEffect_click()
                set_item_value( i , g(i)-1 )
                update_game_config_value()
                check_sub_button_is_click( i + 1 )
                check_add_button_is_click( i - 1 )
            end)
        text_game_set_items[i].Button_add = Text_:getChildByName("Button_add")
            text_game_set_items[i].Button_add:addClickEventListener( function()
                Music:playEffect_click()
                set_item_value( i , g(i)+1 )
                update_game_config_value()
                check_sub_button_is_click( i + 1 )
                check_add_button_is_click( i - 1 )
            end)
        text_game_set_items[i].Text_data = Text_:getChildByName("Text_data")
    end
    if Text_clone then
        Text_clone:removeFromParent()
    end

    init_bull_point()

    -- 返回到修改平台配置的按钮
    local Button_modif_plat = self.Panel_game_set:getChildByName("Button_modif_plat")
        Button_modif_plat:addClickEventListener( function()
            self.Panel_plat_set:setVisible(true)
            self.Panel_game_set:setVisible(false)
        end)

    -- 重置的按钮
    local Button_reset = self.Panel_game_set:getChildByName("Button_reset")
        Button_reset:addClickEventListener( function()
            game_desk_config.config.bullPointBet =  clone( DESK_CONFIG[tostring(game_desk_config.config.NoteType)].bullBet )
            init_bull_point()
        end)

end

-- 玩法选择层 （ 固定底注 、 温州血拼 ）
function RoomCreateLayer:setSelectRole( role_id )
    m_desk_config_select.selectRoleID = role_id
    game_desk_config = m_desk_config_select.Role[ tostring(role_id) ]
    
    self.TextField_roomName:setText( api_get_sub_utf8_str( game_desk_config.desk_name , MAX_ROOM_LEN ))
     
    self.select_bets_index = 1          -- 选择的底注下标
    self.select_point_index = 1    -- 选择的初始分数的下标
    self.select_round_index = 1    -- 选择的初始分数的下标



    --@desc 检查 选择的倍数 所在的下标
    local function check_init_bets_index()
        for i = 1 , #DESK_CONFIG[ m_desk_config_select.selectRoleID ].initBets do           
            if DESK_CONFIG[ m_desk_config_select.selectRoleID ].initBets[i] ==  game_desk_config.config.antes then
                self.select_bets_index = i
                return
            end
        end
    end

    --@desc 检查 选择的初始分数 所在的下标
    local function check_init_point_index() 
         for i = 1 , #DESK_CONFIG[ m_desk_config_select.selectRoleID ].initPoints do           
            if DESK_CONFIG[ m_desk_config_select.selectRoleID ].initPoints[i] ==  game_desk_config.desk_init_point * game_desk_config.config.antes then
                self.select_point_index= i
                return
            end
        end
    end
    
    local function check_init_round_index()
        for i=1 , #DESK_CONFIG[ role_id ].initGameRound do
            self.init_point_select_item[i].Text_item:setString( DESK_CONFIG[ role_id ].initGameRound[i] )
        end
        
        for i = 1 , #DESK_CONFIG[ m_desk_config_select.selectRoleID ].initGameRound do           
            if DESK_CONFIG[ m_desk_config_select.selectRoleID ].initGameRound[i] ==  game_desk_config.config.maxRounds then
                self.select_round_index  = i
                return
            end
        end
    end

    check_init_point_index()
    check_init_bets_index()
    check_init_round_index()

    self:addGameBet_index(0)
    self:addInitPointIndex(0)
    self:setGamePlayCountItem( self.select_round_index )

	for key , var in pairs(ROLE) do
		local Button_roles = self.Button_role[ var ]
		local Image_font = Button_roles:getChildByName("Image_font")
        
        Button_roles:setTouchEnabled( var ~= role_id )
		Button_roles:setBright( var ~= role_id )
		if var == role_id then
			Image_font:loadTexture( "game_res/90010500/create/role_"..var.."_select.png")
		else
			Image_font:loadTexture( "game_res/90010500/create/role_"..var.."_normal.png")
		end	
	end

    if role_id == ROLE[2] then
        self.Button_modif_game:setVisible(false)
    else
        self.Button_modif_game:setVisible(true)
    end

    self:select_banker_type( game_desk_config.config.bankerType )
    self:updateInitPoint()
    self:bull_point_bet_set_panel()

end

function RoomCreateLayer:setGamePlayCountItem( index )
	for j=1,6,1 do
		if j == index then
			self.init_point_select_item[ j ].Button_item:setTouchEnabled(false)
			self.init_point_select_item[ j ].Button_item:setBright( false )
            self.init_point_select_item[ j ].Text_item:setFontSize( 24 )
            self.init_point_select_item[ j ].Text_item:setColor(cc.c3b(255,241,76))
		else
			self.init_point_select_item[ j ].Button_item:setTouchEnabled(true)
			self.init_point_select_item[ j ].Button_item:setBright( true )
            self.init_point_select_item[ j ].Text_item:setFontSize( 20 )
            self.init_point_select_item[ j ].Text_item:setColor(cc.c3b(198,187,231))
		end
	end
    game_desk_config.config.maxRounds = DESK_CONFIG[m_desk_config_select.selectRoleID].initGameRound[index]
    game_desk_config.config.Round = {}
    game_desk_config.config.Round.id = index
	self.Text_neet_room_count:setString( DESK_CONFIG[m_desk_config_select.selectRoleID].RoundToCard[index] )
end

function RoomCreateLayer:updateInitPoint()
    game_desk_config.desk_init_point = DESK_CONFIG[m_desk_config_select.selectRoleID].initPoints[self.select_point_index] * DESK_CONFIG[m_desk_config_select.selectRoleID].initBets[ self.select_bets_index ]
    self.Text_init_point:setString( game_desk_config.desk_init_point )
end

function RoomCreateLayer:addInitPointIndex( index )
	local curIndex = self.select_point_index + index
    if curIndex > 0 and curIndex<= #DESK_CONFIG[m_desk_config_select.selectRoleID].initPoints then
        self.select_point_index = curIndex
        self:updateInitPoint()
        self.Button_point_subtraction:setTouchEnabled( curIndex > 1 )
        self.Button_point_subtraction:setBright( curIndex > 1 )
        self.Button_point_add:setTouchEnabled( curIndex < #DESK_CONFIG[m_desk_config_select.selectRoleID].initPoints )
        self.Button_point_add:setBright( curIndex < #DESK_CONFIG[m_desk_config_select.selectRoleID].initPoints )
    end
end

function RoomCreateLayer:addGameBet_index( index )
	local curIndex = self.select_bets_index + index
    if curIndex > 0 and curIndex<= #DESK_CONFIG[m_desk_config_select.selectRoleID].initBets then
        self.select_bets_index = curIndex
        self.Text_game_bet:setString( DESK_CONFIG[m_desk_config_select.selectRoleID].initBets[ curIndex ] )
        game_desk_config.config.antes = DESK_CONFIG[m_desk_config_select.selectRoleID].initBets[ curIndex ]
        self:updateInitPoint()
        self.Button_bet_subtraction:setTouchEnabled( curIndex > 1 )
        self.Button_bet_subtraction:setBright( curIndex > 1 )
        self.Button_bet_add:setTouchEnabled( curIndex < #DESK_CONFIG[m_desk_config_select.selectRoleID].initBets )
        self.Button_bet_add:setBright( curIndex < #DESK_CONFIG[m_desk_config_select.selectRoleID].initBets )
    end
end

function RoomCreateLayer:create_diamond_small( less_diamond )
    -- 钻石不足
    print("最少需要买 " , less_diamond ,  "个钻石" )
    api_show_Msg_Tip( "房卡不足，是否前往充值", function ()
        local param_1 =  clone(m_def.NotifyParam)
        param_1.event_id = m_def.NOTIFY_EVENT_SCENE_COMMAND
        param_1.event_data.data = {}
        param_1.event_data.data.command = "open-shopLayer-0"
        m_clientmain:get_instance():get_user_mgr():get_event_mgr():BsNotifyEvent( m_def.NOTIFY_EVENT_SCENE , param_1)
    end )
end

function RoomCreateLayer:create_room_card_small( less_room_card )
    --房卡不足
    print("最少需要买 " , less_room_card ,  "张房卡" )
    if g_config.has_shop == false then
        api_show_Msg_Box("您的房卡不足！")
    else
        api_show_Msg_Tip( "房卡不足，是否前往充值", function ()
            local param_1 =  clone(m_def.NotifyParam)
            param_1.event_id = m_def.NOTIFY_EVENT_SCENE_COMMAND
            param_1.event_data.data = {}
            param_1.event_data.data.command = "open-shopLayer-1"
            m_clientmain:get_instance():get_user_mgr():get_event_mgr():BsNotifyEvent( m_def.NOTIFY_EVENT_SCENE , param_1)
        end )
    end
 
end

function RoomCreateLayer:create_vip_level_small()
    if g_config.has_shop == false then
        api_show_Msg_Box("您已经创建了房间，请勿重复创建！")
    else
        local user_info = m_clientmain:get_instance():get_user_mgr():get_user_info()
        local cur_max_vip_level , cur_max_vip_endTime = m_clientmain:get_instance():get_user_mgr():get_user_module():update_vip_info( user_info.VipInfo )
        local function to_vip_layer( level , tips)
            if g_config.has_shop == true then
                api_show_Msg_Tip( '您只能同时创建'..level..'个房间，升级会员创建更多点击确认前往商城' , function() 
                    local param_1 =  clone(m_def.NotifyParam)
                    param_1.event_id = m_def.NOTIFY_EVENT_SCENE_COMMAND
                    param_1.event_data.data = {}
                    param_1.event_data.data.command = "open-vipLayer"
                    m_clientmain:get_instance():get_user_mgr():get_event_mgr():BsNotifyEvent( m_def.NOTIFY_EVENT_SCENE , param_1)
                end)
            else
                api_show_Msg_Box( "您已经创建私人场，请勿重复创建" )
            end
        end
        if cur_max_vip_level == 3 then
            api_show_Msg_Box( "您同时创建的房间数量已达上限" , handler( self , self.recvKeyBack ) )
        elseif cur_max_vip_level == 2 then
            to_vip_layer( 3 )
        elseif cur_max_vip_level == 1 then
            to_vip_layer( 2 )
        elseif cur_max_vip_level == 0 then
            to_vip_layer( 1 )
        end
    end    
end

function RoomCreateLayer:onDeskEvent( event )
    api_hide_loading()
    if nil == event or nil == event.args then
        return
    end
    local param = event.args
    if param.event_id == m_def.NOTIFY_DESK_EVENT_CREATE then
        if 0 == param.event_data.ret then
            --创建私人场成功
            local desk_info = param.event_data.data
            self:updateSelfInfo()
        elseif 1 == param.event_data.ret then
            --房卡不足
            self:create_room_card_small()
        elseif 5 == param.event_data.ret then
            -- vip等级对应可创建的私人场已经达到上限
            self:create_vip_level_small()
        else
            api_show_Msg_Box( param.event_data.desc )
        end
    elseif param.event_id == m_def.NOTIFY_DESK_EVENT_ENTER then
        if 0 ~= param.event_data.ret then
            api_show_tips( param.event_data.desc )
        end
    elseif param.event_id == m_def.NOTIFY_DESK_EVENT_DESK_CONGIG then
        if 0 == param.event_data.ret then
            self:updateRoomConfig()
        else
            api_show_Msg_Tip( param.event_data.desc , handler(self , self.request_desk_config) , handler(self , self.recvKeyBack) )
        end
    end
end

function RoomCreateLayer:updateSelfInfo()
    local user_info = m_clientmain:get_instance():get_user_mgr():get_user_info()
    self.Text_my_room_card_count:setString( tostring( user_info.RoomCard ) )
end

return RoomCreateLayer


--endregion
