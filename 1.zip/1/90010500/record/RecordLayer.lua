--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local WinLoseRecordLayer = import(".WinLoseRecordLayer")
local m_clientmain = import("....room.clientmain")
local m_def = import("....room.module.basicnotifydef")
local m_download = import("....common.download")

local RecordLayer = class("RecordLayer", function()
    return cc.CSLoader:createNode( "game_res/90010500/record/RecordLayer.csb" )
end)

function RecordLayer:ctor(parent)

    self.parent = parent
    

    local Panel_root = self:getChildByName("Panel_root")

    self.Image_root = Panel_root:getChildByName("Image_root")
    api_action_showPageLayer( self.Image_root )

    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end)


    self.ListView = self.Image_root:getChildByName("ListView")
    local Panel_itm = self.Image_root:getChildByName("Panel_itm")
    self.ItmCln = Panel_itm:clone()
    self.ItmCln:retain()
    Panel_itm:removeFromParent()
    self.Text_no_record_tips = self.Image_root:getChildByName("Text_no_record_tips")
    self.Text_no_record_tips:setVisible(false)

    self:registerScriptHandler(handler(self,self.onNodeEvent))

    api_show_loading_ext( 10 )
    m_clientmain:get_instance():get_gameRecord_mgr():request_gameRecord( g_config.game_id_list[1] )
    m_clientmain:get_instance():get_gameRecord_mgr():get_event_mgr():BsAddNotifyEvent( m_def.NOTIFY_GAME_RECORD_EVENT , handler( self , self.onGameRecod) )
end

function RecordLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end

function RecordLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
    elseif event == "exit" then
        g_popBombBox(self)
        m_clientmain:get_instance():get_gameRecord_mgr():clear_record_cell_by_room_id()
    end
end

function RecordLayer:onGameRecod( event )
    api_hide_loading()
    if nil == event or nil == event.args then
        return
    end
    local param = event.args
    if param.event_id == m_def.NOTIFY_GAME_RECORD_EVENT_USER then
        if param.event_data.ret ~= 0 then
	        api_show_Msg_Tip(param.event_data.desc)
        else
            self:updateListView( param.event_data.data )
        end
    end
end

function RecordLayer:updateListView(data)
    self.ListView:removeAllItems()
    if nil == data  or #data == 0 then
        self.Text_no_record_tips:setVisible( true )
    else
        self.Text_no_record_tips:setVisible( false )
    end
    local table_data = clone(data)
    local ferTimeTable = nil
    for i=1,  #table_data do

        local Panel_itm = self.ItmCln:clone()
        Panel_itm:addClickEventListener(function()
            self.parent:addChild(WinLoseRecordLayer:create(self.parent , table_data[i] ))
        end)
        local Button_search = Panel_itm:getChildByName("Button_search")
        Button_search:addClickEventListener(function()
            self.parent:addChild(WinLoseRecordLayer:create(self.parent , table_data[i] ))
        end)

        local timeTable = os.date("*t" , table_data[i].CreateTime )

        local Text_date = Panel_itm:getChildByName("Text_date")
        local Text_month = Panel_itm:getChildByName("Text_month")

        if ferTimeTable and timeTable.day == ferTimeTable.day and timeTable.month == ferTimeTable.month then
           Text_date:removeFromParent()
           Text_month:removeFromParent()
        else
            Text_date:setString( tostring(timeTable.day).."日")
            Text_month:setString(tostring(timeTable.month).."月")
        end

        local Text_hm = Panel_itm:getChildByName("Text_hm")
        Text_hm:setString( string.format("%02d:%02d",timeTable.hour , timeTable.min) )

        ferTimeTable = timeTable

        local Text_desc = Panel_itm:getChildByName("Text_desc")
        Text_desc:setString("来自\""..api_get_ascll_sub_str_by_ui(table_data[i].MasterNickName , 14 ).."\"的房间")

        local Text_name = Panel_itm:getChildByName("Text_name")
        Text_name:setString( FromBase64New(table_data[i].RoomName) )

        local Text_player_num = Panel_itm:getChildByName("Text_player_num")
        Text_player_num:setString(tostring(table_data[i].playerCount))

        local Text_people = Panel_itm:getChildByName("Text_people")
        Text_people:setPositionX(Text_player_num:getPositionX()+Text_player_num:getContentSize().width)

        local Image_num_bg = Panel_itm:getChildByName("Image_num_bg")
        local Text_num = Image_num_bg:getChildByName("Text_num")
        --table_data[i].TotalProfit = 0
        if tonumber(table_data[i].TotalProfit) > 0 then
            Text_num:setString("+"..table_data[i].TotalProfit)
            Text_num:setTextColor(cc.c3b(254, 207, 79))
        else
            Text_num:setString(table_data[i].TotalProfit)
            Text_num:setTextColor(cc.c3b(107, 214, 185))
        end
        

        local Image_state = Panel_itm:getChildByName("Image_state")
        if table_data[i].Dismissed ~= 0 then
            Image_state:loadTexture("game_res/90010500/record/h_record_over.png")
        end

        local Image_head = Panel_itm:getChildByName("Image_head")
        m_download:get_instance():set_record_head_image_and_auto_update( Image_head ,  table_data[i].MasterHeadStr , table_data[i].MasterUserID )

        self.ListView:pushBackCustomItem(Panel_itm)
    end

end

return RecordLayer

--endregion