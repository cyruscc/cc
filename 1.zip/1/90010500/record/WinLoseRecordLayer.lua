--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local PlayerRecordLayer = import(".PlayerRecordLayer")
local m_clientmain = import("....room.clientmain")
local m_def = import("....room.module.basicnotifydef")
local m_download = import("....common.download")


local WinLoseRecordLayer = class("WinLoseRecordLayer", function()
    return cc.CSLoader:createNode( "game_res/90010500/record/WinLoseRecordLayer.csb" )
end)

--@desc 
function WinLoseRecordLayer:ctor( parent , RoomValue  , type )
    if type == 1 then

    else
        self.RoomValue = clone( RoomValue )
    end
	
    self.parent = parent

    local Panel_root = self:getChildByName("Panel_root")

    self.Image_root = Panel_root:getChildByName("Image_root")
    
    api_action_showPageLayer( self.Image_root )

    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end)


    self.Image_root:getChildByName("Button_share"):addClickEventListener(function()
        cc.utils:captureScreen(function(succeed, outputFile)
            if succeed then
               print("test-----------------"..tostring(outputFile))
               lua_to_plat:wx_share_image_session( outputFile , function(ars)
               end)
            end
        end, 
        "qznn_share.jpg")
    end)
    
    if self.RoomValue  then
        self:setRoomInfo( self.RoomValue )
    end

    self.Panel_self = self.Image_root:getChildByName("Panel_self")
    self.Panel_self:setVisible( false )
    self.ListView = self.Image_root:getChildByName("ListView")

    --self:updateListView({1, 2, 4, 5, 7})

    self:registerScriptHandler(handler(self,self.onNodeEvent))
    m_clientmain:get_instance():get_gameRecord_mgr():get_event_mgr():BsAddNotifyEvent( m_def.NOTIFY_GAME_RECORD_EVENT , handler( self , self.onGameRecod) )
    api_show_loading_ext( 10 )
    if self.RoomValue == nil then
        m_clientmain:get_instance():get_gameRecord_mgr():request_get_game_record_by_room( RoomValue.roomID ,  RoomValue )
    else        
        m_clientmain:get_instance():get_gameRecord_mgr():request_gameRecord_by_room_total( g_config.game_id_list[1] , RoomValue.RoomID )
    end
end

function WinLoseRecordLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end

function WinLoseRecordLayer:onNodeEvent(event)
    if event == "enter" then
        g_pushBombBox(self)
    elseif event == "exit" then
        g_popBombBox(self)
    end
end

function WinLoseRecordLayer:onGameRecod(event)
    api_hide_loading()
    if nil == event or nil == event.args then
        return
    end
    local param = event.args
    if param.event_id == m_def.NOTIFY_GAME_RECORD_EVENT_ROOM_TOTAL then
        if param.event_data.ret ~= 0 then
	        api_show_Msg_Box(param.event_data.desc)
        else
            if  param.event_data.request.RoomID == self.RoomValue.RoomID then
                self:updateListView( param.event_data.data )
            end
        end
    elseif param.event_id == m_def.NOTIFY_GAME_RECORD_EVENT_ROOM_INFO_AND_TOTAL then
        if param.event_data.ret ~= 0 then
	        api_show_Msg_Box( param.event_data.desc )
        else
            self.RoomValue = clone(  param.event_data.data.RoomInfo )
            self:updateListView( param.event_data.data.UserInfo )
            self:setRoomInfo( self.RoomValue )
        end
    end
end

function WinLoseRecordLayer:setRoomInfo(room_info)
    if room_info.MasterNickName ~= nil and room_info.MasterNickName ~= "" then
        local Text_master = self.Image_root:getChildByName("Text_master")
        Text_master:setString( api_get_ascll_sub_str_by_ui(room_info.MasterNickName , 14) )
    end
    if room_info.RoomName ~= nil and room_info.RoomName ~= "" then
        local Text_roomName = self.Image_root:getChildByName("Text_roomName")
        Text_roomName:setString( api_get_ascll_sub_str_by_ui( FromBase64New(room_info.RoomName) , 16 ))
    end
end

function WinLoseRecordLayer:lookRoomPlayerCell( value )

    local user_info = m_clientmain:get_instance():get_user_mgr():get_user_info()
    local cur_max_vip_level , cur_max_vip_endTime = m_clientmain:get_instance():get_user_mgr():get_user_module():update_vip_info( user_info.VipInfo )
        self.parent:addChild( PlayerRecordLayer:create(self.parent , self.RoomValue , value , self.itemList ))
end


function WinLoseRecordLayer:setItemData( Panel_bg , value   )
        Panel_bg:addClickEventListener(function()
            self:lookRoomPlayerCell( value )
        end)
        local Button_search = Panel_bg:getChildByName("Button_search")
        
        Button_search:addClickEventListener(function()
            self:lookRoomPlayerCell( value )
        end)
       
        local Text_take_num = Panel_bg:getChildByName("Text_take_num")
        Text_take_num:setString( value.totalIncome-value.TotalProfit )
        local Text_total_num = Panel_bg:getChildByName("Text_total_num")
        Text_total_num:setString( value.totalIncome )

        local Text_name = Panel_bg:getChildByName("Text_name")
        Text_name:setString( api_get_ascll_sub_str_by_ui(value.NickName , 14 ) )

        local Text_board_num = Panel_bg:getChildByName("Text_board_num")
        Text_board_num:setString(value.playCount)

--        local Text_board = Panel_bg:getChildByName("Text_board")
--        Text_board:setPositionX(Text_board_num:getPositionX()+Text_board_num:getContentSize().width)

--        local Image_num_bg = Panel_bg:getChildByName("Image_num_bg")
--        local Text_num = Image_num_bg:getChildByName("Text_num")
        local Text_num = Panel_bg:getChildByName("Text_num")
        if tonumber(value.TotalProfit) > 0 then
            Text_num:setString("+"..value.TotalProfit)
            Text_num:setTextColor(cc.c3b(254, 207, 79))
        else
            Text_num:setString(value.TotalProfit)
            Text_num:setTextColor(cc.c3b(107, 214, 185))
        end
        
--        local Image_id = Panel_bg:getChildByName("Image_id")
--        if Image_id then
--            local Text_id = Image_id:getChildByName("Text_id")
--            Text_id:setString("ID:"..tostring(value.PlayerUserID))
--        end

        local Image_head = Panel_bg:getChildByName("Image_head")
        m_download:get_instance():set_record_head_image_and_auto_update( Image_head , value.HeadStr , value.PlayerUserID)
end

function WinLoseRecordLayer:updateListView(table_data)
    self.itemList = clone( table_data )
    self.ListView:removeAllItems()
    local user_info = m_clientmain:get_instance():get_user_mgr():get_user_info()
    local selfIndex = -1
    for i=1,  #table_data do
        if tostring(table_data[i].PlayerUserID) == tostring(user_info.UserID) then
            selfIndex = i
        else
            local Panel_itm = self.Panel_self:clone()
            Panel_itm:setVisible( true )
            self:setItemData( Panel_itm , table_data[i] )
            self.ListView:pushBackCustomItem(Panel_itm)
        end
    end
    if selfIndex ~= -1 then
        self.Panel_self:setVisible( true )
        self:setItemData( self.Panel_self , table_data[selfIndex] )
    end
  
end

return WinLoseRecordLayer

--endregion
