--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_clientmain = import("....room.clientmain")
local m_def = import("....room.module.basicnotifydef")
local m_download = import("....common.download")


local ConfRecordLayer = class("ConfRecordLayer", function()
    return cc.CSLoader:createNode( "game_res/90010500/record/ConfRecordLayer.csb" )
end)

function ConfRecordLayer:ctor(parent , player_info , room_info , playerList, playerName)

    self.RoomInfo = room_info
    self.PlayerInfo = player_info
    self.parent = parent
    self.playerList = playerList
    self.playerName = playerName

    local Panel_root = self:getChildByName("Panel_root")

    self.Image_root = Panel_root:getChildByName("Image_root")
    api_action_showPageLayer( self.Image_root )

    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end)

    local Image_head = self.Image_root:getChildByName("Image_head")
    if playerList then
        for key , var in pairs(playerList) do
            if var.PlayerUserID == player_info.playerID then
                m_download:get_instance():set_record_head_image_and_auto_update( Image_head ,var.HeadStr , player_info.playerID )
                break
            end
        end
    end

    self.Text_desc = self.Image_root:getChildByName("Text_desc")

    self.ListView = self.Image_root:getChildByName("ListView")
    local Panel_itm = self.Image_root:getChildByName("Panel_itm")
    self.ItmCln = Panel_itm:clone()
    self.ItmCln:retain()
    Panel_itm:removeFromParent()

    self:registerScriptHandler(handler(self,self.onNodeEvent)) 

end

function ConfRecordLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end

function ConfRecordLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
        self:updateListView()
    elseif event == "exit" then
        g_popBombBox(self)
    end
end

function ConfRecordLayer:getRecordItemByPlayer( )
    local data = m_clientmain:get_instance():get_gameRecord_mgr():get_record_cell_by_room_id( self.RoomInfo.RoomID )
    local ret = {}
    for key , var  in ipairs(data) do
        if var.GameRoundID == self.PlayerInfo.GameRoundID then
            table.insert( ret , var )
        end
    end
    return ret
end

function ConfRecordLayer:getPlayerInfo( playerID )
    for key , var in pairs(self.playerList) do
        if var.PlayerUserID == playerID then
            return var
        end
    end   
    return nil
end

function ConfRecordLayer:updateListView()
    local table_data = self:getRecordItemByPlayer()
    self.Text_desc:setString("\""..api_get_ascll_sub_str_by_ui(self.playerName,14).."\"的第"..tostring(self.PlayerInfo.GameRoundID).."局游戏记录，参与玩家"..tostring(#table_data).."人")
    self.ListView:removeAllItems()
   
    for i=1,  #table_data do
        local Panel_itm = self.ItmCln:clone()
        local player_info = self:getPlayerInfo( table_data[i].playerID )
        local Text_name = Panel_itm:getChildByName("Text_name")
        Text_name:setString(api_get_ascll_sub_str_by_ui( player_info.NickName ,14))

        local Text_type = Panel_itm:getChildByName("Text_type")
        Text_type:setString( get_niu_point( table_data[i].Detail.cardType ))

        local Text_win_lose = Panel_itm:getChildByName("Text_win_lose")
         if tonumber(table_data[i].ChangedPoints) > 0 then
            Text_win_lose:setString("+"..table_data[i].ChangedPoints)
            Text_win_lose:setTextColor(cc.c3b(254, 207, 79))
        else
            Text_win_lose:setString(table_data[i].ChangedPoints)
            Text_win_lose:setTextColor(cc.c3b(107, 214, 185))
        end

        local Text_win_lose_all = Panel_itm:getChildByName("Text_win_lose_all")
        if table_data[i].ProfitStamp >= 0 then
            Text_win_lose_all:setString("+"..table_data[i].ProfitStamp)
            Text_win_lose_all:setTextColor(cc.c3b(254, 207, 79))
        else
            Text_win_lose_all:setString(table_data[i].ProfitStamp)
            Text_win_lose_all:setTextColor(cc.c3b(107, 214, 185))
        end

--        local Image_banker = Panel_itm:getChildByName("Image_banker")
--        if nil == table_data[i].Detail or table_data[i].Detail.bIsBanker == false then
--            Image_banker:removeFromParent()
--        end 

--        local Image_id = Panel_itm:getChildByName("Image_id")
--        local Text_id = Image_id:getChildByName("Text_id")
--        Text_id:setString("ID:"..tostring(table_data[i].playerID))
        local Text_id = Panel_itm:getChildByName("Text_id")
        Text_id:setString("ID:"..tostring(table_data[i].playerID))

        self.ListView:pushBackCustomItem(Panel_itm)
    end

end



return ConfRecordLayer

--endregion
