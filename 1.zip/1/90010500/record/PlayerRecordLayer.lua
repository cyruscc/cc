--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_clientmain = import("....room.clientmain")
local m_def = import("....room.module.basicnotifydef")
local m_download = import("....common.download")

local ConfRecordLayer = import(".ConfRecordLayer")


local PlayerRecordLayer = class("PlayerRecordLayer", function()
    return cc.CSLoader:createNode( "game_res/90010500/record/PlayerRecordLayer.csb" )
end)


function get_niu_point( niu_type )
    local points = {}
    points[0] = "无牛"
    points[1] = "牛一"
    points[2] = "牛二"
    points[3] = "牛三"
    points[4] = "牛四"
    points[5] = "牛五"
    points[6] = "牛六"
    points[7] = "牛七"
    points[8] = "牛八"
    points[9] = "牛九"
    points[10] = "牛牛"
    points[11] = "炸弹"
    points[12] = "金牛"
    points[13] = "五小牛"
    return points[ niu_type ]
end

function getCardsNiuPoint( table )
    if #table~= 5 then
        return nil
    end
    local points = {}
    points[0] = "牛牛"
    points[1] = "牛一"
    points[2] = "牛二"
    points[3] = "牛三"
    points[4] = "牛四"
    points[5] = "牛五"
    points[6] = "牛六"
    points[7] = "牛七"
    points[8] = "牛八"
    points[9] = "牛九"
    points[10] = "牛牛"
    points[11] = "炸弹"
    points[12] = "金牛"
    points[13] = "五小牛"
    local sums = 0
    for i=1 , 5 do
        table[i] = table[i]%16
        if(table[i]==15) then
            table[i] = 1
        else
            table[i] = table[i] + 1
        end
        sums = sums + table[i]
    end
    
    for i=1 , 5 do
        for j=i+1 , 5 do
            local sum =  table[i] + table[j]
            for k = j+1 , 5 do
                if( (sum + table[k]) %10 ==0) then
                    return points[ sums%10 ]
                end
            end
        end
    end
    return "无牛"
end


function PlayerRecordLayer:ctor(parent , roomInfo , playerInfo , playerList)

    self.RoomInfo = clone(roomInfo)
    self.playerInfo = clone(playerInfo)
	self.parent = parent
    self.playerList = clone(playerList)

    local Panel_root = self:getChildByName("Panel_root")

    self.Image_root = Panel_root:getChildByName("Image_root")
    api_action_showPageLayer( self.Image_root )

    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end)


    local Image_head = self.Image_root:getChildByName("Image_head")
    m_download:get_instance():set_record_head_image_and_auto_update( Image_head ,playerInfo.HeadStr , playerInfo.PlayerUserID )

    self.Text_desc = self.Image_root:getChildByName("Text_desc")
    
    self.ListView = self.Image_root:getChildByName("ListView")
    local Panel_itm = self.Image_root:getChildByName("Panel_itm")
    self.ItmCln = Panel_itm:clone()
    self.ItmCln:retain()
    Panel_itm:removeFromParent()

    --self:updateListView({1, 2, 4, 5, 7})

    self:registerScriptHandler(handler(self,self.onNodeEvent))
 
end

function PlayerRecordLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end

function PlayerRecordLayer:onNodeEvent(event)
    if event == "enter" then
        g_pushBombBox(self)
        
        if nil ==  m_clientmain:get_instance():get_gameRecord_mgr():get_record_cell_by_room_id( self.RoomInfo.RoomID ) then
            api_show_loading_ext( 10 )
            m_clientmain:get_instance():get_gameRecord_mgr():get_event_mgr():BsAddNotifyEvent( m_def.NOTIFY_GAME_RECORD_EVENT , handler( self , self.onGameRecod) )
            m_clientmain:get_instance():get_gameRecord_mgr():request_gameRecord_by_room_cell( self.RoomInfo.GameID , self.RoomInfo.RoomID )
        else
            self:updateListView()
        end   
        
    elseif event == "exit" then
        g_popBombBox(self)
    end
end

function PlayerRecordLayer:updateListView()
    local table_data = getRecordItemByPlayers( m_clientmain:get_instance():get_gameRecord_mgr():get_record_cell_by_room_id(self.RoomInfo.RoomID) , self.playerInfo.PlayerUserID )
    self.Text_desc:setString("\""..api_get_ascll_sub_str_by_ui(self.playerInfo.NickName,14).."\"的游戏记录，总共参与"..#table_data.."局")
    self.ListView:removeAllItems()
    local win_lose_all = 0
    for i=1,  #table_data do

        local Panel_itm = self.ItmCln:clone()
        Panel_itm:addClickEventListener(function()
            self.parent:addChild( ConfRecordLayer:create(self.parent , table_data[i] , self.RoomInfo , self.playerList, self.playerInfo.NickName) )
        end)

        local Button_search = Panel_itm:getChildByName("Button_search")
        Button_search:addClickEventListener(function()
            self.parent:addChild( ConfRecordLayer:create(self.parent , table_data[i] , self.RoomInfo , self.playerList, self.playerInfo.NickName) )
        end)

        local Text_board_num = Panel_itm:getChildByName("Text_board_num")
        Text_board_num:setString(tostring(table_data[i].GameRoundID))

        local Text_type = Panel_itm:getChildByName("Text_type")
         if table_data[i].Detail and  table_data[i].Detail.cards then
             Text_type:setString( get_niu_point( table_data[i].Detail.cardType ) )
         end
       

        local Text_win_lose = Panel_itm:getChildByName("Text_win_lose")
        if tonumber(table_data[i].ChangedPoints) > 0 then
            Text_win_lose:setString("+"..table_data[i].ChangedPoints)
            Text_win_lose:setTextColor(cc.c3b(254, 207, 79))
        else
            Text_win_lose:setString(table_data[i].ChangedPoints)
            Text_win_lose:setTextColor(cc.c3b(107, 214, 185))
        end

        local Text_win_lose_all = Panel_itm:getChildByName("Text_win_lose_all")
        if table_data[i].ProfitStamp >= 0 then
            Text_win_lose_all:setString("+"..table_data[i].ProfitStamp)
            Text_win_lose_all:setTextColor(cc.c3b(254, 207, 79))
        else
            Text_win_lose_all:setString(table_data[i].ProfitStamp)
            Text_win_lose_all:setTextColor(cc.c3b(107, 214, 185))
        end


--        local Image_banker = Panel_itm:getChildByName("Image_banker")
--        if nil == table_data[i].Detail or table_data[i].Detail.bIsBanker == false then
--            Image_banker:removeFromParent()
--        end  
        self.ListView:pushBackCustomItem(Panel_itm)
    end

end

function getRecordItemByPlayers( data , playerID )
    local ret = {}
    for key , var  in pairs(data) do
        if var.playerID == playerID then
            table.insert( ret , var )
        end
    end    
    return ret
end


function PlayerRecordLayer:onGameRecod(event)
    api_hide_loading()
    if nil == event or nil == event.args then
        return
    end
    local param = event.args
    if param.event_id == m_def.NOTIFY_GAME_RECORD_EVENT_ROOM_CELL then
        if param.event_data.ret ~= 0 then
	        api_show_Msg_Tip(param.event_data.desc)
        else
            if param.event_data.request.roomid == self.RoomInfo.RoomID then
                self:updateListView()
            end            
        end
    end
end

return PlayerRecordLayer

--endregion
