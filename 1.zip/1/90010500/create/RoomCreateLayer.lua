﻿--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_clientmain = import("....room.clientmain")
local m_def = import("....room.module.basicnotifydef")
local IllegalString = import("....room.common.IllegalString")
local HelpLayer = import("..help.HelpLayer")

local RoomCreateLayer = class("RoomCreateLayer", function()
    if g_config.has_once_game then
        return cc.CSLoader:createNode( "game_res/90010500/create/RoomCreateLayer.csb" )
    else
        return cc.CSLoader:createNode( "game_res/90010500/createNew/RoomCreateLayer.csb" )
    end
end)

local MAX_ROOM_LEN = 8

local MAX_BET = 20      -- 最高的倍数
local MIN_BET = 1       -- 最低的倍数

local IN_1 = 0          -- 牛点下标的最小值
local IN_2 = 13         -- 牛点下标的最大值

local DESK_CONFIG = {}

local ROLE = { "0","1" }

DESK_CONFIG[ROLE[1]] = {}
DESK_CONFIG[ROLE[2]] = {}
DESK_CONFIG[ROLE[1]].initGameRound = { 10 , 20 , 30 , 40 , 50 , 60 }  -- 固定底注 可选择的局数
DESK_CONFIG[ROLE[1]].RoundToCard   = { 1  , 1  , 1  , 2  , 2  , 2  }  -- 固定底注 选择的局数对应需要消耗的房卡
DESK_CONFIG[ROLE[2]].initGameRound = { 10 , 20 , 30 , 40 , 50 , 60 }  -- 血拼玩法 可选择的局数
DESK_CONFIG[ROLE[2]].RoundToCard   = { 1  , 1  , 1  , 2  , 2  , 2  }  -- 血拼玩法 选择的局数对应需要消耗的房卡

DESK_CONFIG[ROLE[1]].initBets = { 1, 5, 10  }                         -- 固定底注 可选择的倍数
DESK_CONFIG[ROLE[2]].initBets = { 1 }                                 -- 血拼玩法 可选择的倍数

        -- 初始分数 的算法 ： 由选择的底注值 * 选择的初始分数下标的对应值
DESK_CONFIG[ROLE[1]].initPoints = { 0 , 100 , 1000 }                  -- 固定底注 可选择的初始分数
DESK_CONFIG[ROLE[2]].initPoints = { 0 , 100, 500,1000, 5000, 10000 }  -- 血拼玩法 可选择的初始分数


local game_set_names   = { "无牛" , "牛丁" , "牛二" , "牛三" , "牛四" , "牛五" , "牛六" , "牛七" , "牛八" , "牛九" , "牛牛" , "炸弹" , "金牛" , "五小" }
    -- 固定底注的默认牛点的倍数
DESK_CONFIG[ROLE[1]].bullBet = {   1    ,    1   ,   1    ,    1   ,    1   ,   1    ,    1   ,    2   ,    3   ,    4   ,    5   ,    5   ,   5    ,   5    }
    -- 血拼玩法的默认牛点的倍数
DESK_CONFIG[ROLE[2]].bullBet = {   1    ,    1   ,   1    ,    1   ,    1   ,   1    ,    1   ,    2   ,    2   ,    3   ,    5   ,    5   ,   5    ,   5    }


local m_dufault_role = ROLE[2]    -- 0.固定底注的玩法 1.血拼的玩法

local m_desk_config_select = nil
local game_desk_config = nil


local function set_value( obj ,key , value )
    if obj~=nil and obj[key] == nil then
        obj[key] = value
    end
end

local function setGameDeskConfig()
    UserData:setGameDeskConfig( g_config.game_id_list[1] , m_desk_config_select )
end

function RoomCreateLayer:ctor()   
    self:registerScriptHandler(handler(self,self.onNodeEvent))
    	
    self.Image_bg = self:getChildByName("Image_bg")
    local Button_close = self.Image_bg:getChildByName("Button_close")
    if Button_close then
	    Button_close:addClickEventListener(function()
		    self:recvKeyBack()
	    end)
    end
end

function RoomCreateLayer:request_desk_config()
    api_show_loading_ext( 10 )
    m_clientmain:get_instance():get_desk_mgr():request_desk_config( g_config.game_id_list[1] )
end

function RoomCreateLayer:updateRoomConfig( )
    if self.isUpdate then
        return nil
    end
    self.isUpdate = true
    
    local room_config = m_clientmain:get_instance():get_desk_mgr():get_desk_config( g_config.game_id_list[1] )
    for i = 1 , 2 do
        DESK_CONFIG[ROLE[i]].initGameRound = { }  -- 固定底注 可选择的局数
        DESK_CONFIG[ROLE[i]].RoundToCard   = { }  -- 固定底注 选择的局数对应需要消耗的房卡
    end

    for key , var in pairs( room_config ) do
        if var.title == 'Round' then
            for key1 , var1 in pairs(var.cell) do
                for i = 1 , 2 do
                    table.insert( DESK_CONFIG[ROLE[i]].initGameRound , var1.Round )
                    table.insert( DESK_CONFIG[ROLE[i]].RoundToCard , var1.RoomCard )
                end
            end
        end
    end

    local userinfo = m_clientmain:get_instance():get_user_mgr():get_user_info()
    m_desk_config_select = UserData:getGameDeskConfig( g_config.game_id_list[1] )

    if m_desk_config_select == nil then
        m_desk_config_select = {}
    end
    set_value( m_desk_config_select , "Role" , {} )
    set_value( m_desk_config_select , "selectRoleID" , m_dufault_role )
    
    local roomName = userinfo.NickName --api_get_sub_utf8_str( userinfo.NickName , MAX_ROOM_LEN)
    
    for i = 1 , #ROLE do        
        set_value( m_desk_config_select.Role , ROLE[i] , {} )
        local role = m_desk_config_select.Role[ ROLE[i] ]
        set_value( role , 'desk_name' , roomName )
        set_value( role , 'desk_desc' , "" )
        set_value( role , 'desk_init_point' ,  DESK_CONFIG[ ROLE[i] ].initPoints[1] )
        set_value( role , 'config' , {} )
        local config = role.config
        set_value( config , 'NoteType' , tonumber(tostring(ROLE[i])) )
        set_value( config , 'bankerType' , 1 )    -- 0.轮庄 1.随机庄
        set_value( config , 'maxRounds' , DESK_CONFIG[ ROLE[i] ].initGameRound[1])
        set_value( config , 'antes' , DESK_CONFIG[ ROLE[i] ].initBets[1])
        set_value( config , 'bullPointBet' , clone( DESK_CONFIG[ ROLE[1] ].bullBet ) )
        
    end

    self.Panel_plat_set = self.Image_bg:getChildByName("Panel_plat_set")
    local Panel_set = self.Panel_plat_set:getChildByName("Panel_set")
    ------------------------------------------------------------------------------------------------
	--房间名称
    local Image_room_name = Panel_set:getChildByName("Image_room_name")
    local TextField_roomName = Image_room_name:getChildByName("TextField_roomName")
	self.TextField_roomName = MyEditBox:TextFiled_to_EditBox(TextField_roomName)
	self.TextField_roomName:setMaxLength( MAX_ROOM_LEN )
	------------------------------------------------------------------------------------------------
    --房间局数
	local Image_game_play_count = Panel_set:getChildByName("Image_game_play_count")
		self.init_point_select_item = {}
		for i=1,6,1 do
            self.init_point_select_item[i] = {}
            self.init_point_select_item[i].Text_item = Image_game_play_count:getChildByName("Text_item_"..i-1)
			self.init_point_select_item[i].Button_item = Image_game_play_count:getChildByName("Button_item_"..i-1)
			self.init_point_select_item[i].Button_item:addClickEventListener( function( )
                Music:playEffect_click()
				self:setGamePlayCountItem( i )
                setGameDeskConfig()
			end)
		end
    ------------------------------------------------------------------------------------------------
	--底注
	local Image_game_bet = Panel_set:getChildByName("Image_game_bet")
		self.Text_game_bet = Image_game_bet:getChildByName("Text_game_bet")
    	self.Button_bet_add = Image_game_bet:getChildByName("Button_add")
		self.Button_bet_add:addClickEventListener( function()
            Music:playEffect_click()
			self:addGameBet_index(1)
		end)
		self.Button_bet_subtraction = Image_game_bet:getChildByName("Button_subtraction")
		self.Button_bet_subtraction:addClickEventListener( function()
            Music:playEffect_click()
			self:addGameBet_index(-1)
		end)
	------------------------------------------------------------------------------------------------
    --初始分数
	local Image_init_point = Panel_set:getChildByName("Image_init_point")
		self.Text_init_point = Image_init_point:getChildByName("Text_init_point")
		self.Button_point_add = Image_init_point:getChildByName("Button_add")
		self.Button_point_add:addClickEventListener( function()
            Music:playEffect_click()
			self:addInitPointIndex( 1 )
		end)
		self.Button_point_subtraction = Image_init_point:getChildByName("Button_subtraction")
		self.Button_point_subtraction:addClickEventListener( function()
            Music:playEffect_click()
			self:addInitPointIndex( -1 )
		end)
	
	------------------------------------------------------------------------------------------------
    -- 选庄方式
    self.Image_banker_type = Panel_set:getChildByName("Image_banker_type")
    self.Button_banker_type = {}
    for i = 0 , 1 do        
        self.Button_banker_type[i] = Panel_set:getChildByName("Button_banker_"..i)
        self.Button_banker_type[i]:addClickEventListener( function()
            Music:playEffect_click()
            self:select_banker_type(i)
            setGameDeskConfig()
        end)
    end
    
    ------------------------------------------------------------------------------------------------
	--需要的房卡
	self.Text_neet_room_count = self.Panel_plat_set:getChildByName("Text_neet_room_count")
    if g_config.has_shop == false then
        self.Text_neet_room_count:setVisible( false )
    end
	--现有的房卡
	self.Text_my_room_card_count = self.Panel_plat_set:getChildByName("Text_my_room_card_count")
    if g_config.has_shop == false then
        self.Text_my_room_card_count:setVisible( false )
    end
	

    ------------------------------------------------------------------------------------------------
    local Image_game_set = self.Panel_plat_set:getChildByName("Image_game_set")
    Panel_game_set_rect = Image_game_set:getChildByName("Panel_game_set_rect")
    self.Text_game_set = Panel_game_set_rect:getChildByName("Text_game_set")
    
 

    -- 修改游戏配置（牛点的倍率）
    self.Button_modif_game = Panel_set:getChildByName("Button_modif_game")
        self.Button_modif_game:addClickEventListener( function()
            self.Panel_plat_set:setVisible(false)
            self.Panel_game_set:setVisible(true)
        end)

    self.Panel_game_set = self.Image_bg:getChildByName("Panel_game_set")
    self.Panel_game_set:setVisible( false )
    
    ------------------------------------------------------------------------------------------------
    -- 创建房间的按钮
	local Button_create = self.Panel_plat_set:getChildByName("Button_create")
		Button_create:addClickEventListener(function()
        local goods_list = m_clientmain:get_instance():get_goods_mgr():get_goods_list(g_payType)
        local props_list = m_clientmain:get_instance():get_goods_mgr():get_props_list_by_roomCard()
            Music:playEffect_click()
            game_desk_config.desk_name                 = self.TextField_roomName:getText()
            if game_desk_config.desk_name=="" or IllegalString:stringIsLegal(desk_name)==false  then
                api_show_tips("您输入的房间名称不符合规范")
                return nil
            end
            game_desk_config.desk_desc                 = ""
            if IllegalString:stringIsLegal(game_desk_config.desk_desc)==false then
               api_show_tips("您输入的房间介绍不符合规范")
               return nil
            end
            local needRoomCard = tonumber(self.Text_neet_room_count:getString())
            if needRoomCard > userinfo.RoomCard then
                local less_room_card = needRoomCard - userinfo.RoomCard
                if props_list  then
                    for key , var in pairs(props_list) do
                        if var.PropCount >= less_room_card then
                            if var.Price <= userinfo.Treasure then
                                self:create_room_card_small( less_room_card )
                            else
                                self:create_diamond_small( var.Price - userinfo.Treasure)
                            end
                            return nil
                        end
                    end
                end
                self:create_room_card_small()
                return nil 
            end  
            api_show_loading_ext( 10 )

            setGameDeskConfig()

            --进行 base64 加密 ， 有些特殊的符号会导致 w解析 json 出错 如 L'andti
            game_desk_config.desk_name = ToBase64( game_desk_config.desk_name )
            m_clientmain:get_instance():get_desk_mgr():send_async_request_create_desk( g_config.game_id_list[1] , game_desk_config.desk_init_point , game_desk_config.desk_name , game_desk_config.desk_desc ,  game_desk_config.config )

		end)
	
    ------------------------------------------------------------------------------------------------
    -- 玩法选择
	local Image_select_role = self.Panel_plat_set:getChildByName("Image_select_role")
		self.Button_role = {}
		for key , var in pairs(ROLE) do
			local str = "Button_role_"..var
            print( str )
			self.Button_role[var] = Image_select_role:getChildByName( str )
			self.Button_role[var] :addClickEventListener(function()
                Music:playEffect_click()
				self:setSelectRole( var )
                setGameDeskConfig()
			end)
		end
	local Panel_no_open = Image_select_role:getChildByName('Panel_no_open')
	if Panel_no_open then
		for i = 1 , 100 do
			local Button_role = Panel_no_open:getChildByName('Button_role_'..i)
			if Button_role then
				Button_role:addClickEventListener(function()
					api_show_tips("游戏即将上线，敬请期待！")
				end)
			else
				break
			end
		end
	end

    local Panel_set = self.Panel_plat_set:getChildByName("Panel_set")

    self:setSelectRole( m_desk_config_select.selectRoleID )
        local Button_desc  = Image_select_role:getChildByName( "Button_desc" )
        Button_desc:addClickEventListener( function()
            local scene = CCDirector:getInstance():getRunningScene()
            scene:addChild ( HelpLayer:create(game_desk_config.config.bankerType+2) )
        end)

    self:updateSelfInfo()
end

function RoomCreateLayer:recvKeyBack()
    self:removeFromParent()
end

function RoomCreateLayer:onNodeEvent(event)
    if event == "enter" then
        m_clientmain:get_instance():get_desk_mgr():get_event_mgr():BsAddNotifyEvent( m_def.NOTIFY_DESK_EVENT , handler( self , self.onDeskEvent ) , self)
        m_clientmain:get_instance():get_game_manager():get_game_room_mgr():get_event_mgr():BsAddNotifyEvent(  m_def.NOTIFY_DESK_EVENT , handler( self , self.onDeskEvent ) , self )
        local room_config = m_clientmain:get_instance():get_desk_mgr():get_desk_config( g_config.game_id_list[1] )
        if room_config == nil then
            self:request_desk_config()
        else
            self:updateRoomConfig()
        end
        if g_config.has_once_game then
            g_pushBombBox(self)
        end
    elseif event == "exit" then
        m_clientmain:get_instance():get_desk_mgr():get_event_mgr():BsRemoveNotifyEvent( m_def.NOTIFY_DESK_EVENT , self )
        m_clientmain:get_instance():get_game_manager():get_game_room_mgr():get_event_mgr():BsRemoveNotifyEvent(  m_def.NOTIFY_DESK_EVENT , self )
        if g_config.has_once_game then
            g_popBombBox(self)
        end
    end
end

function RoomCreateLayer:select_banker_type( type )
    game_desk_config.config.bankerType = type
    self.Image_banker_type:setPosition(self.Button_banker_type[type]:getPosition())
    for i = 0 , #self.Button_banker_type do
        self.Button_banker_type[i]:setTouchEnabled( type ~= i )
    end
end

------------------------------------------------------------------------------------------------
-- 牛点倍率的设置 （无牛-牛牛-五小牛的倍率设置）层
function RoomCreateLayer:bull_point_bet_set_panel()
    local datas = ""
    local function g(index)
        return game_desk_config.config.bullPointBet[index+1-IN_1]
    end

    local text_game_set_items = {}

    -- 检查某一项的 加 按钮是否可点击
    local function check_add_button_is_click( index )
        if IN_1 <= index and index <= IN_2 then
            -- 最后一个按钮没有达到上限就可以点击
            -- 只要比上一个按钮的数值少 2 以上就可以点击
            if (index == IN_2 and g(index)<MAX_BET ) or ( index < IN_2 and g(index) < g(index+1) ) then
                text_game_set_items[index].Button_add:setTouchEnabled(true)
                text_game_set_items[index].Button_add:setBright(true)
            else
                text_game_set_items[index].Button_add:setTouchEnabled(false)
                text_game_set_items[index].Button_add:setBright(false)
            end
        end
    end

    -- 检查某一项的 减 按钮是否可点击
    local function check_sub_button_is_click( index )
        if IN_1 <= index and index <=IN_2 then
            if (index == IN_1 and g(index)>MIN_BET) or ( index > IN_1 and g(index) > g(index-1) ) then
                text_game_set_items[index].Button_subtraction:setTouchEnabled(true)
                text_game_set_items[index].Button_subtraction:setBright(true)
            else
                text_game_set_items[index].Button_subtraction:setTouchEnabled(false)
                text_game_set_items[index].Button_subtraction:setBright(false)
            end
        end       
    end

    local function set_item_value( index , value )
        if MIN_BET <= value and value <= MAX_BET then
            game_desk_config.config.bullPointBet[index+1] = value
            setGameDeskConfig()
            text_game_set_items[index].Text_data:setString( g(index) )
            check_sub_button_is_click( index )
            check_add_button_is_click( index )
        end
    end

    local function update_game_config_value()
        datas = ""
        for i=IN_1 , IN_2 do
            datas = datas..game_set_names[i+1].."x"..g(i)
            if i<IN_2 then
                datas = datas.." "
            end
        end
        self.Text_game_set:setString( datas )
    end

        -- 初始化牛点的倍率
    local function init_bull_point()
        for i=IN_1 ,IN_2 do
            set_item_value( i , g(i) )
        end
        update_game_config_value()
    end

    local Text_clone = self.Panel_game_set:getChildByName("Text_clone")

    for i=IN_1 ,IN_2 do
        text_game_set_items[i] = {}
        local Text_ = nil
        if Text_clone then
            Text_ =    Text_clone:clone()
            self.Panel_game_set:addChild( Text_ )
            Text_:setText( game_set_names[i+1] )
            local x = math.floor( math.mod( i , 3 ) ) *  ( 400 - 76 ) +  Text_clone:getPositionX() 
            local y = Text_clone:getPositionY() -( math.floor( i / 3 ) * 97.5 )
            Text_:setPositionX( x )
            Text_:setPositionY( y )
        else
            Text_ = self.Panel_game_set:getChildByName("Text_"..i)
        end
        text_game_set_items[i].Button_subtraction = Text_:getChildByName("Button_subtraction")
            text_game_set_items[i].Button_subtraction:addClickEventListener( function()
                Music:playEffect_click()
                set_item_value( i , g(i)-1 )
                update_game_config_value()
                check_sub_button_is_click( i + 1 )
                check_add_button_is_click( i - 1 )
            end)
        text_game_set_items[i].Button_add = Text_:getChildByName("Button_add")
            text_game_set_items[i].Button_add:addClickEventListener( function()
                Music:playEffect_click()
                set_item_value( i , g(i)+1 )
                update_game_config_value()
                check_sub_button_is_click( i + 1 )
                check_add_button_is_click( i - 1 )
            end)
        text_game_set_items[i].Text_data = Text_:getChildByName("Text_data")
    end
    if Text_clone then
        Text_clone:removeFromParent()
    end

    init_bull_point()

    -- 返回到修改平台配置的按钮
    local Button_modif_plat = self.Panel_game_set:getChildByName("Button_modif_plat")
        Button_modif_plat:addClickEventListener( function()
            self.Panel_plat_set:setVisible(true)
            self.Panel_game_set:setVisible(false)
        end)

    -- 重置的按钮
    local Button_reset = self.Panel_game_set:getChildByName("Button_reset")
        Button_reset:addClickEventListener( function()
            game_desk_config.config.bullPointBet =  clone( DESK_CONFIG[tostring(game_desk_config.config.NoteType)].bullBet )
            init_bull_point()
        end)

end

-- 玩法选择层 （ 固定底注 、 温州血拼 ）
function RoomCreateLayer:setSelectRole( role_id )
    m_desk_config_select.selectRoleID = role_id
    game_desk_config = m_desk_config_select.Role[ tostring(role_id) ]
    
    self.TextField_roomName:setText( api_get_sub_utf8_str( game_desk_config.desk_name , MAX_ROOM_LEN ))
     
    self.select_bets_index = 1          -- 选择的底注下标
    self.select_point_index = 1    -- 选择的初始分数的下标
    self.select_round_index = 1    -- 选择的初始分数的下标



    --@desc 检查 选择的倍数 所在的下标
    local function check_init_bets_index()
        for i = 1 , #DESK_CONFIG[ m_desk_config_select.selectRoleID ].initBets do           
            if DESK_CONFIG[ m_desk_config_select.selectRoleID ].initBets[i] ==  game_desk_config.config.antes then
                self.select_bets_index = i
                return
            end
        end
    end

    --@desc 检查 选择的初始分数 所在的下标
    local function check_init_point_index() 
         for i = 1 , #DESK_CONFIG[ m_desk_config_select.selectRoleID ].initPoints do           
            if DESK_CONFIG[ m_desk_config_select.selectRoleID ].initPoints[i] ==  game_desk_config.desk_init_point * game_desk_config.config.antes then
                self.select_point_index= i
                return
            end
        end
    end
    
    local function check_init_round_index()
        for i=1 , #DESK_CONFIG[ role_id ].initGameRound do
            self.init_point_select_item[i].Text_item:setString( DESK_CONFIG[ role_id ].initGameRound[i] )
        end
        
        for i = 1 , #DESK_CONFIG[ m_desk_config_select.selectRoleID ].initGameRound do           
            if DESK_CONFIG[ m_desk_config_select.selectRoleID ].initGameRound[i] ==  game_desk_config.config.maxRounds then
                self.select_round_index  = i
                return
            end
        end
    end

    check_init_point_index()
    check_init_bets_index()
    check_init_round_index()

    self:addGameBet_index(0)
    self:addInitPointIndex(0)
    self:setGamePlayCountItem( self.select_round_index )

	for key , var in pairs(ROLE) do
		local Button_roles = self.Button_role[ var ]
		local Image_font = Button_roles:getChildByName("Image_font")
        
        Button_roles:setTouchEnabled( var ~= role_id )
		Button_roles:setBright( var ~= role_id )
		if var == role_id then
			Image_font:loadTexture( "game_res/90010500/create/role_"..var.."_select.png")
		else
			Image_font:loadTexture( "game_res/90010500/create/role_"..var.."_normal.png")
		end	
	end

    if role_id == ROLE[2] then
        self.Button_modif_game:setVisible(false)
    else
        self.Button_modif_game:setVisible(true)
    end

    self:select_banker_type( game_desk_config.config.bankerType )
    self:updateInitPoint()
    self:bull_point_bet_set_panel()

end

function RoomCreateLayer:setGamePlayCountItem( index )
	for j=1,6,1 do
		if j == index then
			self.init_point_select_item[ j ].Button_item:setTouchEnabled(false)
			self.init_point_select_item[ j ].Button_item:setBright( false )
            self.init_point_select_item[ j ].Text_item:setFontSize( 24 )
            self.init_point_select_item[ j ].Text_item:setColor(cc.c3b(255,241,76))
		else
			self.init_point_select_item[ j ].Button_item:setTouchEnabled(true)
			self.init_point_select_item[ j ].Button_item:setBright( true )
            self.init_point_select_item[ j ].Text_item:setFontSize( 20 )
            self.init_point_select_item[ j ].Text_item:setColor(cc.c3b(198,187,231))
		end
	end
    game_desk_config.config.maxRounds = DESK_CONFIG[m_desk_config_select.selectRoleID].initGameRound[index]
    game_desk_config.config.Round = {}
    game_desk_config.config.Round.id = index
	self.Text_neet_room_count:setString( DESK_CONFIG[m_desk_config_select.selectRoleID].RoundToCard[index] )
end

function RoomCreateLayer:updateInitPoint()
    game_desk_config.desk_init_point = DESK_CONFIG[m_desk_config_select.selectRoleID].initPoints[self.select_point_index] * DESK_CONFIG[m_desk_config_select.selectRoleID].initBets[ self.select_bets_index ]
    self.Text_init_point:setString( game_desk_config.desk_init_point )
end

function RoomCreateLayer:addInitPointIndex( index )
	local curIndex = self.select_point_index + index
    if curIndex > 0 and curIndex<= #DESK_CONFIG[m_desk_config_select.selectRoleID].initPoints then
        self.select_point_index = curIndex
        self:updateInitPoint()
        self.Button_point_subtraction:setTouchEnabled( curIndex > 1 )
        self.Button_point_subtraction:setBright( curIndex > 1 )
        self.Button_point_add:setTouchEnabled( curIndex < #DESK_CONFIG[m_desk_config_select.selectRoleID].initPoints )
        self.Button_point_add:setBright( curIndex < #DESK_CONFIG[m_desk_config_select.selectRoleID].initPoints )
    end
end

function RoomCreateLayer:addGameBet_index( index )
	local curIndex = self.select_bets_index + index
    if curIndex > 0 and curIndex<= #DESK_CONFIG[m_desk_config_select.selectRoleID].initBets then
        self.select_bets_index = curIndex
        self.Text_game_bet:setString( DESK_CONFIG[m_desk_config_select.selectRoleID].initBets[ curIndex ] )
        game_desk_config.config.antes = DESK_CONFIG[m_desk_config_select.selectRoleID].initBets[ curIndex ]
        self:updateInitPoint()
        self.Button_bet_subtraction:setTouchEnabled( curIndex > 1 )
        self.Button_bet_subtraction:setBright( curIndex > 1 )
        self.Button_bet_add:setTouchEnabled( curIndex < #DESK_CONFIG[m_desk_config_select.selectRoleID].initBets )
        self.Button_bet_add:setBright( curIndex < #DESK_CONFIG[m_desk_config_select.selectRoleID].initBets )
    end
end

function RoomCreateLayer:create_diamond_small( less_diamond )
    -- 钻石不足
    print("最少需要买 " , less_diamond ,  "个钻石" )
    api_show_Msg_Tip( "房卡不足，是否前往充值", function ()
        local param_1 =  clone(m_def.NotifyParam)
        param_1.event_id = m_def.NOTIFY_EVENT_SCENE_COMMAND
        param_1.event_data.data = {}
        param_1.event_data.data.command = "open-shopLayer-0"
        m_clientmain:get_instance():get_user_mgr():get_event_mgr():BsNotifyEvent( m_def.NOTIFY_EVENT_SCENE , param_1)
    end )
end

function RoomCreateLayer:create_room_card_small( less_room_card )
    --房卡不足
    print("最少需要买 " , less_room_card ,  "张房卡" )
    if g_config.has_shop == false then
        api_show_Msg_Box("您的房卡不足！")
    else
        api_show_Msg_Tip( "房卡不足，是否前往充值", function ()
            local param_1 =  clone(m_def.NotifyParam)
            param_1.event_id = m_def.NOTIFY_EVENT_SCENE_COMMAND
            param_1.event_data.data = {}
            param_1.event_data.data.command = "open-shopLayer-1"
            m_clientmain:get_instance():get_user_mgr():get_event_mgr():BsNotifyEvent( m_def.NOTIFY_EVENT_SCENE , param_1)
        end )
    end
 
end

function RoomCreateLayer:create_vip_level_small()
    if g_config.has_shop == false then
        api_show_Msg_Box("您已经创建了房间，请勿重复创建！")
    else
        local user_info = m_clientmain:get_instance():get_user_mgr():get_user_info()
        local cur_max_vip_level , cur_max_vip_endTime = m_clientmain:get_instance():get_user_mgr():get_user_module():update_vip_info( user_info.VipInfo )
        local function to_vip_layer( level , tips)
            if g_config.has_shop == true then
                api_show_Msg_Tip( '您只能同时创建'..level..'个房间，升级会员创建更多点击确认前往商城' , function() 
                    local param_1 =  clone(m_def.NotifyParam)
                    param_1.event_id = m_def.NOTIFY_EVENT_SCENE_COMMAND
                    param_1.event_data.data = {}
                    param_1.event_data.data.command = "open-vipLayer"
                    m_clientmain:get_instance():get_user_mgr():get_event_mgr():BsNotifyEvent( m_def.NOTIFY_EVENT_SCENE , param_1)
                end)
            else
                api_show_Msg_Box( "您已经创建私人场，请勿重复创建" )
            end
        end
        if cur_max_vip_level == 3 then
            api_show_Msg_Box( "您同时创建的房间数量已达上限" , handler( self , self.recvKeyBack ) )
        elseif cur_max_vip_level == 2 then
            to_vip_layer( 3 )
        elseif cur_max_vip_level == 1 then
            to_vip_layer( 2 )
        elseif cur_max_vip_level == 0 then
            to_vip_layer( 1 )
        end
    end    
end

function RoomCreateLayer:onDeskEvent( event )
    api_hide_loading()
    if nil == event or nil == event.args then
        return
    end
    local param = event.args
    if param.event_id == m_def.NOTIFY_DESK_EVENT_CREATE then
        if 0 == param.event_data.ret then
            --创建私人场成功
            local desk_info = param.event_data.data
            self:updateSelfInfo()
        elseif 1 == param.event_data.ret then
            --房卡不足
            self:create_room_card_small()
        elseif 5 == param.event_data.ret then
            -- vip等级对应可创建的私人场已经达到上限
            self:create_vip_level_small()
        else
            api_show_Msg_Box( param.event_data.desc )
        end
    elseif param.event_id == m_def.NOTIFY_DESK_EVENT_ENTER then
        if 0 ~= param.event_data.ret then
            api_show_tips( param.event_data.desc )
        end
    elseif param.event_id == m_def.NOTIFY_DESK_EVENT_DESK_CONGIG then
        if 0 == param.event_data.ret then
            self:updateRoomConfig()
        else
            api_show_Msg_Tip( param.event_data.desc , handler(self , self.request_desk_config) , handler(self , self.recvKeyBack) )
        end
    end
end

function RoomCreateLayer:updateSelfInfo()
    local user_info = m_clientmain:get_instance():get_user_mgr():get_user_info()
    self.Text_my_room_card_count:setString( tostring( user_info.RoomCard ) )
end

return RoomCreateLayer


--endregion
