--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local CHelpLayer = class("CHelpLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/help/HelpLayer.csb")
end)
-- index
-- 1.
function CHelpLayer:ctor( index )
    
    self:registerScriptHandler(handler(self,self.onNodeEvent))
    self.Image_bg = self:getChildByName("Image_bg")
    api_action_fade_show( self.Image_bg ,0.5 )
    local Button_close = self.Image_bg:getChildByName("Button_close")
        Button_close:addClickEventListener( function()
            self:recvKeyBack()
        end)

    self.ScrollView_data = self.Image_bg:getChildByName("ScrollView_data")

    self.Panel = {}
    self.Button = {}
    local Image_top_button = self.Image_bg:getChildByName("Image_top_button")
    for i = 1 , 5 do
        self.Panel[i] =  self.ScrollView_data:getChildByName("Panel_"..tostring(i) )
        self.Panel[i]:setVisible( false )
        self.Button[i] = Image_top_button:getChildByName("Button_"..tostring(i))
        self.Button[i]:addClickEventListener( function()
            Music:playEffect_click()
            self:setPanelIndex( i )
        end)
    end
    self.curIndex = nil
    self:setPanelIndex( index )
end

function CHelpLayer:setPanelIndex( index )
    if index > 3 then
        api_show_tips("功能尚未开发，敬请期待！")
        return nil
    end
    if self.curIndex then
        self.Panel[self.curIndex]:setVisible( false )
        self.Button[ self.curIndex ]:setTouchEnabled(true)
        self.Button[ self.curIndex ]:setBright( true )
    end

    self.Button[ index ]:setTouchEnabled( false )
    self.Button[ index ]:setBright( false )

    self.Panel[ index ]:setVisible( true )
    self.ScrollView_data:setInnerContainerSize( self.Panel[index]:getSize() )
    self.ScrollView_data:scrollToTop( 0 , true )
    self.Panel[index]:setPositionY( self.Panel[index]:getSize().height )
    self.curIndex = index
end

function CHelpLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_fade_hide( self.Image_bg , 0.5 , function ()
            self:removeFromParent()
        end)
    end
end

function CHelpLayer:onNodeEvent(event)
    if event == "enter" then
        g_pushBombBox(self)
    elseif event == "exit" then
        g_popBombBox(self)
    end
end

return CHelpLayer

--endregion
