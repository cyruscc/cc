--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

module("ViewHelp", package.seeall)
local CGameManger = import("app.platform.game.gamemanager")

local Base_Pos = 
{
    userID = tonumber(CGameManger:get_instance():get_client_main():get_user_mgr():get_user_info().UserID),
    chair = -1,
    l_chair = -1
}

local game_scene = nil

local leave_enable = true

local last_mutiply = -1

local banker_chair = -1

local table_voice_not = {}


function getUIObject(chair, table_ui_object, last_state)
    if not chair or chair<0 then
       return nil
    end
    chair = tonumber(chair)
    local base_chair = -1
    if not last_state or last_state==false then
        base_chair = Base_Pos.chair
    else
        base_chair = Base_Pos.l_chair
    end
    if base_chair<0 then
       return table_ui_object[chair+1]
    else
       return table_ui_object[(chair-base_chair+5)%5+1]
    end
end

function initBasePosChair()
    Base_Pos.chair = -1
    Base_Pos.l_chair = -1
end

function initVoiceNotTable()
    table_voice_not = {}
end

function insertVoiceNotTable(userID)
    if table_voice_not == nil then
        table_voice_not = {}
    end
    table_voice_not[userID] = true
end

function removeVoiceNotTable(userID)
    if table_voice_not then
        table_voice_not[userID] = nil
    end
end

function isElementOfVoiceNotTable(userID)
    if table_voice_not and table_voice_not[userID] == true then
        return true
    end
    return false
end

function setLeaveEnable(enable)
    leave_enable = enable
end

function getLeaveEnable()
    return leave_enable
end

function setBasePosChair(chair)
    Base_Pos.l_chair = Base_Pos.chair
    Base_Pos.chair = chair
end

function getBasePosChair()
    return Base_Pos.chair
end

function setLastMutiply(mutitply)
    last_mutiply = mutitply
end


function getLastMutiply()
    return last_mutiply
end


function setBankerChair(chair)
    banker_chair = chair
end

function getBankerChair()
    return banker_chair
end

function getLastBasePosChair()
    return Base_Pos.l_chair
end

function getBasePosUserID()
    return Base_Pos.userID
end

function qz_common_user_info_To_qz1( user_info )
    if nil == user_info then
        return nil
    end
    local user_info_qz1 = {}
    user_info_qz1.userID    = user_info.dwUserID
    user_info_qz1.status    = user_info.status
    user_info_qz1.chair     = user_info.bDeskStation
    user_info_qz1.boy       = user_info.bBoy
    user_info_qz1.nick      = user_info.nickName
    user_info_qz1.avatarUrl = user_info.avatarUrl
    user_info_qz1.point     = user_info.dwMoney
    user_info_qz1.profit    = user_info.dwProfit
    user_info_qz1.dwUserIP  = user_info.dwUserIP
    return user_info_qz1
end

function getSelfPlayer()
    return qz_common_user_info_To_qz1( game_scene:getSelfInfo() )
end

function setGameScene( scene )
    game_scene = scene
end

function getGameScene()
    return game_scene
end

function getDeskConfig()
    return game_scene:getDeskInfo()
end

    --坐下的玩家
function getDeskPlayerMap()
    local desk_playerMap = game_scene:getSitDownPlayerMap()
    local ret = {}
    if desk_playerMap then
        for key , var in pairs( desk_playerMap ) do
            local var_qz1 = qz_common_user_info_To_qz1(var)
            table.insert( ret , var_qz1 )
        end
    end
    return ret
end

    --围观群众
function getViewerPlayerMap()
    local desk_playerMap = game_scene:getStandUpPlayerMap()
    local ret = {}
    if desk_playerMap then
        for key , var in pairs( desk_playerMap ) do
            local var_qz1 = qz_common_user_info_To_qz1(var)
            table.insert( ret , var_qz1 )
        end
    end
    return ret
end

function get_player_info_by_chairID( chairID )
    return qz_common_user_info_To_qz1( game_scene:getPlayerInfoByChairID( chairID ) )
end
    

function get_player_info_by_userID( userID )
    return qz_common_user_info_To_qz1( game_scene:getPlayerInfoByUserID( userID ) )
end

--endregion
