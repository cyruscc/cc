--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local GameShareLayer = import('.GameShareLayer')
local GameSelectLayer = import('.GameSelectLayer')
local RoomInforLayer = import('.RoomInforLayer')
local GameRecordLayer = import('.GameRecordLayer')
local GameFaceLayer = import('.GameFaceLayer')
local MyRoomLayer = import("....room.view2.room.MyRoomLayer")
local m_download = import("....common.download")

local BaseUIManager = class("BaseUIManager")

function BaseUIManager:ctor(ui_project, ui_root)
    

    self.ui_project = ui_project

    self.desk_config =  ViewHelp.getDeskConfig()

    self.Text_room_id = ui_project:getChildByName("Text_room_id")

    self.Text_room_id:setString(tostring(self.desk_config.roomKey))


    self.Text_base_bet = ui_project:getChildByName("Text_base_bet")
    self.Text_base_bet:setString(tostring(self.desk_config.config.antes))

    self.Text_current_board = ui_project:getChildByName("Text_current_board")
    self.Text_current_board:setString(tostring(self.desk_config.progress).."/"..tostring(self.desk_config.config.maxRounds))



            --房间描述
    local Text_ratio_0 = ui_project:getChildByName("Text_ratio_0")
    local Text_ratio_1 = ui_project:getChildByName("Text_ratio_1")
    local Text_ratio_2 = ui_project:getChildByName("Text_ratio_2")

    local desc_text_0 = ""
    local desc_text_1 = ""
    local desc_text_2 = ""
    local niu_table_text = {"无牛X", "牛丁X", "牛二X", "牛三X", "牛四X", "牛五X", "牛六X", "牛七X", "牛八X", "牛九X", "牛牛X", "炸弹X", "金牛X", "五小牛X"}
    for i=1, #niu_table_text do
        if i<=7 then
            desc_text_0 = desc_text_0..niu_table_text[i]..self.desk_config.config.bullPointBet[i].." "
        elseif i<=11 then
            desc_text_1 = desc_text_1..niu_table_text[i]..self.desk_config.config.bullPointBet[i].." "
        else
            desc_text_2 = desc_text_2..niu_table_text[i]..self.desk_config.config.bullPointBet[i].." "
        end

    end
    Text_ratio_0:setString(desc_text_0)
    Text_ratio_1:setString(desc_text_1)
    Text_ratio_2:setString(desc_text_2)
    Text_ratio_1:setPositionX(Text_ratio_0:getPositionX()+Text_ratio_0:getContentSize().width)
    Text_ratio_2:setPositionX(Text_ratio_1:getPositionX()+Text_ratio_1:getContentSize().width)

    self.Image_wait = ui_project:getChildByName("Image_wait")
    self.Button_start = ui_project:getChildByName("Button_start")
    self.Button_start:addClickEventListener(function()
        ViewHelp.getGameScene():reqStartDesk()
        self.Button_start:setVisible(false)
    end
    )
    if self.desk_config.mastUserID==ViewHelp.getBasePosUserID() then
        self.Image_wait:setVisible(false)
        if self.desk_config.activated then
           self.Button_start:setVisible(false)
        else
           self.Button_start:setVisible(true)
        end
    else
        self.Button_start:setVisible(false)
        if self.desk_config.activated then
           self.Image_wait:setVisible(false)
        else
           self.Image_wait:setVisible(true)
        end
    end

    --返回
    local Button_select = ui_project:getChildByName("Button_select")
    Button_select:addClickEventListener(function()
        ui_root:addChild(GameSelectLayer:create(Button_select))
    end
    )
    --房间信息
    local Button_room = ui_project:getChildByName("Button_room")
    Button_room:addClickEventListener(function()
        
        ui_root:addChild(RoomInforLayer:create(ui_root))
    end
    )

    --申请信息
    local Button_message = ui_project:getChildByName("Button_message")
    local Image_red = Button_message:getChildByName("Image_red")
    Button_message:addClickEventListener(function()
        Image_red:setVisible(false)
        ui_root:addChild(MyRoomLayer:create(2, ui_root, self.desk_config.gameID))
    end
    )
    Image_red:setVisible(false)
    if self.desk_config.mastUserID~=ViewHelp.getBasePosUserID() then
        Button_message:setVisible(false)
    end

    --游戏战绩
    local Button_record = ui_project:getChildByName("Button_record")
    Button_record:addClickEventListener(function()
        ui_root:addChild(GameRecordLayer:create(ui_root))
    end
    )

    --微信邀请
    local Button_invite = ui_project:getChildByName("Button_invite")
    Button_invite:addClickEventListener(function()
        --ui_root:addChild(GameShareLayer:create())
        lua_to_plat:wx_share_to_session( "招脚来斗牛" , "我在私人房间里玩牛牛，房号："..tostring(ViewHelp.getDeskConfig().roomKey).."。人多热闹，都来一起玩吧！" , get_download_url(), function (args)
            local table_value = lua_to_plat:get_ret_table(args)
            if table_value.ret == 1 then
                print("分享至微信会话窗口成功！")
            else
                print("分享至微信会话窗口失败！")
            end           
        end)
    end
    )
    --发表情
    self.Button_face = ui_project:getChildByName("Button_face")
    self.Button_face:addClickEventListener(function()
        ui_root:addChild(GameFaceLayer:create())
    end
    )

    --录音
    self.Button_recorder = ui_project:getChildByName("Button_recorder")

    local function recorder_start_call_back(ret_table)
        dump( ret_table )
        if ret_table["ret"]==1 then
            self.recorder_start = true
        else
            self.recorder_start = false
        end
    end
    local function recorder_stop_call_back(ret_table)
        --print( "recorder_stop_call_back---------" , json.decode( ret_table ))
        --local ret_table = lua_to_plat:get_ret_table(args)
        dump( ret_table )
        if ret_table.ret == 1 and self.recorder_start then
            print("recorder----------------ok")
            print(tostring(ret_table["filePath"]))
            print(tostring(ret_table["fileName"]))
            ViewHelp.getGameScene():reqRecordSound(tostring(ret_table["fileName"]), os.time()-self.cur_time)
        else
            print("recorder----------------faild")
        end
    end
    self.isRecorder = false
    self.cur_time = 0
    self.recorder_time = 0
    self.Button_recorder:addTouchEventListener(function(sender, eventType)
        if eventType == ccui.TouchEventType.began then
           if (os.time()-self.cur_time)<1 then
              print("You do to frequency")
              return
           end
           self.cur_time = os.time()
           self.isRecorder = true
           ui_root:getRecorderUIManager():start_recorder(function ()
               self.isRecorder = false
               lua_to_plat:recorder_stop(true, recorder_stop_call_back)
           end)
           Music:pauseMusic()
           Music:pauseEffect()
           lua_to_plat:recorder_start(tostring(ViewHelp.getBasePosUserID()).."_"..tostring(os.time()), recorder_start_call_back)

        elseif eventType == ccui.TouchEventType.moved then
            
        elseif eventType == ccui.TouchEventType.ended then

            if self.isRecorder then
                ui_root:getRecorderUIManager():stop_recorder()
                if (os.time()-self.cur_time)>=1 then
                   lua_to_plat:recorder_stop(true, recorder_stop_call_back)
                else
                   lua_to_plat:recorder_stop(false, recorder_stop_call_back)
                end
                self.isRecorder = false
            end
            Music:resumeMusic()
            Music:resumeEffect()
        elseif eventType == ccui.TouchEventType.canceled then

            if self.isRecorder then

               ui_root:getRecorderUIManager():stop_recorder()
               lua_to_plat:recorder_stop(false, recorder_stop_call_back)
               self.isRecorder = false
            end
            Music:resumeMusic()
            Music:resumeEffect()
        end

    end)


    if ViewHelp.getSelfPlayer().chair>=0 then
        self:selfSitDown()
    else
        self:selfStandUp()
    end

    self.Panel_chat = ui_project:getChildByName("Panel_chat")
    self.table_ui_chat = {}
    local Panel_chat_itm = self.Panel_chat:getChildByName("Panel_chat_itm")
    self.ui_chat_cln = Panel_chat_itm:clone()
    self.ui_chat_cln:retain()
    Panel_chat_itm:removeFromParent()

end

    --游戏开始
function BaseUIManager:game_start(resp_table)
    
   self.Text_current_board:setString(resp_table.CurRounds.."/"..resp_table.MaxRounds)

end


function BaseUIManager:chat_enable_notity( hcode , user_info)

    if ViewHelp.getSelfPlayer().chair>=0 then
        self:selfSitDown()
    else
        self:selfStandUp()
    end
end

--有玩家录音
function BaseUIManager:player_recorder( user_info , recordInfo)
    if not user_info or user_info.chair>=0 then
       return
    end

    local ui_chat = self.ui_chat_cln:clone()
    self.Panel_chat:addChild(ui_chat)
    self:insertUIChat(ui_chat)
    self:setUIChatPositionAdjust()

    local Image_head = ui_chat:getChildByName("Image_head")
    m_download:get_instance():set_head_image_and_auto_update(Image_head,  user_info.avatarUrl, user_info.userID, 'setUIPlayer')

    local Image_chat = ui_chat:getChildByName("Image_chat")
    Image_chat:setTouchEnabled(true)
    Image_chat:addTouchEventListener(function()
        
        lua_to_plat:playRecorder(recordInfo.voiceID)
        Image_chat:setTouchEnabled(false)
    end)
    ui_chat:runAction(cc.Sequence:create(cc.DelayTime:create(recordInfo.duration),
    cc.CallFunc:create(function()
     self:removeUIChat(ui_chat)
     self:setUIChatPositionAdjust()
     end)
    ))
    local Text_time = Image_chat:getChildByName("Text_time")
    Text_time:setString(tostring(recordInfo.duration).."'")

    if UserData:getAutoPlaySound()==1 then

        lua_to_plat:playRecorder(recordInfo.voiceID)
        Image_chat:setTouchEnabled(false)
    end

end

function BaseUIManager:insertUIChat(ui_chat)
    table.insert(self.table_ui_chat, 1, ui_chat)
    if #self.table_ui_chat>=3 then
       self.table_ui_chat[3]:removeFromParent()
       table.remove(self.table_ui_chat, 3)
    end
end

function BaseUIManager:removeUIChat(ui_chat)
    for i=1,  #self.table_ui_chat do
       if self.table_ui_chat[i]==ui_chat then
          table.remove(self.table_ui_chat, i)
          ui_chat:removeFromParent()
          break
       end
    end
end

function BaseUIManager:setUIChatPositionAdjust()
    for i=1,  #self.table_ui_chat do
       self.table_ui_chat[i]:setPositionY(60*(i-1))
    end
end

function BaseUIManager:getAvailableUIChat()
    for i=1, #self.table_ui_chat do
       if self.table_ui_chat[i]:isVisible()==false then
          return self.table_ui_chat[i]
       end
    end
    return self.table_ui_chat[1]
end

function BaseUIManager:deskStart(user_info)
    self.Image_wait:setVisible(false)
    self.Button_start:setVisible(false)
end

function BaseUIManager:selfSitDown()
    self.Button_recorder:setPositionY(181.83)
    self.Button_face:setVisible(true)
    if ViewHelp.getDeskConfig().allowChat then
        self.Button_recorder:setVisible(true)
        self.Button_face:setPositionX(122.22)
    else
        self.Button_recorder:setVisible(false)
        self.Button_face:setPositionX(45.35)
    end
end

function BaseUIManager:selfStandUp()
    self.Button_recorder:setPositionY(63.79)
    self.Button_face:setVisible(false)
    if ViewHelp.getDeskConfig().allowChat then
        self.Button_recorder:setVisible(true)
        self.Button_face:setPositionX(45.35)
    else
        self.Button_recorder:setVisible(false)
        self.Button_face:setPositionX(122.22)
    end
end


function BaseUIManager:new_applyinfo_notify()
    local Button_message = self.ui_project:getChildByName("Button_message")
    local Image_red = Button_message:getChildByName("Image_red")
    Image_red:setVisible(true)
end

return BaseUIManager

--endregion
