--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local GameSceneModule = import('..GameSceneModule')
local AdjustLabel = import("....ui.AdjustLabel")

local m_download = import("....common.download")

local GamePersonalLayer = import(".GamePersonalLayer")

local PlayerUIManager = class("PlayerUIManager")


function PlayerUIManager:ctor(ui_project, ui_root)

    self.ui_project = ui_project
    self.ui_root = ui_root
    self.table_ui_player = {}
    for i=1,  5 do
        local ui_player = ui_project:getChildByName("Panel_player_"..(i-1))
        self:setUIPlayer(ui_player)
        self.table_ui_player[i] = ui_player
    end

    if tonumber(ViewHelp.getSelfPlayer().chair)>=0 then
        ViewHelp.setBasePosChair(tonumber(ViewHelp.getSelfPlayer().chair))
    end
    self:setDeskUIPlayer()
    self:setSeatButton()
    if tonumber(ViewHelp.getSelfPlayer().chair)>=0 then
       self:hideAllSeatButton()
    end
end

    --隐藏所有座位按钮
function PlayerUIManager:hideAllSeatButton()
    for i=1, #self.table_ui_player do
        self:setUIPlayerChildEnable(self.table_ui_player[i], nil, "Button_seat_down", false)
    end
end

    --设置座位对应的chair
function PlayerUIManager:setSeatButton()

    for i=1, #self.table_ui_player do
       local ui_player = self.table_ui_player[i]
       local Button_seat_down = ui_player:getChildByName("Button_seat_down")
       local chair = -1
       if ViewHelp.getBasePosChair()<0 then
            chair = i-1
       else
            chair = (ViewHelp.getBasePosChair()+(i-1))%5
       end
       Button_seat_down:addClickEventListener(function()
          if ViewHelp.getSelfPlayer().chair>=0 then
             return
          end
          local max = 0
          for key, var in pairs(ViewHelp.getDeskConfig().config.bullPointBet) do
             if var>max then
                max = var
             end
          end
          if ViewHelp.getDeskConfig().config.antes*4*max>ViewHelp.getSelfPlayer().point then
             self.ui_root:pointLease()
             return
          end
          ViewHelp.getGameScene():reqSitdownDesk(chair, false)
       end
        )
    end
end

    --设置桌子上已经坐下的玩家的信息
function PlayerUIManager:setDeskUIPlayer()
    for i=1, #self.table_ui_player do
        local ui_player = self.table_ui_player[i]
        self:setUIPlayer(ui_player)
    end
    for key, value in pairs(ViewHelp.getDeskPlayerMap()) do
        local ui_player = self:getUIPlayer(tonumber(value.chair))
        if ui_player~=nil then
            self:setUIPlayer(ui_player, value)
        end
    end 
end

    --获取UIPlayer
function PlayerUIManager:getUIPlayer(chair, last_state)
    return ViewHelp.getUIObject(chair, self.table_ui_player, last_state)
end

    --位置信息初始化
function PlayerUIManager:setUIPlayer(ui_player, desk_player)

    self.desk_player = clone( desk_player )
    if not ui_player then
       return
    end

    local Button_seat_down = ui_player:getChildByName("Button_seat_down")
    local Image_seat_bg = ui_player:getChildByName("Image_seat_bg")

    local Image_line = Image_seat_bg:getChildByName("Image_line")
    Image_line:stopAllActions()
    Image_line:setVisible(false)

    local Panel_face = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Panel_face")
    Panel_face:removeAllChildren()
    Panel_face:setVisible(false)

    local Image_point_bg = Image_seat_bg:getChildByName("Image_point_bg")
    Image_point_bg:setVisible(false)

    local Image_recorder = Image_seat_bg:getChildByName("Image_recorder")
    Image_recorder:stopAllActions()
    Image_recorder:setVisible(false)
    local Image_ok = Image_seat_bg:getChildByName("Image_ok")
    Image_ok:setVisible(false)

    local Image_face = Image_seat_bg:getChildByName("Image_face")
    Image_face:setVisible(false)
    Image_face:removeAllChildren()

    local Image_ratio = Image_seat_bg:getChildByName("Image_ratio")
    Image_ratio:setTag(0)
    Image_ratio:setVisible(false)

    if not self.desk_player or self.desk_player.chair<0 then
        Button_seat_down:setVisible(true)
        Image_seat_bg:setVisible(false)
        return
    end
    Button_seat_down:setVisible(false)
    Image_seat_bg:setVisible(true)

--    if Image_seat_bg:getChildByTag(1)~=nil then
--       Image_seat_bg:getChildByTag(1):removeFromParent()
--    end
    if ui_player==self.table_ui_player[1] then
        if tonumber(self.desk_player.userID)==ViewHelp.getBasePosUserID() then
            Image_seat_bg:setPosition(cc.p(135.5, 63.79))
            Image_ok:setPosition(626.5, 177.18)
            Image_point_bg:setPosition(cc.p(195, 135))
            self.ui_root:getBaseUIManager():selfSitDown()
        else
            Image_seat_bg:setPosition(cc.p(640, 72.79))
            Image_ok:setPosition(148, 186.18)
            Image_point_bg:setPosition(cc.p(120, 122))
        end
    end


    local Image_head = Image_seat_bg:getChildByName("Image_head")
    Image_head:loadTexture("game_res/90010500/com/head_0.png")

    m_download:get_instance():set_head_image_and_auto_update(Image_head,  self.desk_player.avatarUrl, self.desk_player.userID, 'setUIPlayer')
    
    Image_head:setTouchEnabled(true)

    Image_head:addClickEventListener(function()
       self.ui_root:addChild(GamePersonalLayer:create(desk_player, self.ui_root))
    end)



    local Text_name = Image_seat_bg:getChildByName("Text_name")
    Text_name:setString(tostring(self.desk_player.nick))
    if Text_name:getContentSize().width>75 then
        local AdjustLabel = AdjustLabel:create(tostring(self.desk_player.nick), 75, Text_name:getContentSize().height, Text_name:getFontSize())
        Text_name:setString(AdjustLabel:getDesText().."...")
    end

    local Text_point = Image_seat_bg:getChildByName("Text_point")
    Text_point:setString(tostring(self.desk_player.point))

    local Image_banker = Image_seat_bg:getChildByName("Image_banker")
    Image_banker:setVisible(false)


end


    --设置座位游戏状态
function PlayerUIManager:setUIPlayerGameState(table_game_state)

    for key,var in pairs(table_game_state) do

        local ui_player = self:getUIPlayer(key)

        local Image_ok = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_ok")
        Image_ok:setVisible(var.enable_ok)

        local Image_ratio = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_ratio")
        Image_ratio:setVisible(var.enable_ratio)
        if ViewHelp.getDeskConfig().config.NoteType==1 then
            local Image_point_bg = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_point_bg")
            Image_point_bg:setVisible(var.enable_point_bg)
            local Text_point = Image_point_bg:getChildByName("Text_point")
            Text_point:setString(var.Text_point)
        else
            local Image_ratio = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_ratio")
            Image_ratio:setVisible(var.enable_ratio)
            Image_ratio:loadTexture("game_res/90010500/gameScene/game_x_"..tostring(var.enable_ratio_tag-1)..".png")
            Image_ratio:setTag(var.enable_ratio_tag)
        end


        local Image_face = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_face")
        Image_face:setVisible(false)

        local Image_recorder = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_recorder")
        Image_recorder:setVisible(false)


    end
    
end

        --获取UIPlayer上的UI节点
function PlayerUIManager:getUIPlayerChild(ui_player, ui_name_parent, ui_name_child)

   if not ui_player then
      return nil
   end
   if not ui_name_parent then
      return ui_player:getChildByName(ui_name_child)
   end
   local ui_parent = ui_player:getChildByName(ui_name_parent)
   local ui_child = ui_parent:getChildByName(ui_name_child)
   return ui_child
end

        --根据chair设置UIPlayer位置上节点是否可见
function PlayerUIManager:setChildEnableByChair(chair, ui_name_parent, ui_name_child, enable)
    local ui_player = self:getUIPlayer(chair)
    if not ui_player then
       return
    end
    return self:setUIPlayerChildEnable(ui_player, ui_name_parent, ui_name_child, enable)
end

        --设置UIPlayer位置上节点是否可见
function PlayerUIManager:setUIPlayerChildEnable(ui_player, ui_name_parent, ui_name_child, enable)
    if not ui_player then
       return nil
    end
    local Image_child = self:getUIPlayerChild(ui_player, ui_name_parent, ui_name_child)
    if not Image_child then
       return nil
    end
    Image_child:setVisible(enable)
    return Image_child
end

        --游戏结算清理
function PlayerUIManager:game_end_clear(resp_table)
 
   for key, var in pairs(resp_table) do
        self:setUIPlayerChildEnable(self:getUIPlayer(key), "Image_seat_bg", "Image_banker", false)
        self:setUIPlayerChildEnable(self:getUIPlayer(key), "Image_seat_bg", "Image_line", false)
        if ViewHelp.getDeskConfig().config.NoteType==1 then
            self:setUIPlayerChildEnable(self:getUIPlayer(key), "Image_seat_bg", "Image_point_bg", false)
        else
            local Image_ratio = self:setUIPlayerChildEnable(self:getUIPlayer(key), "Image_seat_bg", "Image_ratio", false)
            Image_ratio:setTag(0)
        end
   end

end

-----------------------------------游戏消息处理-------------------------------------------
    --玩家准备
function PlayerUIManager:player_ready(resp_table)

   self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_ok", true)

end

    --游戏开始
function PlayerUIManager:game_start(resp_table)
    dump( resp_table )
    for i=1, #resp_table.playerData do
       self:setUIPlayerChildEnable(self:getUIPlayer(resp_table.playerData[i].chair), "Image_seat_bg", "Image_ok", false)
       if resp_table.playerData[i].chair==ViewHelp.getSelfPlayer().chair then
          ViewHelp.setLeaveEnable(false)
       end

    end

end
    --叫庄结束
function PlayerUIManager:game_banker_end(resp_table, animate)
    local table_tips = {}
    table_tips[1] = "首次随机选择庄家"
    table_tips[4] = "庄家离开，随机选择庄家"
    if resp_table.iTipFlag==2 then
        table_tips[2] = "\""..ViewHelp.get_player_info_by_chairID(resp_table.chair).nick.."\"继续当庄"
    end
    if resp_table.iTipFlag==3 then
        table_tips[3] = "\""..ViewHelp.get_player_info_by_chairID(resp_table.chair).nick.."\"拿到牛牛，成为庄家"
    end
    
    api_show_tips(table_tips[resp_table.iTipFlag])
    if animate then
 
        local function playBankerAnimate()  -- 播放 庄家位置上的 庄家动画
            local ui_player = self:getUIPlayer(resp_table.chair)
            local animate_path = ""
            if ui_player==self.table_ui_player[1] then
                animate_path = "game_res/90010500/armature/XZ/XZ_0.csb"
            elseif ui_player==self.table_ui_player[2] or  ui_player==self.table_ui_player[5] then
                animate_path = "game_res/90010500/armature/XZ/XZ_1.csb"
            else
                animate_path = "game_res/90010500/armature/XZ/XZ_2.csb"
            end
            local Image_seat_bg = self:getUIPlayerChild(ui_player, nil, "Image_seat_bg")
            local Image_banker = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_banker")
            self.ui_root:playGameAnimate(animate_path,
            ui_player,
            {x=Image_seat_bg:getPositionX(), y=Image_seat_bg:getPositionY()},
            function()
                self.ui_root:playGameAnimate("game_res/90010500/armature/XZ/XZ_B.csb",
                Image_seat_bg,
                {x=Image_banker:getPositionX(), y=Image_banker:getPositionY()},
                function()
                    self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_banker", true) 
                    self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_line", true)
                end)
            end)
        end

        local function playRandomSelectBankerAnimate()  -- 播放随机选择庄家的 选择光效 动画
            local _temp_table = {}
            for i=1, #resp_table.players do
               _temp_table[i] = resp_table.players[i]
            end
            local temp_table = {}
            local size = #_temp_table
            for i=1, size do
               local r_idx = math.random(1, #_temp_table)
               temp_table[i] = _temp_table[r_idx]
               table.remove(_temp_table, r_idx)
            end
            local function blinkAnimate(index)
               local Image_line = self:getUIPlayerChild(self:getUIPlayer(temp_table[index]), "Image_seat_bg", "Image_line")
               Image_line:setVisible(true)
               Image_line:runAction(cc.Sequence:create(cc.Blink:create(0.5, 2),
               cc.CallFunc:create(function()
                    Image_line:setVisible(false)
                    if index<#temp_table then
                       index = index+1
                       blinkAnimate(index)
                    else
                       playBankerAnimate()
                    end
               end)))
            end
            if #temp_table>1 then
               blinkAnimate(1)
            end
        end
        if resp_table.iTipFlag == 1 or resp_table.iTipFlag == 4 and resp_table.players then
            -- 播放随机选择庄家动画
            playRandomSelectBankerAnimate()
        else
            playBankerAnimate()
        end
    else
       self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_banker", true)
       self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_line", true)
    end
end
--    --随机庄家
--function PlayerUIManager:game_banker_rand(resp_table, animate)
--    local table_tips = {"首次随机选择庄家", "庄家离开，随机选择庄家"}
--    if resp_table.iTipFlag==2 then
--        table_tips[3] = "\""..ViewHelp.get_player_info_by_chairID(resp_table.chair).nick.."\"继续当庄"
--    end
--    if resp_table.iTipFlag==3 then
--        table_tips[4] = "\""..ViewHelp.get_player_info_by_chairID(resp_table.chair).nick.."\"拿到牛牛，成为庄家"
--    end
--    Msg:showTips(table_tips[resp_table.iTipFlag+1])
--    if animate then
--        if resp_table.iTipFlag==0 or resp_table.iTipFlag==1 then
--                dump(resp_table)

--        else
--            self:game_banker_end(resp_table, animate)
--        end
--    else
--        self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_banker", true) 
--        self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_line", true) 
--    end
--end

    --玩家下注
function PlayerUIManager:player_bet(resp_table)

    if ViewHelp.getDeskConfig().config.NoteType==1 then
       local Image_point_bg = self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_point_bg", true)
       Image_point_bg:getChildByName("Text_point"):setString(tostring(resp_table.multiplying))
       return
    end
    local Image_ratio = self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_ratio", true)
    if resp_table.multiplying and resp_table.multiplying>0 and resp_table.multiplying<5 then
       Image_ratio:loadTexture("game_res/90010500/gameScene/game_x_"..tostring(resp_table.multiplying-1)..".png")
       Image_ratio:setTag(resp_table.multiplying)
    end
end

    --游戏结算
function PlayerUIManager:game_end(resp_table)

   for key, var in pairs(resp_table) do
        local ui_player = self:getUIPlayer(key)
        if ui_player then
            local Text_point = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Text_point")
            Text_point:setString(tostring(var.iTotalPoint))
        end
   end
end


-------------------------------------------------------end--------------------------------------------


--------------------------------------游戏玩家状态恢复-----------------------------------
    --准备状态恢复
function PlayerUIManager:game_rebind_ready(resp_table)
    if not resp_table.table_bAgree then
       return
    end
    for key, var in pairs(resp_table.table_bAgree) do
        if var==true then
           self:setChildEnableByChair(key, "Image_seat_bg", "Image_ok", true)
        else
            if key==ViewHelp.getSelfPlayer().chair then
               self.ui_root:getCallUIManager():game_ready()
            end
        end
    end
    
end

    --叫庄恢复
function PlayerUIManager:game_rebind_banker(resp_table)

    if resp_table.bankerType==0 then
       if resp_table.chair and resp_table.chair==ViewHelp.getSelfPlayer().chair then
          self.ui_root:getCallUIManager():game_banker_notify(resp_table)
       end
    end
    if resp_table.bankerType==1 then
        ViewHelp.setBankerChair(resp_table.chair)
        self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_banker", true)
        self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_line", true) 
    end
end

    --下注恢复
function PlayerUIManager:game_rebind_bet(resp_table)
    ViewHelp.setBankerChair(resp_table.chair)
    self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_banker", true)
    self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_line", true) 
    for i=1, #resp_table.table_playerData do
       local _playerData = resp_table.table_playerData[i]
       if _playerData.bIsDo==true then
          if ViewHelp.getDeskConfig().config.NoteType==1 then
              local Image_point_bg = self:setChildEnableByChair(_playerData.chair, "Image_seat_bg", "Image_point_bg", true)
              Image_point_bg:getChildByName("Text_point"):setString(tostring(_playerData.multiplying))
          else
              local Image_ratio = self:setChildEnableByChair(_playerData.chair, "Image_seat_bg", "Image_ratio", true)
              if _playerData.multiplying and _playerData.multiplying>0 and multiplying.multiplying<5 then
                 Image_ratio:loadTexture("game_res/90010500/gameScene/game_x_"..tostring(_playerData.multiplying-1)..".png")
                 Image_ratio:setTag(_playerData.multiplying)
              end
          end
       else
            if _playerData.chair==ViewHelp.getSelfPlayer() then
               local table_bet_notify = {}
               table_bet_notify.betTime = resp_table.iLeaverTime
               local betItems = {}
               local _betItems = {}
               _betItems.chair = _playerData.chair
               _betItems.multiply = _playerData.maxMultiply
               _betItems.note = _playerData.note
               betItems[1] = _betItems
               table_bet_notify.betItems = betItems
               self.ui_root:getCallUIManager():game_bet_notify(table_bet_notify)
            end
       end       
    end
    
end

    --发牌恢复
function PlayerUIManager:game_rebind_card_send(resp_table)

    self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_banker", true)
    self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_line", true) 
    ViewHelp.setBankerChair(resp_table.chair)
    local table_card = {}
    for i=1, #resp_table.table_playerData do
       local _playerData = resp_table.table_playerData[i]
       if resp_table.chair~=_playerData.chair then
          if ViewHelp.getDeskConfig().config.NoteType==1 then
              local Image_point_bg = self:setChildEnableByChair(_playerData.chair, "Image_seat_bg", "Image_point_bg", true)
              Image_point_bg:getChildByName("Text_point"):setString(tostring(_playerData.multiplying))
          else
              local Image_ratio = self:setChildEnableByChair(_playerData.chair, "Image_seat_bg", "Image_ratio", true)
              Image_ratio:loadTexture("game_res/90010500/gameScene/game_x_"..tostring(_playerData.multiplying-1)..".png")
              Image_ratio:setTag(_playerData.multiplying)
          end
       end
       table_card[_playerData.chair] = _playerData.table_card
    end
    self.ui_root:getCardUIManager():game_card_send(table_card)  
end

    --开牌恢复
function PlayerUIManager:game_rebind_card_open(resp_table)

    self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_banker", true)
    self:setChildEnableByChair(resp_table.chair, "Image_seat_bg", "Image_line", true) 
    ViewHelp.setBankerChair(resp_table.chair)
    local card_send_data = {}
    local card_open_data = {}
    for i=1, #resp_table.table_playerData do
       local _playerData = resp_table.table_playerData[i]
       if resp_table.chair~=_playerData.chair then
          if ViewHelp.getDeskConfig().config.NoteType==1 then
              local Image_point_bg = self:setChildEnableByChair(_playerData.chair, "Image_seat_bg", "Image_point_bg", true)
              Image_point_bg:getChildByName("Text_point"):setString(tostring(_playerData.multiplying))
          else
              local Image_ratio = self:setChildEnableByChair(_playerData.chair, "Image_seat_bg", "Image_ratio", true)
              Image_ratio:loadTexture("game_res/90010500/gameScene/game_x_"..tostring(_playerData.multiplying-1)..".png")
              Image_ratio:setTag(_playerData.multiplying)
          end
       end
       card_send_data[_playerData.chair] = _playerData.table_card
       if _playerData.bIsDo then
           table.insert(card_open_data, #card_open_data+1, _playerData.chair)
       else
           if _playerData.chair==ViewHelp.getSelfPlayer().chair then
              self.ui_root:getCardUIManager():game_card_open()
           end
       end
       self.ui_root:getCardUIManager():game_card_send(card_send_data)
       for i=1, #card_open_data do
          self.ui_root:getCardUIManager():player_card_open({chair=card_open_data[i]})
       end
       
    end
end
-------------------------------------------------------end--------------------------------------------


-----------------------------------平台处理-------------------------------------------
-- 有玩家坐下
function PlayerUIManager:playerSitDesk( user_info )

    if ViewHelp.getBasePosUserID()==tonumber(user_info.userID) then
        local table_game_state = {}
        for key, value in pairs(ViewHelp.getDeskPlayerMap()) do
            if key~=tonumber(user_info.chair) then
                local ui_player = self:getUIPlayer(tonumber(value.chair), true)
                local game_state = {}
                local Image_ok = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_ok")
                game_state.enable_ok = Image_ok:isVisible()
                if ViewHelp.getDeskConfig().config.NoteType==1 then
                    local Image_point_bg = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_point_bg")
                    game_state.enable_point_bg = Image_point_bg:isVisible()
                    local Text_point = Image_point_bg:getChildByName("Text_point")
                    game_state.Text_point = Text_point:getString()
                else
                    local Image_ratio = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_ratio")
                    game_state.enable_ratio = Image_ratio:isVisible()
                    game_state.enable_ratio_tag = Image_ratio:getTag()
                end
                table_game_state[key] = game_state
            end
        end 
        self.ui_root:getAnimatePanel():removeAllChildren()
        self:setDeskUIPlayer()
        self:setSeatButton()
        self:hideAllSeatButton()
        self:setUIPlayerGameState(table_game_state)
        if ViewHelp.getBankerChair() >=0 then
           self:game_banker_end({chair=ViewHelp.getBankerChair()})
        end
        self.ui_root:getBaseUIManager():selfSitDown()
        if UserData:getAutoAgree()==1 then
           --GameSceneModule:request_player_ready()
        else
           self.ui_root:getCallUIManager():game_ready() 
        end
    else
        self:setUIPlayer(self:getUIPlayer(tonumber(user_info.chair)), user_info)
    end

end

-- 有玩家站起
function PlayerUIManager:playerStandUp( user_info )
    
    self:setUIPlayer(self:getUIPlayer(user_info.chair))
    if ViewHelp.getBasePosUserID()==tonumber(user_info.userID) then
        self.ui_root:getBaseUIManager():selfStandUp()
        for i=1, #self.table_ui_player do
            local Image_seat_bg = self:getUIPlayerChild(self.table_ui_player[i], nil, "Image_seat_bg")
            if Image_seat_bg:isVisible()==false then
               self:setUIPlayerChildEnable(self.table_ui_player[i], nil, "Button_seat_down", true)
            end
        end
    else
        if ViewHelp.getSelfPlayer().chair>=0 then
           self:setUIPlayerChildEnable(self:getUIPlayer(user_info.chair), nil, "Button_seat_down", false)
        end
    end
   
end

-- 有玩家发表情
function PlayerUIManager:player_chat( user_info  , chatInfo)

   local ui_player = self:getUIPlayer(user_info.chair)
   local Panel_face = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Panel_face")
   Panel_face:setVisible(true)
   Panel_face:removeAllChildren()
   --local Image_face = self:getUIPlayerChild(ui_player, "Image_seat_bg", "Image_face")
   local res = "game_res/90010500/armature/chat_animate/ChatNode_"..((chatInfo-1)%15)..".csb"
   local game_armature = cc.CSLoader:createNode( res )
   local action = cc.CSLoader:createTimeline(res)
   action:gotoFrameAndPlay(0,false)
   game_armature:runAction(action)
   action:setLastFrameCallFunc(function()
        game_armature:removeFromParent()
        Panel_face:setVisible(false)
   end)
   game_armature:setScale(0.8)
   game_armature:setPosition(44.5, 44.5)
   Panel_face:addChild(game_armature)
end

--有玩家托管
function PlayerUIManager:player_trusteeship( hcode , user_info )
    
end


--有玩家录音
function PlayerUIManager:player_recorder( user_info  , recordInfo)

    local player = ViewHelp.get_player_info_by_userID(user_info.userID)
    if not player or player.chair<0 then
       return
    end
    local Image_recorder = self:getUIPlayerChild(self:getUIPlayer(player.chair), "Image_seat_bg", "Image_recorder")
    Image_recorder:setVisible(true)
    Image_recorder:setTouchEnabled(true)
    Image_recorder:stopAllActions()
    Image_recorder:addTouchEventListener(function()
        
        lua_to_plat:playRecorder(recordInfo.voiceID)
        Image_recorder:setTouchEnabled(false)
    end)
    Image_recorder:runAction(cc.Sequence:create(cc.DelayTime:create(recordInfo.duration),
    cc.CallFunc:create(function()
     Image_recorder:setVisible(false)
     end)
    ))
    local Text_time = Image_recorder:getChildByName("Text_time")
    Text_time:setString(tostring(recordInfo.duration).."'")
    
    if UserData:getAutoPlaySound()==1 then

        lua_to_plat:playRecorder(recordInfo.voiceID)
        Image_recorder:setTouchEnabled(false)
    end
end

--玩家加分
function PlayerUIManager:add_point_notity(  user_info , add_point)
    dump( user_info )
    if self.desk_player and self.desk_player.userID == user_info.userID then
        self.desk_player.point = user_info.point
    end    
    if user_info.chair>=0 then

        self:getUIPlayerChild(self:getUIPlayer(user_info.chair), "Image_seat_bg", "Text_point"):setString(tostring(user_info.point)) 
    end

end


----玩家加分
--function PlayerUIManager:add_point_notity( hcode , user_info )


--    local player = ViewHelp.getRoomManager():get_player_info_by_userID(user_info.targetUserID)
--    player.point = player.point+user_info.addPoints
--    if player.chair>=0 then


--        self:getUIPlayerChild(self:getUIPlayer(player.chair), "Image_seat_bg", "Text_point"):setString(tostring(player.point)) 
--    end


--end

-------------------------------------------------------end--------------------------------------------


return PlayerUIManager

--endregion
