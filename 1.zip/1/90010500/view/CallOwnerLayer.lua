--region *.lua
--Date
--此文件由[BabeLua]插件自动生成



--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local SliderNode = import('.SliderNode')

local CallOwnerLayer = class("CallOwnerLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/CallOwnerLayer.csb")
end)

function CallOwnerLayer:ctor()

    self.point = 0

    local Panel_root = self:getChildByName("Panel_root")
    self.Image_root = Panel_root:getChildByName("Image_root")
    api_action_showPageLayer( self.Image_root )
    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end
    )

    local Button_send = self.Image_root:getChildByName("Button_send")
    Button_send:addClickEventListener(function()
        ViewHelp.getGameScene():reqApplyAddPointByMaster(self.point, self.TextField:getText())
        self:removeFromParent()
    end
    )

    local Text_min = self.Image_root:getChildByName("Text_min")

    local Text_max = self.Image_root:getChildByName("Text_max")

    local Image_input = self.Image_root:getChildByName("Image_input")
    local TextField = Image_input:getChildByName("TextField")
    self.TextField = MyEditBox:TextFiled_to_EditBox(TextField)
    TextField:setMaxLength(30)

    self.LoadingBar = self.Image_root:getChildByName("LoadingBar")

    self.Image_root:addChild(SliderNode:create(handler(self, self.sliderDelegate), 0, 10000))

    self:registerScriptHandler(handler(self,self.onNodeEvent))

    self:sliderDelegate(0, 0)

end

function CallOwnerLayer:sliderDelegate(percent, number)

    self.LoadingBar:setPercent(percent*100)
    self.TextField:setText("我要上"..tostring(number).."分")
    self.point = number
end

function CallOwnerLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end

function CallOwnerLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
    elseif event == "exit" then
        g_popBombBox(self)
    end

end

return CallOwnerLayer



--endregion




--endregion
