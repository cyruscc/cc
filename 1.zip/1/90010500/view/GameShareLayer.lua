--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameShareLayer = class("GameShareLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/GameShareLayer.csb")
end)

function GameShareLayer:ctor()

    local Panel_root = self:getChildByName("Panel_root")

    self.Image_root = Panel_root:getChildByName("Image_root")
    api_action_showPageLayer( self.Image_root )
    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end)

        --分享会话
    local Button_share_session = self.Image_root:getChildByName("Button_share_session")
    Button_share_session:addClickEventListener(function()

        lua_to_plat:wx_share_to_session( "招脚来斗牛" , "我在私人房间里玩牛牛，房号："..tostring(ViewHelp.getDeskConfig().roomKey).."。人多热闹，都来一起玩吧！" , get_download_url(), function (args)
            local table_value = lua_to_plat:get_ret_table(args)
            if table_value.ret == 1 then
                print("分享至微信会话窗口成功！")
            else
                print("分享至微信会话窗口失败！")
            end
           
        end)
    end)
            --分享朋友圈
    local Button_share_timeline = self.Image_root:getChildByName("Button_share_timeline")
    Button_share_timeline:addClickEventListener(function()

        lua_to_plat:wx_share_to_timeline("我在私人房间里玩牛牛，房号："..tostring(ViewHelp.getDeskConfig().roomKey).."。人多热闹，都来一起玩吧！" , get_download_url() , function (args)
            local table_value = lua_to_plat:get_ret_table(args)
            if table_value.ret == 1 then
                print("分享朋友圈窗口成功！")
            else
                print("分享朋友圈窗口失败！")
            end
           
        end)
    end)


    self:registerScriptHandler(handler(self,self.onNodeEvent))

end

function GameShareLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end

function GameShareLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
    elseif event == "exit" then
        g_popBombBox(self)
    end

end


return GameShareLayer



--endregion


