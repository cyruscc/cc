--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local TimerUIManager = class("TimerUIManager")

function TimerUIManager:ctor(ui_project)

    self.ui_project = ui_project
    self.Text_tip = ui_project:getChildByName("Text_tip")
    self.Text_tip:setString("")
    self.Image_timer_bg = ui_project:getChildByName("Image_timer_bg")

    local Sprite = cc.Sprite:create("game_res/90010500/gameScene/game_clock_1.png")
    self.ProgressTimer = cc.ProgressTimer:create(Sprite)
    self.ProgressTimer:setPosition(self.Image_timer_bg:getPositionX(), self.Image_timer_bg:getPositionY())
    ui_project:addChild(self.ProgressTimer)
    self.ProgressTimer:setPercentage(100)
    self.ProgressTimer:setMidpoint(cc.p(0.5, 0.5))
    self.ProgressTimer:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
    self.ProgressTimer:setRotationSkewY(180)

    self.AtlasLabel = ui_project:getChildByName("AtlasLabel")
    self.AtlasLabel:setString("")
    self.time = 0
    self.schedule_handle = nil

end


function TimerUIManager:startTimer(time, call_function, text)
     self:ui_open()
     local Sprite = cc.Sprite:create("game_res/90010500/gameScene/game_clock_1.png")
     self.ProgressTimer:setSprite(Sprite)
     self.ProgressTimer:setPercentage(100)
     if not time or time<=0 or time>600 then
        self:ui_close()
        if time<=0 and call_function~=nil then
            call_function()
        end
        return
     end
     if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
     end
     self.time = time
     self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
        self.time = self.time-0.25
        self.AtlasLabel:setString(tostring(math.ceil(self.time)))
        self.ProgressTimer:setPercentage(self.time/time*100)
        if self.time<=time/2 then
           local Sprite = cc.Sprite:create("game_res/90010500/gameScene/game_clock_2.png")
           self.ProgressTimer:setSprite(Sprite)
           self.AtlasLabel:setProperty(tostring(math.ceil(self.time)), "game_res/90010500/com/num_1.png", 28, 45, '.') 
        end
        if self.time<=time*1/4 then
           local Sprite = cc.Sprite:create("game_res/90010500/gameScene/game_clock_3.png")
           self.ProgressTimer:setSprite(Sprite)
           self.AtlasLabel:setProperty(tostring(math.ceil(self.time)), "game_res/90010500/com/num_2.png", 28, 45, '.') 
        end
        if self.time<=0 then
            self:stopTimer()
            if call_function~=nil then
               call_function()
            end
        end
     end,
     0.25, 
     false)
     self.AtlasLabel:setProperty(tostring(math.ceil(self.time)), "game_res/90010500/com/num_0.png", 28, 45, '.')
     self.AtlasLabel:setString(tostring(math.ceil(self.time)))
     if text then
        self.Text_tip:setString(text)
     else
        self.Text_tip:setString("")
     end
end


function TimerUIManager:stopTimer()

    if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
        self.schedule_handle = nil
    end
    self.time = 0
    self.AtlasLabel:setString("")
    self.Text_tip:setString("")
    self:ui_close()
end

function TimerUIManager:setText(text)
    self.Text_tip:setString(text)
end

function TimerUIManager:setEnable(enable)
    self.Image_timer_bg:setVisible(enable)
    self.ProgressTimer:setVisible(enable)
    self.AtlasLabel:setVisible(enable)
    self.Text_tip:setVisible(enable)
end


function TimerUIManager:clearSchedule()
   if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
   end
end


function TimerUIManager:ui_open()
    self.ui_project:setVisible(true)
end

function TimerUIManager:ui_close()
    self.ui_project:setVisible(false)
end

return TimerUIManager



--endregion
