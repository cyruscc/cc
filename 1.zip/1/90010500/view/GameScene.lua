--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

require("app/platform/game/90010500/view/ViewHelp")

local BaseUIManager = import('.BaseUIManager')
local PlayerUIManager = import('.PlayerUIManager')
local CardUIManager = import('.CardUIManager')
local CallUIManager = import('.CallUIManager')
local BillingUIManager = import('.BillingUIManager')
local RecorderUIManager = import('.RecorderUIManager')
local TimerUIManager = import('.TimerUIManager')
local m_download = import("....common.download")
local m_def = import("....room.module.basicnotifydef")
local CallOwnerLayer = import('.CallOwnerLayer')
local CAddGamePointLayer  = import("....room.view2.room.AddGamePointLayer")
local GameSceneModule = import("..GameSceneModule")
local GameSceneBase = import("app.platform.game.GameSceneBase")
local CGameScene = class("CGameScene", GameSceneBase )

function CGameScene:onCreate()
    self.deskActive = false
    self.bAgree = false
    self.super:registered_child(self)
    ViewHelp.setGameScene( self )

    ViewHelp.initBasePosChair()
    ViewHelp.setLeaveEnable(true)
    ViewHelp.initVoiceNotTable()
    ViewHelp.setBankerChair(-1)
    ViewHelp.setLastMutiply(-1)
    
    GameSceneModule:getInstance():init(self)

            --请求恢复游戏状态
    self.super:reqDeskRebind()

	local GameLayer = cc.CSLoader:createNode("game_res/90010500/gameScene/GameLayer.csb")
	self:addChild(GameLayer)


    local Image_root = GameLayer:getChildByName("Image_root")
     
    self.Panel_animate = Image_root:getChildByName("Panel_animate")

    self.BaseUIManager = BaseUIManager.new(Image_root:getChildByName("Panel_base"), self)

    self.PlayerUIManager = PlayerUIManager.new(Image_root:getChildByName("Panel_player"), self)

    self.TimerUIManager = TimerUIManager.new(Image_root:getChildByName("Panel_timer"))
    self.TimerUIManager:ui_close()

    self.CallUIManager = CallUIManager.new(Image_root:getChildByName("Panel_call"), self)
    self.CallUIManager:ui_close()

    self.CardUIManager = CardUIManager.new(Image_root:getChildByName("Panel_card"), self)
    self.CardUIManager:ui_close()

    self.BillingUIManager = BillingUIManager.new(Image_root:getChildByName("Panel_billing"), self)
    self.BillingUIManager:ui_close()

    self.RecorderUIManager = RecorderUIManager.new(Image_root:getChildByName("Panel_recorder"))
    self.RecorderUIManager:ui_close()


    self:registerScriptHandler(handler(self, self.onNodeEvent))

    self.autoTime = 0

        --自动坐桌
    self:autoSitDesk()
    Music:stopMusic()
end

function CGameScene:onNodeEvent( event )
    if event == "enter" then
		--返回键开启
        g_setMainLayerDelegate(self)
        self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
            local desk_config  = self.super:getDeskInfo()
            desk_config.leaveTime = desk_config.leaveTime-1
            if desk_config.leaveTime<=0 then
               desk_config.leaveTime = 0
                if self.schedule_handle~=nil then
                    g_scheduler:unscheduleScriptEntry(self.schedule_handle)
                    self.schedule_handle = nil
                end
             end
        end,
        1.0, 
        false)
	elseif event == "exit" then
        self:clearSchedule_handle()
	end
end

function CGameScene:clearSchedule_handle(args)
    self.TimerUIManager:clearSchedule()
    self.RecorderUIManager:clearSchedule()
    if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
        self.schedule_handle = nil
    end
end


function CGameScene:onKeyReleased(keyCode, event)
    if keyCode ~= cc.KeyCode.KEY_BACK then
        return
    end
    if ViewHelp.getLeaveEnable()==false then
        
       Msg:showTips("游戏过程中不能退出游戏哦!")
       return
    end
    self.super:reqLeaveDesk()
    self.super:Exit_game()
end

        --自动坐桌
function CGameScene:autoSitDesk()
    print("检测自动坐下")
    if UserData:getAutoSitDesk()==1 and tonumber(ViewHelp.getSelfPlayer().chair)<0 and self.super:getDeskInfo().config.antes*4*5<=ViewHelp.getSelfPlayer().point then
        for i=1, 5 do
            local player_info = ViewHelp.get_player_info_by_chairID(i-1)
            if not player_info then
                self.super:reqSitdownDesk(i-1, true)
                self.autoTime = self.autoTime+1
                break
            end
        end
    end
end
--播放动画
function CGameScene:playGameAnimate(animate_file, parent, position, call_func, restore)

    local game_armature = cc.CSLoader:createNode(animate_file)
    local action = cc.CSLoader:createTimeline(animate_file)
    action:gotoFrameAndPlay(0,false)
    game_armature:runAction(action)
    action:setLastFrameCallFunc(function()
        if restore==true then
            if call_func then
                game_armature:runAction(cc.Sequence:create(cc.DelayTime:create(0.5), cc.CallFunc:create(call_func))) 
            end
        else
            if call_func then
                call_func() 
            end
            game_armature:removeFromParent()
        end
    end)
    if position then
        game_armature:setPosition(cc.p(position.x, position.y))
    else
        game_armature:setPosition(cc.p(640, 360))
    end
    if not parent then
        self.Panel_animate:addChild(game_armature)
    else
        parent:addChild(game_armature)
    end
    return game_armature
end

function CGameScene:pointLease()
    local text_tip  = ""
    local call_func = nil
    if self.super:getDeskInfo().mastUserID~=tonumber(ViewHelp.getSelfPlayer().userID) then
        text_tip = "您的分数不够啦，请及时联系房主加分！"
        call_func = function()
           self:addChild(CallOwnerLayer:create())
        end
    else
        text_tip = "您的分数不够啦，给自己加点分吧！"
        call_func = function()
           local apply_info ={}
           apply_info.apply_user_nickName = ViewHelp.getSelfPlayer().nick
           apply_info.apply_user_tablePoint = ViewHelp.getSelfPlayer().point
           apply_info.apply_user_id = ViewHelp.getSelfPlayer().userID
           apply_info.desk_id=self.super:getDeskInfo().roomID
           self:addChild(CAddGamePointLayer:create(apply_info, true))
        end
    end
    api_show_Msg_Tip( text_tip , call_func )
end

function CGameScene:getBaseUIManager()
    return self.BaseUIManager
end

function CGameScene:getPlayerUIManager()
    return self.PlayerUIManager
end

function CGameScene:getCallUIManager()
    return self.CallUIManager
end

function CGameScene:getCardUIManager()
    return self.CardUIManager
end

function CGameScene:getBillingUIManager()
    return self.BillingUIManager
end

function CGameScene:getRecorderUIManager()
    return self.RecorderUIManager
end

function CGameScene:getTimerUIManager()
    return self.TimerUIManager
end
function CGameScene:getAnimatePanel()
    return self.Panel_animate
end

function CGameScene:check_ready()
    if self.deskActive == true and self.bAgree == false and ViewHelp.getSelfPlayer().chair >= 0 then
        if UserData:getAutoAgree() == 1 then
            GameSceneModule:request_player_ready()
        else
            self.CallUIManager:ui_open()
            self.CallUIManager:game_ready()
        end
    end
end

-------------------------------------------游戏消息---------------------------------------

    --入场场景恢复
function CGameScene:game_rebind(resp_table)

    if not resp_table then
        print("game_rebind---------------error")
        return
    end

    if resp_table.GameStation == 0 then
        self.deskActive = resp_table.deskActive
    else
        self.deskActive = true
    end

    if ViewHelp.getSelfPlayer().chair >= 0 and  resp_table.table_bAgree[ViewHelp.getSelfPlayer().chair]==true then
        self.bAgree = true
    else
        self.bAgree = false
    end
    self:check_ready()

    self.PlayerUIManager:game_rebind_ready(resp_table)
        --游戏准备阶段
    if resp_table.GameStation==1 then

        self.TimerUIManager:startTimer(resp_table.iLeaverTime, nil, "游戏即将开始...")

        --游戏叫庄阶段
    elseif resp_table.GameStation==20 then
       if ViewHelp.getSelfPlayer().chair>=0 then
            ViewHelp.setLeaveEnable(false)
       end
        self.PlayerUIManager:game_rebind_banker(resp_table)
        --游戏下注阶段
    elseif resp_table.GameStation==21 then
        if ViewHelp.getSelfPlayer().chair>=0 then
            ViewHelp.setLeaveEnable(false)
        end
        self.PlayerUIManager:game_rebind_bet(resp_table)

        --游戏发牌阶段
    elseif resp_table.GameStation==22 then
        if ViewHelp.getSelfPlayer().chair>=0 then
            ViewHelp.setLeaveEnable(false)
        end
        self.PlayerUIManager:game_rebind_card_send(resp_table)

         --游戏开牌阶段
    elseif resp_table.GameStation==23 then
        if ViewHelp.getSelfPlayer().chair>=0 then
            ViewHelp.setLeaveEnable(false)
        end
        self.PlayerUIManager:game_rebind_card_open(resp_table)

        --游戏结算阶段
    elseif resp_table.GameStation==24 then
        --
        ViewHelp.setBankerChair(-1)
    end
end

    --有玩家准备
function CGameScene:player_ready(resp_table)
    if not resp_table then
        print("player_ready---------------error")
        return
    end
    if resp_table.chair == ViewHelp.getSelfPlayer().chair then
        self.CallUIManager:hideReday()
        self.bAgree = true
    end
    self.PlayerUIManager:player_ready(resp_table)
end

    --准备倒计时取消
function CGameScene:game_ready_timer_cancel(resp_table)
    self.TimerUIManager:stopTimer()
end
    --准备倒计时开始
function CGameScene:game_ready_timer(resp_table)
    if not resp_table then
        print("game_ready_timer---------------error")
        return
    end
    self.TimerUIManager:startTimer(resp_table.time, nil, "游戏即将开始...")
    self:update_game_record()
end

    --游戏开始
function CGameScene:game_start(resp_table)

    local deskInfo = self.super:getDeskInfo()
    dump( deskInfo  , "-------------- desk_info --------------" , 10 )

    if not resp_table then
        print("game_start---------------error")
        return
    end
    Music:playEffect("game_res/90010500/sound/game/game_start.mp3", false)
    self.super:getDeskInfo().progress = self.super:getDeskInfo().progress+1
    --for i=1, #resp_table.playerData do
       --local desk_player = ViewHelp.get_player_info_by_chairID(resp_table.playerData[i].chair)
       --desk_player.behavior.PlayedRounds = desk_player.behavior.PlayedRounds+1
    --end
    self.TimerUIManager:stopTimer()
    self:playGameAnimate("game_res/90010500/armature/KS/KS.csb")
    self:playGameAnimate("game_res/90010500/armature/KS/Node.csb")
    self.PlayerUIManager:game_start(resp_table)
    self.BaseUIManager:game_start(resp_table)
end

    --通知玩家叫庄
function CGameScene:game_banker_notify(resp_table)
    if not resp_table then
        print("game_banker_notify---------------error")
        return
    end
    self.CallUIManager:game_banker_notify(resp_table)
    if resp_table.chair == ViewHelp.getSelfPlayer().chair then
       self.TimerUIManager:startTimer(resp_table.bankertime)
       return
    end
    local  player = ViewHelp.get_player_info_by_chairID(resp_table.chair)
    if player then
       self.TimerUIManager:startTimer( resp_table.bankertime, nil, "\""..player.nick.."\"正在叫庄...")
    end
end
    --玩家叫庄结果
function CGameScene:player_banker(resp_table)
    if not resp_table then
        print("player_banker---------------error")
        return
    end
    if ViewHelp.get_player_info_by_chairID(resp_table.chair).boy then
        if resp_table.bIsQiang then
            Music:playEffect("game_res/90010500/sound/game/game_boy_rob.mp3", false)
        else
            Music:playEffect("game_res/90010500/sound/game/game_boy_rob_not.mp3", false)
        end
    else
        if resp_table.bIsQiang then
            Music:playEffect("game_res/90010500/sound/game/game_girl_rob.mp3", false)
        else
            Music:playEffect("game_res/90010500/sound/game/game_girl_rob_not.mp3", false)
        end
    end
    self.CallUIManager:player_banker(resp_table)
end

    --叫庄结束
function CGameScene:game_banker_end(resp_table)
    if not resp_table then
        print("game_banker_end---------------error")
        return
    end
    self.TimerUIManager:stopTimer()
    Music:playEffect("game_res/90010500/sound/game/game_banker.mp3", false)
    ViewHelp.setBankerChair(resp_table.chair)
    self.PlayerUIManager:game_banker_end(resp_table, true)
--    local desk_player = ViewHelp.get_player_info_by_chairID(resp_table.chair)
--    desk_player.behavior.BankerTimes = desk_player.behavior.BankerTimes+1
end

    --随机庄结束
function CGameScene:game_banker_rand(resp_table)
    if not resp_table then
        print("game_banker_rand---------------error")
        return
    end
    Music:playEffect("game_res/90010500/sound/game/game_banker.mp3", false)
    ViewHelp.setBankerChair(resp_table.chair)
    self.PlayerUIManager:game_banker_rand(resp_table, true)
--    local desk_player = ViewHelp.get_player_info_by_chairID(resp_table.chair)
--    desk_player.behavior.BankerTimes = desk_player.behavior.BankerTimes+1
end


    --通知玩家下注
function CGameScene:game_bet_notify(resp_table)
    if not resp_table then
        print("game_bet_notify---------------error")
        return
    end
    self.CallUIManager:game_bet_notify(resp_table)

end

    --玩家下注
function CGameScene:player_bet(resp_table)
    if not resp_table then
        print("player_bet---------------error")
        return
    end
    self.CallUIManager:player_bet(resp_table)
    self.PlayerUIManager:player_bet(resp_table)
--    local desk_player = ViewHelp.get_player_info_by_chairID(resp_table.chair)
--    local key = string.format("Multiply%d", resp_table.multiplying)
--    desk_player.behavior[key] = desk_player.behavior[key] +1
end

    --发牌
function CGameScene:game_card_send(resp_table)
    if not resp_table then
        print("game_card_send---------------error")
        return
    end
    self.CallUIManager:game_card_send(resp_table)
    self.CardUIManager:game_card_send(resp_table, true)
end

    --游戏开始开牌
function CGameScene:game_card_open(resp_table)
    if not resp_table then
        print("game_card_open---------------error")
        return
    end
    self.CardUIManager:game_card_open(resp_table)
    self.TimerUIManager:startTimer(resp_table.displayTime)
end

    --玩家开牌
function CGameScene:player_card_open(resp_table)

    if not resp_table then
        print("player_card_open---------------error")
        return
    end
    Music:playEffect("game_res/90010500/sound/game/game_complete.mp3", false)
    if resp_table.chair==ViewHelp.getSelfPlayer().chair and resp_table.remain > 0 then
        self.TimerUIManager:setText("还有人在冥思苦想中...")
    end
    self.CardUIManager:player_card_open(resp_table)
end


    --结算
function CGameScene:game_end(resp_table)
    if not resp_table then
        print("game_end---------------error")
        return
    end
    local count  = 0
    for key, var in pairs(resp_table) do
        local desk_player = self.super:getPlayerInfoByChairID(key)
        if desk_player then
            desk_player.dwProfit = desk_player.dwProfit+var.iChangePoint
            desk_player.dwMoney = var.iTotalPoint
--            if desk_player.dwProfit>desk_player.behavior.MaxProfit then
--              desk_player.behavior.MaxProfit = desk_player.profit
--            end
        end

        count = count+1
    end
    ViewHelp.setLeaveEnable(true)
    performWithDelay(self,
    function()
        self.CardUIManager:game_card_data_clear() 
        self.BillingUIManager:game_end(resp_table, true)
    end, 
    1.0)
    self.TimerUIManager:stopTimer()
    performWithDelay(self,
    function()
       self.Panel_animate:removeAllChildren()
       ViewHelp.setBankerChair(-1)
       self.PlayerUIManager:game_end(resp_table)
       self.CardUIManager:game_end_clear() 
       self.BillingUIManager:game_end_clear()
       self.CallUIManager:game_end_ready(resp_table)
       self.PlayerUIManager:game_end_clear(resp_table)
    end, 
    3*count+2.5)
end

local game_record_update_call = nil
function CGameScene:update_game_record()
    if game_record_update_call then
        performWithDelay( self , game_record_update_call , 0.5)
    end
end

function CGameScene:register_game_record_update_call( call )
    game_record_update_call = call
end

function CGameScene:show_game_record()
    local deskInfo = self.super:getDeskInfo()
    self.super:Exit_game( 1 , deskInfo )
end


--------------------------------------end------------------------------------------------




-------------------------------------------平台接口---------------------------------------
--@desc  桌子激活
--@param code 0.激活桌子成功 1.未进入房间 2.你不是房主无权限 3.桌子已曾激活 -1.其它原因
function CGameScene:deskStart( code  )
    if code == 1 then
        api_show_Msg_Box( "你已掉线，是否重新进入游戏" , function()
            self.super:Exit_game()
        end ,  false )
    elseif code == 2 then
        api_show_tips("你不是房主，没权解散房间")
    elseif code == 3 then
        print("桌子已经激活")
    elseif code == 0 or code == nil then
        self.BaseUIManager:deskStart()
        self.CallUIManager:deskStart()
        self.deskActive = true
    else
        api_show_Msg_Box("开始失败，未知的错误("..code..")")
    end
end

--@desc  加入桌子
--@param code 1.桌子号不属于本房间 5.桌子人数已满人 -1.其它原因
function CGameScene:playerJoinDesk( user_info , desk_info , code )
    if user_info then
       print("有玩家加入桌子 ")
       return
       self:update_game_record()
    end
end

--@desc  离开桌子
--@param code 1.正在游戏不准离开桌子 2.已经离开不需要再次离开
function CGameScene:playerLeaveDesk( user_info , desk_info  , code )
    if code == 1 then
        api_show_tips("你正在游戏中，不允许离开")
    elseif code == 2 then
        self.super:Exit_game()
    elseif code == 0 or code == nil then
        local user_info_qz1 = ViewHelp.qz_common_user_info_To_qz1( user_info )
        if user_info_qz1.chair >= 0 then
            self:playerStandUp( user_info , desk_info  , 0 )
        end
        self:update_game_record()
    else
        api_show_tips("离开失败，未知错误("..code..")")
    end
end

--@desc  坐下
--@param code 1.位置上已有玩家 2.分数不足 3.座位不正确 4.玩家未进房间 5.不允许坐下 6.房间已解散 7.被房主禁了 8.桌子索引不属于本房间 9.桌子已满人  10.玩家已经坐下 -1.其它原因
function CGameScene:playerSitDesk( user_info , desk_info , code )
    --performWithDelay( self , function()

        local function show_tips( type , msg , ok_call , cancel_call , close_enable )
            performWithDelay( self , function()
                if type == 1 then
                    api_show_tips( msg )
                elseif type == 2 then
                    api_show_Msg_Tip( msg , ok_call , cancel_call , close_enable )
                elseif type == 3 then
                    api_show_Msg_Box( msg , ok_call , close_enable )
                end
            end , 0.35)

        end
        
        if code == 1 then
            show_tips( 1 , "该座位上已有玩家坐下")
        elseif code == 2 then
            if user_info.dwUserID == self:getDeskInfo().mastUserID then
                show_tips( 2 , "您的分数不够啦，给自己加点分吧！" , function ()
                   local apply_info ={}
                   apply_info.apply_user_nickName = ViewHelp.getSelfPlayer().nick
                   apply_info.apply_user_tablePoint = ViewHelp.getSelfPlayer().point
                   apply_info.apply_user_id = ViewHelp.getSelfPlayer().userID
                   apply_info.desk_id=self.super:getDeskInfo().roomID
                   self:addChild(CAddGamePointLayer:create(apply_info, true))
                end)
            else
                show_tips( 2 , "您的分数不够啦，请及时联系房主加分！" , function ()
                    self:addChild(CallOwnerLayer:create())
                end)
            end

        elseif code == 4 then
            show_tips(1,"你坐下的座位号非法")
        elseif code == 5 then
            show_tips( 3 ,"游戏逻辑不允许坐下" , nil , false )
        elseif code == 6 then
            show_tips( 3 ,"房间已解散，请退出房间" , function() 
                self.super:Exit_game()
            end , true)
        elseif code == 7 then
            show_tips( 3 ,"房主不允许坐下")
        elseif code == 8 then
            show_tips( 3 ,"桌子索引错误，请退出房间" , function()
                self.super:Exit_game()
            end , true)
        elseif code == 9 then
            show_tips( 1 , "桌子人数已满")
        elseif code == 10 then
            show_tips( 1 , "你已经坐下，请站起后再坐下")
        elseif code == 0 or code == nil then
            if user_info == nil then
                show_tips( 1, "进入的玩家信息为 空")
            else
                local user_info_qz1 = ViewHelp.qz_common_user_info_To_qz1( user_info )
                Music:playEffect("game_res/90010500/sound/game/game_sitdown.mp3", false)
                if ViewHelp.getSelfPlayer().userID == tonumber(user_info_qz1.userID) then
                    ViewHelp.setBasePosChair(tonumber(user_info_qz1.chair))
                    self:check_ready()
                end
                self.PlayerUIManager:playerSitDesk( user_info_qz1 )
                self.CardUIManager:playerSitDesk( user_info_qz1 )
                self.BillingUIManager:playerSitDesk( user_info_qz1 )
                self:update_game_record()
            end
        else
            show_tips( 2 ,"坐下失败，未知错误("..code..")" , function()
                self.super:Exit_game()
            end , true)
        end
   -- end , 0.5 )
    
end

--@desc  站起
--@param code 1.玩家正在游戏中 2.玩家不在房间  -1.其它原因
function CGameScene:playerStandUp( user_info , desk_info , code ) 
    if code == 1  then
        api_show_tips("你正在游戏中，不允许站起")
    elseif code == 2 then
        api_show_tips("你不在房间中，不需要站起")
    elseif code == 0 or code == nil then
        Music:playEffect("game_res/90010500/sound/game/game_stand.mp3", false)
        local user_info_qz1 = ViewHelp.qz_common_user_info_To_qz1( user_info )
        self.CallUIManager:playerStandUp( user_info_qz1 )
        self.PlayerUIManager:playerStandUp( user_info_qz1 )
        self:update_game_record()
        if user_info_qz1.userID == ViewHelp.getSelfPlayer().userID then
            self.bAgree = false            
        end
    else        
        api_show_tips("站起失败，未知错误("..code..")")
    end
end


-- 聊天           有玩家发送了文字聊天信息
function CGameScene:playerChat( user_info , desk_info , chatInfo )
    local user_info_qz1 = ViewHelp.qz_common_user_info_To_qz1( user_info )
    self.PlayerUIManager:player_chat( user_info_qz1 , chatInfo )
end


--@desc  语音           有玩家发送了语音聊天信息
--@param code 1.房间禁止发话 2.不在房间 3.非法音频ID 4.重复使用音频ID -1.其它原因
function CGameScene:playerRecorderNew(  user_info , desk_info , recordInfo , code ) 
    if code == 1 then
        api_show_tips("发送失败，房主禁止聊天")
    elseif code == 2 then
        api_show_Msg_Box("你已经不在房间里，请退出游戏" , function()
            self.super:Exit_game()
        end , true)
    elseif code == 3 then
        api_show_tips("非法的音频")
    elseif code == 4 then
        api_show_tips("该语言已发送，请勿重复发送")
    elseif code == 0 or code == nil then
        local user_info_qz1 = ViewHelp.qz_common_user_info_To_qz1( user_info )
        if ViewHelp.isElementOfVoiceNotTable(user_info_qz1.userID) then
           return
        end        
        self.PlayerUIManager:player_recorder(  user_info_qz1 , recordInfo )
        self.BaseUIManager:player_recorder(  user_info_qz1 , recordInfo )
    else
        api_show_Msg_Box("语音发送失败，未知错误（"..code.."）")
    end
    
end

--@desc  房主请求解散失败时的返回
--@param code 0.解散命令已成功，但是要等待游戏解散 1.未在房间里没权解散 2.不是房主无权解散 3.桌子已经解散不需要重复解散 -1.其他原因 
function CGameScene:onMasterDismissDeskFail( code  )
    if code == 0 or code == nil then
        api_show_Msg_Box("发送成功，本局游戏结算后房间将会自动解散")
    elseif code == 1 then
        api_show_Msg_Box("你已掉线，请退出房间" , function()
            self.super:Exit_game()
        end , true)
    elseif code == 2 then
        api_show_Msg_Box("你不是房主，无权解散房间")
    elseif code == 3 then
        api_show_Msg_Box("桌子已经解散不需要重复解散 ")
    else
        api_show_Msg_Box("解散失败，未知错误（"..code.."）")
    end
end


--@desc  桌子解散
--@param code 1.房主解散 2.对局已打满  3.桌子限期已到  4大家同意解散 5.有玩家申请解散房间
--@param user_info 有玩家请求解散时对应玩家的信息
function CGameScene:onDeskDismiss( code , user_info )
    if code == 1 then
        local deskInfo = self.super:getDeskInfo()
        dump( deskInfo )
        if deskInfo.progress ~= nil and deskInfo.progress>0 then
            api_show_Msg_Tip( "房间已被房主解散，是否前往查看战绩?",  function()
                self.super:Exit_game( 1 , self.super:getDeskInfo() )
            end, function()
                self.super:Exit_game()
            end , true)
        else
            api_show_Msg_Box("房间已被房主解散",function()
                self.super:Exit_game()
            end , true)
        end
    elseif code == 2 then
        api_show_Msg_Tip("游戏已经结束，是否前往查看战绩?" ,  function()
            self.super:Exit_game( 1 , self.super:getDeskInfo() )
        end, function()
            self.super:Exit_game()
        end , true)
    elseif code == 3 then
        api_show_Msg_Tip("房间已到期，是否前往查看战绩?" ,  function()
            self.super:Exit_game( 1 , self.super:getDeskInfo() )
        end, function()
            self.super:Exit_game()
        end , true)
    else
        api_show_Msg_Tip( "房间已解散，未知错误("..code..")" ,  function()
            self.super:Exit_game()
        end , true)
    end
end

--@desc  给玩家加分结果返回
--@param code 1.房主身份验证不通过; 2.您不是房主没权加分 3.桌子不存在; 4.该玩家没有进入过本桌子; 10.请求参数有误; -1.其它原因
--@param add_point 本次添加的分数
function CGameScene:playeMasterAddPointBack( user_info , desk_info , code , add_point)
    if code == 1 then
        api_show_tips("你不是房主，没有权限加分")
    elseif code == 2 then
        api_show_tips("你不是房主，没有权限加分")
    elseif code == 3 then
        api_show_Msg_Tip("桌子已解散，请退出房间" , function() 
            self.super:Exit_game()
        end , true)
    elseif code == 4 then
        api_show_tips("该玩家没有进入过本桌子，不可以对其添加分数")
    elseif code == 10 then
        api_show_tips("请求参数有错误")
    elseif code == 0 or code == nil then
        local user_info_qz1 = ViewHelp.qz_common_user_info_To_qz1( user_info )
        if user_info_qz1.userID==tonumber(ViewHelp.getSelfPlayer().userID) and self.super:getDeskInfo().mastUserID~=tonumber(ViewHelp.getSelfPlayer().userID) then
            api_show_tips(string.format("房主给您加了%d分！", add_point))
        else
            api_show_tips(string.format("房主给\"%s\"加了%d分！", user_info_qz1.nick , add_point))
        end
        self:update_game_record()
        self.PlayerUIManager:add_point_notity( user_info_qz1 , add_point )
    else
        api_show_Msg_Box("加分失败，未知错误("..code..")")
    end 

end

--@desc  申请加分数结果返回
--@param code 0.发送成功，待房主给你回应 1.您不在房间中，不可以申请 2.房间已解散 3.错误内容类型码 10-参数错误 -1.其他原因
function CGameScene:ans_apply_add_point_by_master( code )
    if code == 0 or code == nil then
        api_show_tips("发送成功！")
    elseif code == 1 then
        api_show_Msg_Box("你已经退出了房间" , function() 
            self.super:Exit_game()
        end , true)
    elseif code == 2 then
        api_show_Msg_Box("房间已经解散")
    elseif code == 3 then
        api_show_tips("错误的类型")
    elseif code == 10 then
        api_show_tips("参数错误")
    else
        api_show_Msg_Box("申请失败，未知错误("..code..")")
    end
end

--@desc  收到申请信息
function CGameScene:onHasApplyInfo()
    Music:playEffect("res/sound/hall/msgTips.mp3")
    self.BaseUIManager:new_applyinfo_notify()
end

--@desc  被T           玩家被房主T出房间
--@param code 1.不能踢自己 2.不是房主不能T人 3.要踢出的用户不在房间中 4.你不在房间中不能操作 5.玩家已曾踢除 10.请求参数有误 -1.其它原因
function CGameScene:playerByMasterBoot(  user_info , desk_info , code )
    if code == 1 then
        api_show_tips("你不可已踢自己")
    elseif code == 2 then
        api_show_tips("你不是房主，没有权限踢人")
    elseif code == 3 then
        api_show_tips("该玩家已经不再房间里")
    elseif code == 4 then
        api_show_tips("你不在房间中，请退出" , function()
            self.super:Exit_game()
        end , true)
    elseif code == 5 then        
        api_show_tips("该玩家已被踢出房间，请勿重复操作")
    elseif code == 10 then
        api_show_tips("请求参数有误")
    elseif code == 0 or code == nil then
        local user_info_qz1 = ViewHelp.qz_common_user_info_To_qz1( user_info )
        if user_info_qz1.userID == ViewHelp.getSelfPlayer().userID then
            self:clearSchedule_handle()
            api_show_Msg_Box("你被房主踢出了房间" , function()
                self.super:Exit_game()

            end , true) 
        else
            api_show_tips( user_info_qz1.nick.." 被房主踢出了房间")     
            self:playerStandUp(user_info , desk_info , 0) 
            self:update_game_record()      
        end
    else
        api_show_Msg_Box("踢人失败，未知错误（"..code.."）")
    end
end

--@desc  聊天开关改变
--@param code 1.不是房主不能操作 2.不在房间中不能操作 3.不能重复操作 10.请求参数有误 -1.其它原因
function CGameScene:changeChatSwitch( isOpen , code )
    if code == 1 then
        api_show_tips("你不是房主，没有权限设置")
    elseif code == 2 then
        api_show_Msg_Box("你已不在房间中，请退出游戏" , function()
            self.super:Exit_game()
        end , true)
    elseif code == 3 then
        api_show_tips("不能重复操作")
    elseif code == 10 then
        api_show_tips("请求参数错误")
    elseif code == 0 or code == nil then
        self.BaseUIManager:chat_enable_notity( isOpen )
    else
        api_show_Msg_Box("改变房间聊天的开关失败，未知错误（"..code.."）")
    end
end

--@desc  进入开关改变
--@param code 1.不是房主不能操作 2.不在房间中不能操作 3.不能重复操作 10.请求参数有误 -1.其它原因
function CGameScene:changeEnterDeskSwitch( isOpen , code )
    if code == 1 then
        api_show_tips("你不是房主，没有权限设置")
    elseif code == 2 then
        api_show_Msg_Box("你已不在房间中，请退出游戏" , function()
            self.super:Exit_game()
        end , true)
    elseif code == 3 then
        api_show_tips("不能重复操作")
    elseif code == 10 then
        api_show_tips("请求参数错误")
    elseif code == 0 or code == nil then
        if isOpen == false then
            api_show_tips("房间已设置为禁止加入")
        else
            api_show_tips("房间已设置为允许加入")
        end
    else
        api_show_Msg_Box("改变房间加入的开关失败，未知错误（"..code.."）")
    end
end

function CGameScene:other_player_offline(user_info)
    
end

--@desc  掉线通知
--@param code 1.socket错误 2.心跳超时 3.账号在异地登录被挤下
function CGameScene:onOffLineNotify( code , desc )
    if code == 1 then
        api_show_Msg_Box(" 你已经掉线 ！",function()
            self:Exit_game()
        end , true)
    elseif code == 2 then
        api_show_Msg_Box(" 你已经掉线 ！",function()
            self:Exit_game()
        end , true )
    elseif code == 3 then
        api_show_Msg_Box("你的账号在另一个移动端登录" , function()
            self:Exit_game(3)
        end , true )
    end
end
--------------------------------------end------------------------------------------

return CGameScene

--endregion
