--region *.lua
--Date
--此文件由[BabeLua]插件自动生成
local GameSceneModule = import('..GameSceneModule')
local CardUIManager = class("CardUIManager")

function CardUIManager:ctor(ui_project, ui_root)

    self.ui_project = ui_project
    self.ui_root = ui_root
    self.player_card_open_resp_table = {}
    self.table_ui_card = {}
    self.table_card_value = {}
    self.last_select_idx = -1
    self.table_select_card = {nil, nil, nil, nil, nil}
    self.table_text = {}
    self.table_help_value = {}

    for i=1,  5 do
        local ui_card = ui_project:getChildByName("Panel_card_"..(i-1))
        ui_card:setVisible(false)
        self.table_ui_card[i] = ui_card
    end

    self.Panel_calculate = ui_project:getChildByName("Panel_calculate")
    self.Panel_calculate:setVisible(false)

    local Image_help_bg = self.Panel_calculate:getChildByName("Image_help_bg")
    for i=1, 4 do
        local Text_card = Image_help_bg:getChildByName("Text_card_"..(i-1))
        Text_card:setString("")
        self.table_text[i] = Text_card
    end

    for i=1, 5 do
        local Image_card = self.Panel_calculate:getChildByName("Image_card_"..(i-1))
        Image_card:addClickEventListener(function()
            if self:isSelect(Image_card) then
                self:helpTableRemove(self.table_card_value[i])
                self.table_select_card[i] = nil
                Image_card:setPositionY(110)
                if Image_help_bg:isVisible() then
                   self:setHelpText()
                end
            else
                if self:isFull() then
                   self.table_select_card[self.last_select_idx]:setPositionY(110)
                   self.table_select_card[self.last_select_idx] = nil
                   self:helpTableRemove(self.table_card_value[self.last_select_idx])
                end
                table.insert(self.table_help_value, #self.table_help_value+1, self.table_card_value[i])
                self.table_select_card[i] = Image_card
                Image_card:setPositionY(130)
                self.last_select_idx = i
                if Image_help_bg:isVisible() then
                   self:setHelpText()
                end
            end

        end)
        Image_card:setPositionY(110)
    end

    local Button_help = self.Panel_calculate:getChildByName("Button_help")
    Button_help:addClickEventListener(function()
         local has_niu, niu_table = self:getTableCardNiuValue()
         if has_niu==false then
            Msg:showTips("您的牌没有牛噢!")
        else
            if self:isNiuValue() then
               return
            end
            self.table_select_card = {nil, nil, nil, nil, nil}
            self.table_help_value = niu_table
            for i=1, 5 do
                local Image_card = self.Panel_calculate:getChildByName("Image_card_"..(i-1))
                Image_card:setPositionY(110)
                for j=1, #self.table_help_value do
                   if self.table_help_value[j]==self.table_card_value[i] then
                       self.table_select_card[i] = Image_card
                       self.last_select_idx = i
                       Image_card:setPositionY(130)
                       break
                   end
                end
            end
            if Image_help_bg:isVisible() then
                self:setHelpText()
            end
        end
    end)

        --有牛按钮
    local Button_has_niu = self.Panel_calculate:getChildByName("Button_has_niu")
    Button_has_niu:addClickEventListener(function()
        if self:isNiuValue()==true then
           GameSceneModule:request_player_card_open(ViewHelp.getSelfPlayer().chair)
           self.Panel_calculate:setVisible(false)
        else
            Msg:showTips("有牛需要“10”的倍数哦!")
            print("Bai niu error!---no zuo no die!")
        end
    end)

        --没牛按钮
    local Button_no_niu = self.Panel_calculate:getChildByName("Button_no_niu")
    Button_no_niu:addClickEventListener(function()
        local has_niu, niu_table = self:getTableCardNiuValue()
        if has_niu==false then
           GameSceneModule:request_player_card_open(ViewHelp.getSelfPlayer().chair)
           self.Panel_calculate:setVisible(false)
        else
            Msg:showTips("手上的牌是有牛的噢，再看一眼？")
            print("Are you sure mei niu?")
        end
    end)


        --超级牛按钮
    local Button_super_niu = self.Panel_calculate:getChildByName("Button_super_niu")
    Button_super_niu:addClickEventListener(function()
       GameSceneModule:request_player_card_open(ViewHelp.getSelfPlayer().chair)
       self.Panel_calculate:setVisible(false)
    end)

end

--设置提示算牛
function CardUIManager:setHelpText()
    for i=1, #self.table_text do
        if self.table_help_value[i]~=nil then
           self.table_text[i]:setString(self:getCardString(self.table_help_value[i]))
        else
           self.table_text[i]:setString("")
        end
        if i==4 then
           local sum = 0
           for j=1, #self.table_help_value do
              sum = sum+self:getCardNiuValue(self.table_help_value[j])
           end
           if #self.table_help_value>0 then
              self.table_text[i]:setString(tostring(sum))
           else
              self.table_text[i]:setString("")
           end
        end
    end
    
end

function CardUIManager:helpTableRemove(value)
    for i=1, #self.table_help_value do
        if value==self.table_help_value[i] then
            table.remove(self.table_help_value, i)
            break
        end
    end
end


    --获取UICard
function CardUIManager:getUICard(chair, last_state)
    return ViewHelp.getUIObject(chair, self.table_ui_card, last_state)
end


    --获取Card对应的显示字符
function CardUIManager:getCardString(value)
    local low = value%16%13
    if low<10 then
        return tostring(low+1)
    elseif low==10 then
        return "J"
    elseif low==11 then
        return "Q"
    else
        return "K"
    end
end

    --获取Card对应的牛计算值
function CardUIManager:getCardNiuValue(value)
    local low = value%16%13
    if low+1>=10 then
        return 10
    else
        return low+1
    end
end
    --判断自己的牌是否有牛
function CardUIManager:getTableCardNiuValue()
    for i=1, #self.table_card_value-2 do
        for j=i+1, #self.table_card_value-1 do
            for k=j+1, #self.table_card_value do
                local tmp_sum = self:getCardNiuValue(self.table_card_value[i])+self:getCardNiuValue(self.table_card_value[j])+self:getCardNiuValue(self.table_card_value[k])
                if tmp_sum%10==0 then
                   local tmp_table  = {self.table_card_value[i], self.table_card_value[j], self.table_card_value[k]}
                   return true, tmp_table
                end
            end
        end
    end
    return false, nil
end

    --判断选中的牌是否有牛
function CardUIManager:isNiuValue()
    if self:isFull()==false then
       return false
    end
    local sum = 0
    for i=1, 5 do
       if self.table_select_card[i]~=nil then
          sum = sum+self:getCardNiuValue(self.table_card_value[i])
       end
    end
    if sum%10==0 then
       return true
    end
    return false
end

    --判断被选中的牌是否满3张
function CardUIManager:isFull()
   local full = 0
   for i=1, 5 do
       if self.table_select_card[i]~=nil then
          full = full+1
       end
   end
   if full>=3 then
      return true
   end
   return false
end

    --判断某张牌是否被选中
function CardUIManager:isSelect(Image_card)
    
   for i=1, 5 do
      if Image_card==self.table_select_card[i] then
         return true
      end
   end
   return false
end

    --设置牌背显示颜色
function CardUIManager:setCardStatu(ui_card, color,compelete)
   ui_card:setVisible(true)
   for i=1, 5 do
        local Image_card = ui_card:getChildByName("Image_card_"..(i-1))
        Image_card:setColor(color)
        Image_card:setVisible(true)
   end
   local Image_compelete = ui_card:getChildByName("Image_compelete")
   Image_compelete:setVisible(compelete)
end


    --设置自己当前发下的牌
function CardUIManager:setCalculateCard(table_card)
    self:initCalculateCard()
    local sum = 0
    local isWuXiaoNiu = true
    local isHua = true
    local isZha = true
    local isSuper = nil
    local zha_tmp_1 = {value = table_card[1]%16%13+1, count=0}
    local zha_tmp_2 = {value = table_card[2]%16%13+1, count=0}
    for i=1, #table_card do
        local niu_value = table_card[i]%16%13+1
        if niu_value>5 then
            isWuXiaoNiu = false
        end
        if niu_value<=10 then
            isHua = false
        end
        if zha_tmp_1.value==niu_value then
           zha_tmp_1.count = zha_tmp_1.count+1
        end
        if zha_tmp_2.value==niu_value then
           zha_tmp_2.count = zha_tmp_2.count+1
        end
        sum = sum+niu_value
    end
    if zha_tmp_1.count<4 and zha_tmp_2.count<4 then
       isZha = false
    end
    local Button_super_niu = self.Panel_calculate:getChildByName("Button_super_niu")
    local Image_font = Button_super_niu:getChildByName("Image_font")
    if sum<=10 and isWuXiaoNiu==true then
        isSuper = true
        Image_font:loadTexture("game_res/90010500/gameScene/game_has_xiaoniu.png")
    elseif isHua==true then
        isSuper = true
        Image_font:loadTexture("game_res/90010500/gameScene/game_has_jinniu.png")
    elseif isZha==true then
        isSuper = true
        Image_font:loadTexture("game_res/90010500/gameScene/game_has_zha.png")
    end
    self:setCardOpenEnable(true, isSuper)
    for i=1, 5 do
        self.table_card_value[i] = table_card[i]
        local low = table_card[i]%16%13
        local hight = (table_card[i]-table_card[i]%16)/16
        local Image_card = self.Panel_calculate:getChildByName("Image_card_"..(i-1))
        Image_card:loadTexture("game_res/90010500/card/card_"..tostring(hight).."_"..tostring(low)..".png")
        Image_card:setPositionY(110)
        Image_card:setVisible(true)
    end
end

function CardUIManager:initCalculateCard()
    self.Panel_calculate:setVisible(true)
    self:setCardOpenEnable(false)
    self.table_select_card = {nil, nil, nil, nil, nil}
    self.table_card_value  = {}
    self.table_help_value  = {}
    self.last_select_idx = -1
    for i=1, #self.table_text do
        self.table_text[i]:setString("")
    end
end


    --设置是否可以开牌
function CardUIManager:setCardOpenEnable(enable, isSuper)
    local Image_help_bg = self.Panel_calculate:getChildByName("Image_help_bg")
    Image_help_bg:setVisible(enable)
    local Button_help = self.Panel_calculate:getChildByName("Button_help")
    Button_help:setVisible(enable)
    local Button_has_niu = self.Panel_calculate:getChildByName("Button_has_niu")
    Button_has_niu:setVisible(enable)
    local Button_no_niu = self.Panel_calculate:getChildByName("Button_no_niu")
    Button_no_niu:setVisible(enable)
    local Button_super_niu = self.Panel_calculate:getChildByName("Button_super_niu")
    Button_super_niu:setVisible(enable)
    if isSuper then
        Image_help_bg:setVisible(false)
        Button_help:setVisible(false)
        Button_has_niu:setVisible(false)
        Button_no_niu:setVisible(false)
    else
        Button_super_niu:setVisible(false)
    end
end

    --发牌57
function CardUIManager:game_card_send(resp_table, animate)
    self.game_card_send_resp_table = resp_table
    self:game_card_send_start(resp_table, animate)
end

function CardUIManager:game_card_send_start(resp_table, animate)
    self:ui_open()
    for i=1,  #self.table_ui_card do
        self.table_ui_card[i]:setVisible(false)
    end
    if animate then
        self:game_card_send_animate(resp_table)
    else
        for key, var in pairs(resp_table) do
            self:set_card_send(key, var)
        end
    end
end

--发牌动画
function CardUIManager:game_card_send_animate(resp_table)
    self.ui_root:getTimerUIManager():setEnable(false)
    self.table_animate_data = {}
    local banker_chair = ViewHelp.getBankerChair()
    for i=1, 5 do
        if resp_table[(banker_chair+i)%5]~=nil then
           local _animate_data = {}
           _animate_data.chair = (banker_chair+i)%5
           _animate_data.cards = resp_table[(banker_chair+i)%5]
           table.insert(self.table_animate_data, #self.table_animate_data+1, _animate_data)
        end
    end
    if #self.table_animate_data>0 then
       self:card_send_animate_controll(self.table_animate_data[1])
       table.remove(self.table_animate_data, 1)
    end
end

--发牌动画控制
function CardUIManager:card_send_animate_controll(table_card_data)

    Music:playEffect("game_res/90010500/sound/game/game_send_card.mp3", false)
    if table_card_data.chair~=ViewHelp.getSelfPlayer().chair then
        self:other_card_send_animate(table_card_data)
    else
        self:self_card_send_animate(table_card_data)
    end
end

--自己的发牌动画
function CardUIManager:self_card_send_animate(table_card_data)
    
    self:initCalculateCard()
    for i=1, 5 do
       local low = table_card_data.cards[i]%16%13
       local hight = (table_card_data.cards[i]-table_card_data.cards[i]%16)/16
       local Image_card = self.Panel_calculate:getChildByName("Image_card_"..(i-1))
       Image_card:loadTexture("game_res/90010500/card/card_"..tostring(hight).."_"..tostring(low)..".png")
       Image_card:setVisible(false)
       Image_card:setPositionY(110)

       local sprite_default = cc.Sprite:create("game_res/90010500/card/card_default.png")
       sprite_default:setPosition(600+i*20, 340)
       sprite_default:setScale(0.8)
       self.ui_root:getAnimatePanel():addChild(sprite_default)

       local delayTime = cc.DelayTime:create(0.05*(i-1))
       local fadeIn = cc.FadeIn:create(0.05*(i-1))
       local spawn_in = cc.Spawn:create(delayTime, fadeIn)

       local moveTo = cc.MoveTo:create(0.4, cc.p(348.00+(i-1)*20, 110))
       local easeIn = cc.EaseIn:create(moveTo, 2.5)
       local scaleTo = cc.ScaleTo:create(0.4, 1.0)
       local spawn_move = cc.Spawn:create(moveTo, easeIn, scaleTo)


       local moveTo_end = cc.MoveTo:create(0.4, cc.p(348.00+145*(i-1), 110))
       local scaleTo_end = cc.ScaleTo:create(0.4, 180/74*0.75, 248/97*0.75)
       local spawn_end = cc.Spawn:create(moveTo_end, scaleTo_end)

       local callfunc = cc.CallFunc:create(function()
           if i==5 then
                if #self.table_animate_data>0 then
                    self:card_send_animate_controll(self.table_animate_data[1])
                    table.remove(self.table_animate_data, 1)
                else
                    self.ui_root:getTimerUIManager():setEnable(true)
                end
                self:set_card_send(table_card_data.chair, table_card_data.cards)
            end
            sprite_default:removeFromParent()
            Image_card:setVisible(true)
        end)
        local sequence = cc.Sequence:create(spawn_in, spawn_move, spawn_end, callfunc)
        sprite_default:runAction(sequence)
    end
end

--其他玩家的发牌动画
function CardUIManager:other_card_send_animate(table_card_data)

   local ui_card = self:getUICard(table_card_data.chair)
   ui_card:setVisible(true)
   self:setCardStatu(ui_card, cc.c3b(255, 255, 255),false)
   for i=1, 5 do
        local Image_card = ui_card:getChildByName("Image_card_"..(i-1))
        Image_card:setVisible(false)
        local sprite_default = cc.Sprite:create("game_res/90010500/card/card_default.png")
        if ui_card==self.table_ui_card[2] then
            sprite_default:setPosition(640-i*20, 340)
        else
           sprite_default:setPosition(600+i*20, 340)
        end
        sprite_default:setScale(0.8)
        self.ui_root:getAnimatePanel():addChild(sprite_default)
        local moveTo = cc.MoveTo:create(0.25, cc.p(Image_card:getPositionX(), Image_card:getPositionY()))
        local easeIn = cc.EaseIn:create(moveTo, 2.5)
        local scaleTo = cc.ScaleTo:create(0.25, 1.0)

        local spawn_move = cc.Spawn:create(moveTo, easeIn, scaleTo)

        local delayTime = cc.DelayTime:create(0.05*(i-1))
        local fadeIn = cc.FadeIn:create(0.05*(i-1))
        local spawn_in = cc.Spawn:create(delayTime, fadeIn)

        local callfunc = cc.CallFunc:create(function()
            if i==5 then
                if #self.table_animate_data>0 then
                   self:card_send_animate_controll(self.table_animate_data[1])
                   table.remove(self.table_animate_data, 1)
                else
                   self.ui_root:getTimerUIManager():setEnable(true)
                end
             end
             sprite_default:removeFromParent()
             Image_card:setVisible(true)
         end)
         local sequence = cc.Sequence:create(spawn_in, spawn_move, callfunc)
         sprite_default:runAction(sequence)  
    end
end


    --发牌设置
function CardUIManager:set_card_send(chair, table_card)

    self:ui_open()
    if chair==ViewHelp.getSelfPlayer().chair then
        self:setCalculateCard(table_card)
    else
        local ui_card = self:getUICard(chair)
        self:setCardStatu(ui_card, cc.c3b(255, 255, 255),false)
    end
    
end

    --游戏开始开牌
function CardUIManager:game_card_open(resp_table)
    self:setHelpText()
end

    --玩家开牌
function CardUIManager:player_card_open(resp_table)

   table.insert(self.player_card_open_resp_table, #self.player_card_open_resp_table+1, resp_table)
   self:ui_open()
   self:player_card_open_start(resp_table)
end

function CardUIManager:player_card_open_start(resp_table)

   if ViewHelp.getSelfPlayer().chair==resp_table.chair  then
      self.Panel_calculate:setVisible(false)
   end
   local ui_card = self:getUICard(resp_table.chair)
   self:setCardStatu(ui_card, cc.c3b(125, 125, 125),true)

end


    -- 有玩家坐下
function CardUIManager:playerSitDesk( user_info )
   
    if ViewHelp.getBasePosUserID()~=tonumber(user_info.userID) then
        return
    end
    self.ui_root:getAnimatePanel():removeAllChildren()
    if self.game_card_send_resp_table~=nil then
       self:game_card_send_start(self.game_card_send_resp_table)
    end
    for i=1, #self.player_card_open_resp_table  do
        self:player_card_open_start(self.player_card_open_resp_table[i])
    end
   
end

function CardUIManager:game_card_data_clear()
   self.game_card_send_resp_table = nil
   self.player_card_open_resp_table = {}
end


function CardUIManager:game_end_clear()
   self:ui_close()
end

function CardUIManager:ui_open()
    self.ui_project:setVisible(true)
end

function CardUIManager:ui_close()
    self.ui_project:setVisible(false)
end

return CardUIManager

--endregion
