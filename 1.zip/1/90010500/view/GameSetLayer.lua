--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local SET_CLOSE = 0
local SET_OPEN = 1


local GameSetLayer = class("GameSetLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/GameSetLayer.csb")
end)

function GameSetLayer:ctor()
	

    local Panel_root = self:getChildByName("Panel_root")
    self.Image_root = Panel_root:getChildByName("Image_root")
    api_action_showPageLayer( self.Image_root )
    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end)

            --背景音乐
    local Button_music_0 = self.Image_root:getChildByName("Button_music_0")
    local Button_music_1 = self.Image_root:getChildByName("Button_music_1")
    self:ButtonToggle( Button_music_0 , Button_music_1 , UserData:getMusic() , function(cur_state)
            UserData:setMusic( cur_state )
            if cur_state == 1 then
                Music:playMusic()
            else
                Music:stopMusic()
            end
        end )

            --游戏音效
    local Button_effect_0 = self.Image_root:getChildByName("Button_effect_0")
    local Button_effect_1 = self.Image_root:getChildByName("Button_effect_1")
    self:ButtonToggle( Button_effect_0 , Button_effect_1 , UserData:getSound() , function(cur_state)
            UserData:setSound( cur_state )
        end )

            --震动效果
    local Button_vibration_0 = self.Image_root:getChildByName("Button_vibration_0")
    local Button_vibration_1 = self.Image_root:getChildByName("Button_vibration_1")
    self:ButtonToggle( Button_vibration_0 , Button_vibration_1 , UserData:getVibration() , function(cur_state)
            UserData:setVibration(cur_state)
        end)

            --语音播放
    local Button_voice_0 = self.Image_root:getChildByName("Button_voice_0")
    local Button_voice_1 = self.Image_root:getChildByName("Button_voice_1")
    self:ButtonToggle( Button_voice_0 , Button_voice_1 , UserData:getAutoPlaySound() , function(cur_state)
           UserData:setAutoPlaySound( cur_state )
        end)

            --自动坐下
    local Button_seat_down_0 = self.Image_root:getChildByName("Button_seat_down_0")
    local Button_seat_down_1 = self.Image_root:getChildByName("Button_seat_down_1")
    self:ButtonToggle( Button_seat_down_0 , Button_seat_down_1 , UserData:getAutoSitDesk() , function(cur_state)
            UserData:setAutoSitDesk( cur_state )
        end)

            --自动准备
    local Button_ready_0 = self.Image_root:getChildByName("Button_ready_0")
    local Button_ready_1 = self.Image_root:getChildByName("Button_ready_1")
    self:ButtonToggle( Button_ready_0 , Button_ready_1 , UserData:getAutoAgree() , function(cur_state)
            UserData:setAutoAgree( cur_state )
        end)


    self:registerScriptHandler(handler(self,self.onNodeEvent))

end

function GameSetLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end

function GameSetLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
    elseif event == "exit" then
        g_popBombBox(self)
    end

end

function GameSetLayer:writeToLocal(key, cur_state)
    g_gameLocalSet[key] = cur_state
    cc.UserDefault:getInstance():setIntegerForKey(key, cur_state)
    cc.UserDefault:getInstance():flush()
end

function GameSetLayer:ButtonToggle(Button_close, Button_open, cur_state, function_call)
    Button_close:addClickEventListener(function()
        function_call(SET_OPEN)
        Button_open:setVisible(true)
        Button_close:setVisible(false)
    end)
    Button_open:addClickEventListener(function()
        function_call(SET_CLOSE)
        Button_open:setVisible(false)
        Button_close:setVisible(true)
    end)
    if cur_state==SET_OPEN then
        Button_open:setVisible(true)
        Button_close:setVisible(false)
    end
    if cur_state==SET_CLOSE then
        Button_open:setVisible(false)
        Button_close:setVisible(true)
    end
end

return GameSetLayer

--endregion
