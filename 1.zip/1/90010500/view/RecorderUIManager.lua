--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local RecorderUIManager = class("RecorderUIManager")

function RecorderUIManager:ctor(ui_project)

    self.ui_project = ui_project
    self.Text_time = ui_project:getChildByName("Text_time")
    self.Text_time:setString("")

end


function RecorderUIManager:start_recorder(call_function)
    
    self:ui_open()
    self.Text_time:setString("")
    if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
    end
    local time = 0
    self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
        time = time+1
        self.Text_time:setString(tostring(time).."'")
        if time>= g_config.recorder_max_time then
            self:stop_recorder()
            if call_function~=nil then
               call_function()
            end
        end
     end,
     1.0, 
     false)

end

function RecorderUIManager:stop_recorder()
    
    self:ui_close()
    self:clearSchedule()
end

function RecorderUIManager:clearSchedule()
    
    if self.schedule_handle~=nil then
        g_scheduler:unscheduleScriptEntry(self.schedule_handle)
    end
end

function RecorderUIManager:ui_open()
    self.ui_project:setVisible(true)
end

function RecorderUIManager:ui_close()
    self.ui_project:setVisible(false)
end

return RecorderUIManager

--endregion
