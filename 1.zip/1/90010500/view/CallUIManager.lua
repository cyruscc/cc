--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local CallUIManager = class("CallUIManager")
local GameSceneModule = import('..GameSceneModule')

local CALL_NONE = 0
local CALL_READY = 1
local CALL_BANKER = 2
local CALL_BET = 3



function CallUIManager:ctor(ui_project, ui_root)

    self.ui_project = ui_project
    self.ui_root = ui_root

    self.Button_ready = ui_project:getChildByName("Button_ready")
    self.Button_ready:addClickEventListener(function()
        GameSceneModule:request_player_ready()
        self.Button_ready:setVisible(false)
    end
    )

    self.Button_call_banker = ui_project:getChildByName("Button_call_banker")
    self.Button_call_banker:addClickEventListener(function()

        GameSceneModule:request_player_banker(ViewHelp.getSelfPlayer().chair, true)
        self:ui_close()
    end
    )

    self.Button_no_call = ui_project:getChildByName("Button_no_call")
    self.Button_no_call:addClickEventListener(function()

        GameSceneModule:request_player_banker(ViewHelp.getSelfPlayer().chair, false)
        self:ui_close()
    end
    )

    self.Panel_bet_call = ui_project:getChildByName("Panel_bet_call")

    local Text_multiply = self.Panel_bet_call:getChildByName("Text_multiply")
    Text_multiply:setVisible(false)

    self.Panel_point_call = ui_project:getChildByName("Panel_point_call")
    self.Panel_point_call:setVisible(false)
    
end

function CallUIManager:hideReday()
    self.Button_ready:setVisible( false )
end

function CallUIManager:deskStart(user_info)
   if UserData:getAutoAgree()==1 and ViewHelp.getSelfPlayer().chair>=0 then
       GameSceneModule:request_player_ready()
   else
       self:ui_open()
       self:game_ready()
   end
end


function CallUIManager:setBetButton(index, max_multiply)
    
    if not index or index>max_multiply or index<=0 then
       index = 1
    end
    local Text_multiply = self.Panel_bet_call:getChildByName("Text_multiply")
    Text_multiply:setString(tostring(index))
    for i=1, 4 do
        local Button_bet = self.Panel_bet_call:getChildByName("Button_bet_"..(i-1))
        local Image_select = Button_bet:getChildByName("Image_select")
        Button_bet:addClickEventListener(function()
           self:setHideAllImageSelect()
           Image_select:setVisible(true)
           Text_multiply:setString(tostring(i))
        end)
        Button_bet:setTouchEnabled(true)
        Button_bet:setBright(true)
        if index==i then
            Image_select:setVisible(true)
        else
            Image_select:setVisible(false)
        end
        if max_multiply~=nil then
           if i>max_multiply then
              Button_bet:setTouchEnabled(false)
              Button_bet:setBright(false)
           end
        end
    end
end


function CallUIManager:setPointButton(note)
    
    for i=1, #note do
        if note[i] then
           local Button_point = self.Panel_point_call:getChildByName("Button_point_"..i-1)
           Button_point:addClickEventListener(function()
               GameSceneModule:request_player_bet(ViewHelp.getSelfPlayer().chair, note[i])
           end)
           local Text_point = Button_point:getChildByName("Text_point")
           Text_point:setString(tostring(note[i]))
        end
    end
    

end

function CallUIManager:setHideAllImageSelect()
    for i=1, 4 do
        local Button_bet = self.Panel_bet_call:getChildByName("Button_bet_"..(i-1))
        local Image_select = Button_bet:getChildByName("Image_select")
        Image_select:setVisible(false)
    end
end

function CallUIManager:game_ready()

    self:ui_open()
    local desk_config =  ViewHelp.getDeskConfig()
    if desk_config.activated==false  or ViewHelp.getSelfPlayer().chair<0 then
       self:ui_close()
       return
    end
    self:setCallStatus(CALL_READY)
end

function CallUIManager:game_end_ready(resp_table)

   for key, var in pairs(resp_table) do
      if key==ViewHelp.getSelfPlayer().chair then
         if UserData:getAutoAgree()==1 then
            GameSceneModule:request_player_ready()
         else
            self:ui_open()
            self:setCallStatus(CALL_READY) 
         end
         break
      end
   end
   
end

function CallUIManager:game_banker_notify(resp_table)
    self:ui_open()
    if resp_table.chair==ViewHelp.getSelfPlayer().chair then
        self:setCallStatus(CALL_BANKER)
    else
        self:ui_close()
    end
end

    --玩家叫庄结果
function CallUIManager:player_banker(resp_table)

    if resp_table.chair==ViewHelp.getSelfPlayer().chair then
        self:ui_close()
    end
end


    --玩家下注
function CallUIManager:game_bet_notify(resp_table)
    local isSelfBet = false
    for i=1, #resp_table.betItems do
       if resp_table.betItems[i].chair==ViewHelp.getSelfPlayer().chair and ViewHelp.getSelfPlayer().chair>=0 then
          self:ui_open()
          self:setCallStatus(CALL_BET)
          if ViewHelp.getDeskConfig().config.NoteType==1 then
              self:setPointButton(resp_table.betItems[i].note)
              self.ui_root:getTimerUIManager():startTimer(resp_table.betTime,               
              function()
                 self:ui_close()
              end)
          else
              self:setBetButton(ViewHelp.getLastMutiply(), resp_table.betItems[i].multiply)
              self.ui_root:getTimerUIManager():startTimer(resp_table.betTime-1, 
              function()
                 local Text_multiply = self.Panel_bet_call:getChildByName("Text_multiply")
                 local multiplying = tonumber(Text_multiply:getStringValue())
                 GameSceneModule:request_player_bet(ViewHelp.getSelfPlayer().chair, multiplying)
              end)
          end
          isSelfBet = true
          break
       end
    end
    if isSelfBet==false then
       self.ui_root:getTimerUIManager():startTimer(resp_table.betTime, nil, "等待玩家下注...")
    end
end

function CallUIManager:player_bet(resp_table)

    if resp_table.chair==ViewHelp.getSelfPlayer().chair then
        if ViewHelp.getDeskConfig().config.NoteType==0 then
           ViewHelp.setLastMutiply(resp_table.multiplying)
           
        end
        self:ui_close()
     end

end

function CallUIManager:game_card_send(resp_table)
    for key, var in pairs(resp_table) do
        if key==ViewHelp.getSelfPlayer().chair then
           self:ui_close()
           break
        end
    end
end


function CallUIManager:playerStandUp( user_info )

    if user_info.userID==ViewHelp.getBasePosUserID() then
        self:ui_close()
    end
end

function CallUIManager:setCallStatus(status)

    self.Button_ready:setVisible(status==CALL_READY)
    self.Button_call_banker:setVisible(status==CALL_BANKER)
    self.Button_no_call:setVisible(status==CALL_BANKER)
    if ViewHelp.getDeskConfig().config.NoteType==1 then
       self.Panel_point_call:setVisible(status==CALL_BET)
       self.Panel_bet_call:setVisible(false)
    else
       self.Panel_bet_call:setVisible(status==CALL_BET)
       self.Panel_point_call:setVisible(false)
    end

end


function CallUIManager:ui_open()
    self.ui_project:setVisible(true)
end

function CallUIManager:ui_close()
    self.ui_project:setVisible(false)
end

return CallUIManager

--endregion
