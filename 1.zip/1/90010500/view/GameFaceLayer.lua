--region *.lua
--Date
--此文件由[BabeLua]插件自动生成



--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local GameFaceLayer = class("GameFaceLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/GameFaceLayer.csb")
end)

function GameFaceLayer:ctor()

    local Panel_root = self:getChildByName("Panel_root")
    Panel_root:addClickEventListener(function()
        self:recvKeyBack()
    end)

    local Image_root = Panel_root:getChildByName("Image_root")

    local ScrollView = Image_root:getChildByName("ScrollView")

    for i=1, 15 do
       local Button_face = Image_root:getChildByName("Button_face_"..i-1)
       Button_face:addClickEventListener(function()
            if ViewHelp.getSelfPlayer().chair>=0 then
               ViewHelp.getGameScene():reqChat(i)
            end
            self:recvKeyBack()
        end)
    end

    self:registerScriptHandler(handler(self,self.onNodeEvent))

end

function GameFaceLayer:recvKeyBack()
    self:removeFromParent()
end

function GameFaceLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
    elseif event == "exit" then
        g_popBombBox(self)
    end

end



return GameFaceLayer



--endregion




--endregion
