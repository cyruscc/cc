--region *.lua
--Date
--此文件由[BabeLua]插件自动生成



--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local STATE_ALLOW = 0
local STATE_FORBIT = 1

local CallOwnerLayer = import('.CallOwnerLayer')

local RoomInforLayer = class("RoomInforLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/RoomInforLayer.csb")
end)

function RoomInforLayer:ctor(parent)

    local desk_config =  ViewHelp.getDeskConfig()

    local Panel_root = self:getChildByName("Panel_root")
    self.Image_root = Panel_root:getChildByName("Image_root")
    api_action_showPageLayer( self.Image_root )

    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end)
        --底注
    local Image_base = self.Image_root:getChildByName("Image_base")
    local Text_base = Image_base:getChildByName("Text_base")
    Text_base:setString(tostring(desk_config.config.antes))
        --局数
    local Image_board = self.Image_root:getChildByName("Image_board")
    local Text_board = Image_board:getChildByName("Text_board")
    Text_board:setString(desk_config.progress.."/"..desk_config.config.maxRounds)
        --房间名称
    local Image_name = self.Image_root:getChildByName("Image_name")
    local Text_name = Image_name:getChildByName("Text_name")
    Text_name:setString( FromBase64New(desk_config.roomName))

        --初始分数
    local Image_begin = self.Image_root:getChildByName("Image_begin")
    local Text_begin = Image_begin:getChildByName("Text_begin")
    Text_begin:setString(tostring(desk_config.initPoints))

        --房主名称
    local Image_owner = self.Image_root:getChildByName("Image_owner")
    local Text_owner = Image_owner:getChildByName("Text_owner")
    Text_owner:setString( api_get_ascll_sub_str_by_ui(desk_config.mastUserNick , 14))
        --暗号
    local Image_id = self.Image_root:getChildByName("Image_id")
    local Text_id = Image_id:getChildByName("Text_id")
    Text_id:setString(tostring(desk_config.roomKey))

    local Image_time = self.Image_root:getChildByName("Image_time")
    self.Text_time = Image_time:getChildByName("Text_time")
    self:setTextTime()

    local desk_player = ViewHelp.getDeskPlayerMap()
    local viewer_player = ViewHelp.getViewerPlayerMap()
    local desk_player_count = self:getTableSize(desk_player)
    local viewer_player_count = self:getTableSize(viewer_player)
        --玩家
    local Image_player = self.Image_root:getChildByName("Image_player")
    local Text_player = Image_player:getChildByName("Text_player")
    Text_player:setString(tostring(desk_player_count+viewer_player_count).."/"..tostring(desk_config.holdUsersNum))

        --房间描述
    local Panel_desc = self.Image_root:getChildByName("Panel_desc")
    local Text_desc = Panel_desc:getChildByName("Text_desc")

    local desc_text = ""
    local niu_table_text = {"无牛X", "牛丁X", "牛二X", "牛三X", "牛四X", "牛五X", "牛六X", "\n牛七X", "牛八X", "牛九X", "牛牛X", "炸弹X", "金牛X", "五小牛X"}
    dump( desk_config , "desk_config" , 10 )
    for i=1, #niu_table_text do
        desc_text = desc_text..niu_table_text[i]..desk_config.config.bullPointBet[i].."  "
    end
    Text_desc:setString(desc_text)

        --分享
    local Button_share = self.Image_root:getChildByName("Button_share")
    Button_share:addClickEventListener(function()
        lua_to_plat:wx_share_to_session( "招脚来斗牛" , "我在私人房间里玩牛牛，房号："..tostring(desk_config.roomKey).."。人多热闹，都来一起玩吧！" , get_download_url() , function (args)
            local table_value = lua_to_plat:get_ret_table(args)
            if table_value.ret == 1 then
                print("分享至微信会话窗口成功！")
            else
                print("分享至微信会话窗口失败！")
            end
           
        end)
    end)

        --解散房间
    local Button_release = self.Image_root:getChildByName("Button_release")
    Button_release:addClickEventListener(function()
        local function relase_groom()
            ViewHelp.getGameScene():reqDissmisDesk(0)
        end
        Msg:showMsg(2, "是否解散房间?", relase_groom)
    end)

        --联系房主
    local Button_call_owner = self.Image_root:getChildByName("Button_call_owner")
    Button_call_owner:addClickEventListener(function()
        parent:addChild(CallOwnerLayer:create())
    end)

            --禁止加入
    local Button_forbit_enter = self.Image_root:getChildByName("Button_forbit_enter")
    local state_enter = STATE_FORBIT
    if desk_config.allowEnter==false  then
       state_enter = STATE_ALLOW
       Button_forbit_enter:loadTextureNormal("game_res/90010500/btn/green_3_normal.png")
       Button_forbit_enter:loadTexturePressed("game_res/90010500/btn/green_3_press.png")
    end
    self:setButtonState(Button_forbit_enter,
    "允许加入",
    "禁止加入",
    state_enter,
    function(isOpen)
        if args==true then
            Button_forbit_enter:loadTextureNormal("game_res/90010500/btn/blue_1_normal.png")
            Button_forbit_enter:loadTexturePressed("game_res/90010500/btn/blue_1_press.png")
        else
            Button_forbit_enter:loadTextureNormal("game_res/90010500/btn/green_3_normal.png")
            Button_forbit_enter:loadTexturePressed("game_res/90010500/btn/green_3_press.png")
        end
        ViewHelp.getGameScene():reqChangeEnterDeskSwitch(isOpen)
    end)

        --禁止聊天
    local Button_forbit_chat = self.Image_root:getChildByName("Button_forbit_chat")
    local state_chat = STATE_FORBIT
    if desk_config.allowChat==false  then
       state_chat = STATE_ALLOW
       Button_forbit_chat:loadTextureNormal("game_res/90010500/btn/green_3_normal.png")
       Button_forbit_chat:loadTexturePressed("game_res/90010500/btn/green_3_press.png")
    end
    self:setButtonState(Button_forbit_chat,
    "允许聊天",
    "禁止聊天",
    state_chat,
    function(isOpen)
        if args==true then
            Button_forbit_chat:loadTextureNormal("game_res/90010500/btn/blue_1_normal.png")
            Button_forbit_chat:loadTexturePressed("game_res/90010500/btn/blue_1_press.png")
        else
            Button_forbit_chat:loadTextureNormal("game_res/90010500/btn/green_3_normal.png")
            Button_forbit_chat:loadTexturePressed("game_res/90010500/btn/green_3_press.png")
        end
        ViewHelp.getGameScene():reqChangeChatSwitch(isOpen)
    end)
    

    if desk_config.mastUserID==ViewHelp.getBasePosUserID() then
        Button_call_owner:setTouchEnabled(false)
        Button_call_owner:setBright(false)
    else
        Button_release:setTouchEnabled(false)
        Button_release:setBright(false)
        Button_forbit_enter:setTouchEnabled(false)
        Button_forbit_enter:setBright(false)
        Button_forbit_chat:setTouchEnabled(false)
        Button_forbit_chat:setBright(false)
    end
    self:registerScriptHandler(handler(self,self.onNodeEvent))

end

function RoomInforLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end

function RoomInforLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
        self.schedule_handle = g_scheduler:scheduleScriptFunc(function()
           self:setTextTime()
           if ViewHelp.getDeskConfig().leaveTime<=0 then
               if self.schedule_handle~=nil then
                   g_scheduler:unscheduleScriptEntry(self.schedule_handle)
                   self.schedule_handle = nil
               end
            end
        end,
        1.0, 
        false)

    elseif event == "exit" then
        g_popBombBox(self)
        if self.schedule_handle~=nil then
            g_scheduler:unscheduleScriptEntry(self.schedule_handle)
            self.schedule_handle = nil
        end
    end

end

function RoomInforLayer:setTextTime()
   local desk_config  = ViewHelp.getDeskConfig()
   local time_s = desk_config.leaveTime%60
   local time_m = (desk_config.leaveTime-time_s)/60%60
   local time_h = ((desk_config.leaveTime-time_s)/60-time_m)/60
   self.Text_time:setString(string.format("%02d:%02d:%02d", time_h, time_m, time_s))
end

function RoomInforLayer:getTableSize(table_ars)
    local count = 0
    for key, var in pairs(table_ars) do
        count = count+1
    end
    return count
end

function RoomInforLayer:setButtonState(button, allow, forbit, state, func_call)
    local function setNormal(cur_state)
        if cur_state==STATE_ALLOW then
            button:setTitleText(allow)
            --button:loadTextureNormal(allow)
        end
        if cur_state==STATE_FORBIT then
            button:setTitleText(forbit)
            --button:loadTextureNormal(forbit)
        end
    end
    setNormal(state)
    button:addClickEventListener(function()
        if state==STATE_ALLOW then
            func_call(true)
            state=STATE_FORBIT
        else
            func_call(false)
            state=STATE_ALLOW
        end
        setNormal(state)
    end)
end

return RoomInforLayer



--endregion




--endregion
