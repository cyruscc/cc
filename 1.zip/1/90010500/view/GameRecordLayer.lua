--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local m_download = import("....common.download")
local GamePersonalLayer = import(".GamePersonalLayer")


local GameRecordLayer = class("GameRecordLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/GameRecordLayer.csb")
end)

function GameRecordLayer:ctor(ui_root)
    
    self.ui_root = ui_root
    local Panel_root = self:getChildByName("Panel_root")
    Panel_root:addClickEventListener(function()
        self:recvKeyBack()
    end)

    self.Image_root = Panel_root:getChildByName("Image_root")

    self.Image_root_position = {x=self.Image_root:getPositionX(), y=self.Image_root:getPositionY()}

    self.Image_root:setPositionX(self.Image_root:getPositionX()+self.Image_root:getContentSize().width)

    self.Image_root:runAction(cc.MoveBy:create(0.25, cc.p(-self.Image_root:getContentSize().width,0)))

    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end)


    self:updatreScrollView()

    self:registerScriptHandler(handler(self,self.onNodeEvent))


    local function handleUpdateScrollView(event) 
        print("handleUpdateScrollView-------------")
        self:updatreScrollView()
    end
    local eventDispatcher = self:getEventDispatcher()
    local listener = cc.EventListenerCustom:create("GameRecordLayer.handleUpdateScrollView", handleUpdateScrollView)
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)


end

function GameRecordLayer:getTableSize(table_ars)
    local count = 0
    for key, var in pairs(table_ars) do
        count = count+1
    end
    return count
end


function GameRecordLayer:updatreScrollView()

    local desk_config = ViewHelp.getDeskConfig()

    local Image_board = self.Image_root:getChildByName("Image_board")
    local Text_board = Image_board:getChildByName("Text_board")
    Text_board:setString(tostring(desk_config.progress).."/"..tostring(desk_config.config.maxRounds))

    self.ScrollView = self.Image_root:getChildByName("ScrollView")

    self.ScrollView:removeAllChildren()

    local Panel_playing = self.Image_root:getChildByName("Panel_playing")
    local Panel_see = self.Image_root:getChildByName("Panel_see")
    local Panel_itm = self.Image_root:getChildByName("Panel_itm")
    Panel_playing:setVisible(true)
    Panel_see:setVisible(true)
    Panel_itm:setVisible(true)

    local desk_player = ViewHelp.getDeskPlayerMap()
    local viewer_player = ViewHelp.getViewerPlayerMap()
    local desk_player_count = self:getTableSize(desk_player)
    local viewer_player_count = self:getTableSize(viewer_player)

    local f_sum_height = 0
    if desk_player_count>0 then
        f_sum_height = f_sum_height+desk_player_count*75+45
    end
    if viewer_player_count>0 then
        f_sum_height = f_sum_height+viewer_player_count*75+45
    end

    local f_scroll_height = 605
    if f_sum_height>f_scroll_height then
        f_scroll_height = f_sum_height
    end

    self.ScrollView:setInnerContainerSize(cc.size(640.00, f_scroll_height))

    if desk_player_count>0 then
        f_scroll_height = self:srcollViewAddChild(Panel_playing, Panel_itm, desk_player, f_scroll_height)
    end
    if viewer_player_count>0 then
        f_scroll_height = self:srcollViewAddChild(Panel_see, Panel_itm, viewer_player, f_scroll_height)
    end
    
    Panel_playing:setVisible(false)
    Panel_see:setVisible(false)
    Panel_itm:setVisible(false)
end


function GameRecordLayer:srcollViewAddChild(Panel_parent, Panel_itm, table_ars, f_scroll_height)
    local Panel_clone = Panel_parent:clone()
    Panel_clone:setPosition(0, f_scroll_height-45)
    self.ScrollView:addChild(Panel_clone)
    f_scroll_height = f_scroll_height-45
    for key, var in pairs(table_ars) do
       local itm_clone = Panel_itm:clone()
       itm_clone:setPosition(0, f_scroll_height-75)

       local Image_head = itm_clone:getChildByName("Image_head")
       m_download:get_instance():set_head_image_and_auto_update(Image_head,  var.avatarUrl, var.userID)
       Image_head:setTouchEnabled(true)
       Image_head:addClickEventListener(function()
          self.ui_root:addChild(GamePersonalLayer:create(var, self.ui_root))
          self:recvKeyBack()
       end)

       local Text_name = itm_clone:getChildByName("Text_name")
       Text_name:setString( api_get_ascll_sub_str_by_ui( var.nick , 14 ))

       local Image_num_bg = itm_clone:getChildByName("Image_num_bg")

       local Text_num = Image_num_bg:getChildByName("Text_num")
       local Text_num_str = ""
       if var.profit==0 then
            Text_num_str = tostring(var.profit)
       elseif var.profit>0 then
            Text_num_str="+"..tostring(var.profit)
       else
            Text_num_str = tostring(var.profit)
            Text_num:setTextColor(cc.RED)
       end
       Text_num:setString(Text_num_str)
  

       local Text_take_title = itm_clone:getChildByName("Text_take_title")
       local Text_take_num = Text_take_title:getChildByName("Text_take_num")
       Text_take_num:setString(tostring(var.point-var.profit))

       local Text_point_title = itm_clone:getChildByName("Text_point_title")
       local Text_point_num = Text_point_title:getChildByName("Text_point_num")
       Text_point_num:setString(tostring(var.point))

       f_scroll_height = f_scroll_height-75
       self.ScrollView:addChild(itm_clone)
    end
    return f_scroll_height
end

function GameRecordLayer:recvKeyBack()
    self.Image_root:runAction(cc.Sequence:create(cc.MoveBy:create(0.25, cc.p(self.Image_root:getContentSize().width,0)), 
    cc.CallFunc:create(function()
        self:removeFromParent()
    end)))

end

function GameRecordLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
        ViewHelp:getGameScene():register_game_record_update_call( handler(self , self.updatreScrollView) )
    elseif event == "exit" then
        g_popBombBox(self)
        ViewHelp:getGameScene():register_game_record_update_call( nil )
    end

end

return GameRecordLayer




--endregion
