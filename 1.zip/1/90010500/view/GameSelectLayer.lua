--region *.lua
--Date
--此文件由[BabeLua]插件自动生成



--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local CGameManger = import("...gamemanager")

local HelpLayer = import("..help.HelpLayer")

local GameSetLayer = import(".GameSetLayer")


local GameSelectLayer = class("GameSelectLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/GameSelectLayer.csb")
end)

function GameSelectLayer:ctor(Button_select)

    self.Button_select = Button_select

    local Panel_root = self:getChildByName("Panel_root")
    Panel_root:addClickEventListener(function()
        self:recvKeyBack()
    end)

    self.Image_root = Panel_root:getChildByName("Image_root")

    self.Button_leave = self.Image_root:getChildByName("Button_leave")
    self.Button_leave:addClickEventListener(function()

        ViewHelp.getGameScene():reqLeaveDesk()
        ViewHelp.getGameScene():Exit_game()
    end
    )
    self.Button_leave:setTouchEnabled(ViewHelp.getLeaveEnable())
    self.Button_leave:setBright(ViewHelp.getLeaveEnable())


    self.Button_stand = self.Image_root:getChildByName("Button_stand")
    self.Button_stand:addClickEventListener(function()
        if ViewHelp.getSelfPlayer().chair<0 then
           return
        end
        ViewHelp.getGameScene():reqStandupDesk()
        self:recvKeyBack()
    end
    )
   
    if ViewHelp.getSelfPlayer().chair<0 or ViewHelp.getLeaveEnable()==false then
        self.Button_stand:setTouchEnabled(false)
        self.Button_stand:setBright(false)
    end

    local Button_ruler = self.Image_root:getChildByName("Button_ruler")
    Button_ruler:addClickEventListener(function()
        self:getParent():addChild ( HelpLayer:create(ViewHelp.getDeskConfig().config.bankerType+2) )
        self:recvKeyBack()
    end
    )


    local Button_set = self.Image_root:getChildByName("Button_set")
    Button_set:addClickEventListener(function()
        self:getParent():addChild(GameSetLayer:create())
        self:recvKeyBack()
    end
    )

    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end
    )
    self:registerScriptHandler(handler(self,self.onNodeEvent))

end

function GameSelectLayer:recvKeyBack()
    self:removeFromParent()
end


function GameSelectLayer:setLeaveEnable(enable)
    self.Button_leave:setTouchEnabled(enable)
    self.Button_leave:setBright(enable)
end

function GameSelectLayer:setStandEnable(enable)
    self.Button_stand:setTouchEnabled(enable)
    self.Button_stand:setBright(enable)
end

function GameSelectLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
        self.Button_select:setVisible(false)
    elseif event == "exit" then
        g_popBombBox(self)
        self.Button_select:setVisible(true)
    end

end



return GameSelectLayer



--endregion




--endregion
