--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local percent_num = 100

local SliderNode = class("SliderNode", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/call/SliderNode.csb")
end)

function SliderNode:ctor(delegate, min_number, max_number, start_positionX, positionY, end_positionX)
    
    self.delegate = delegate

    self.Image_slider = self:getChildByName("Image_slider")
    self.Text_slider = self.Image_slider:getChildByName("Text_slider")

    if min_number~=nil then
       self.min_number = min_number
    else
       self.min_number = 0
    end
    self.Text_slider:setString(tostring(self.min_number))

    if max_number~=nil then
       self.max_number = max_number
    else
       self.max_number = 100
    end

    if start_positionX~=nil then
       self.start_positionX = start_positionX
       self.Image_slider:setPositionX(start_positionX)
    else
       self.start_positionX = self.Image_slider:getPositionX()
    end

    if positionY~=nil then
       self.Image_slider:setPositionY(positionY)
    end

    if end_positionX~=nil then
       self.end_positionX = end_positionX
    else
       self.end_positionX = 720
    end

    local touch_listener = cc.EventListenerTouchOneByOne:create()
    touch_listener:setSwallowTouches(false) 
    touch_listener:registerScriptHandler(handler(self, self.onTouchBegan), cc.Handler.EVENT_TOUCH_BEGAN)
    touch_listener:registerScriptHandler(handler(self, self.onTouchMoved), cc.Handler.EVENT_TOUCH_MOVED)        
    touch_listener:registerScriptHandler(handler(self, self.onTouchEnded), cc.Handler.EVENT_TOUCH_ENDED)  
    touch_listener:registerScriptHandler(handler(self, self.onTouchCancelled), cc.Handler.EVENT_TOUCH_CANCELLED)      
    local eventDispatcher = self:getEventDispatcher()      
    eventDispatcher:addEventListenerWithSceneGraphPriority(touch_listener, self) 

    self:registerScriptHandler(handler(self,self.onNodeEvent))

end

function SliderNode:onTouchBegan(touch, event)

    local p = self.Image_slider:convertToNodeSpace(touch:getLocation())
    local  rect = cc.rect(0, 0, self.Image_slider:getContentSize().width, self.Image_slider:getContentSize().height)
    if cc.rectContainsPoint(rect, p) then
		
        self.begin_p = self:convertToNodeSpace(touch:getLocation())
        return true
    end 
    return false
end

function SliderNode:onTouchMoved(touch, event)
    local end_p = self:convertToNodeSpace(touch:getLocation())
    local p = self.Image_slider:convertToNodeSpace(touch:getLocation())
    local moveX = end_p.x-self.begin_p.x
    self.begin_p = end_p
    local current_positionX = self.Image_slider:getPositionX()+moveX
    local percent = 0
    if current_positionX<=self.start_positionX then
        self.Image_slider:setPositionX(self.start_positionX)
        percent = 0
    elseif current_positionX>=self.end_positionX then
        self.Image_slider:setPositionX(self.end_positionX)
        percent = 1
    else
        self.Image_slider:setPositionX(current_positionX)
        percent = (current_positionX-self.start_positionX)/(self.end_positionX-self.start_positionX)
    end
    self.Text_slider:setString(tostring(self:floatToInt(percent*percent_num)*(self.max_number/percent_num)))
    if self.delegate~=nil then
       
       self.delegate(percent, self:floatToInt(percent*percent_num)*(self.max_number/percent_num))
    end
end

function SliderNode:onTouchEnded(touch, event)
    
end

function SliderNode:onTouchCancelled(touch, event)

end


function SliderNode:setSliderPencent(percent)
   if not percent then
      return
   end
   if percent<0 then
      percent = 0
   end
   if percent>1 then
      percent = 1
   end
   self.Image_slider:setPositionX(self.start_positionX+(self.end_positionX-self.start_positionX)*percent)
   if self.delegate~=nil then
       self.delegate(percent, self:floatToInt(percent*percent_num)*(self.max_number/percent_num))
   end
end

function SliderNode:setStartPositionX(start_positionX)
    if start_positionX~=nil then
       self.start_positionX = start_positionX
       self.Image_slider:setPositionX(start_positionX)
    end
end
function SliderNode:setPositionY(positionY)
    if positionY~=nil then
       self.Image_slider:setPositionY(positionY)
    end
end

function SliderNode:setEndPositionX(end_positionX)
    if end_positionX~=nil then
       self.end_positionX = end_positionX
    end
end

function SliderNode:setMinNumber(min_number)
    if min_number~=nil then
       self.min_number = min_number
    end
end

function SliderNode:setMaxNumber(max_number)
    if max_number~=nil then
       self.max_number = max_number
    end
end

function SliderNode:setDelegate(delegate)
    self.delegate = delegate
end

function SliderNode:floatToInt(x)
    if x <= 0 then
       return math.ceil(x)
    end
    if math.ceil(x) == x then
       x = math.ceil(x)
    else
       x = math.ceil(x) - 1
    end
    return x
end

return SliderNode






--endregion
