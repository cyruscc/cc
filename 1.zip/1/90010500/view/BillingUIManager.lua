--region *.lua
--Date
--此文件由[BabeLua]插件自动生成

local CImageNode = import("....ui.CImageNode")


local BillingUIManager = class("BillingUIManager")


function BillingUIManager:ctor(ui_project, ui_root)

    self.ui_project = ui_project
    self.ui_root = ui_root

    self.table_ui_billing = {}
    for i=1,  5 do
        local ui_billing  = ui_project:getChildByName("Panel_billing_"..(i-1))
        self.table_ui_billing[i] = ui_billing 
        ui_billing:setVisible(false)
    end

end

--结算清理
function BillingUIManager:game_end_clear()

    self:ui_close()
    self.game_end_resp_table = nil

end

    --获取UIBilling
function BillingUIManager:getUIBilling(chair, last_state)
    return ViewHelp.getUIObject(chair, self.table_ui_billing, last_state)
end

    --设置开牌
function BillingUIManager:setUIBillingCardByChair(chair, table_billing)
    self.ui_root:getCardUIManager():getUICard(chair):setVisible(false)
    self:setUIBillingCard(self:getUIBilling(chair), table_billing)
end
    --设置开牌
function BillingUIManager:setUIBillingCard(ui_billing, table_billing)
     ui_billing:setVisible(true)
     for i=1, 5 do
       local Image_card = ui_billing:getChildByName("Image_card_"..(i-1))
       local low = table_billing.cards[i]%16%13
       local hight = (table_billing.cards[i]-table_billing.cards[i]%16)/16
       Image_card:loadTexture("game_res/90010500/card/card_"..tostring(hight).."_"..tostring(low)..".png")
    end
    local Image_card_type = ui_billing:getChildByName("Image_card_type")
    local Image_atlasLabel = ui_billing:getChildByName("Image_atlasLabel")
    local Image_card_type_bg = ui_billing:getChildByName("Image_card_type_bg")
    local Panel_card_type = ui_billing:getChildByName("Image_card_type")

    
    Image_card_type:setVisible(false)
    Image_atlasLabel:setVisible(false)
    Image_card_type_bg:setVisible(false)
    Panel_card_type:setVisible(false)
    Panel_card_type:removeAllChildren()
end

    --设置牛点
function BillingUIManager:setUIBillingCardType(ui_billing, table_billing, animate, call_func)
    local Image_card_type = ui_billing:getChildByName("Image_card_type")
    local Image_card_type_bg = ui_billing:getChildByName("Image_card_type_bg")
    if animate then
       local Panel_card_type = ui_billing:getChildByName("Panel_card_type")
       Panel_card_type:setVisible(true)
       Panel_card_type:removeAllChildren()
       if table_billing.boy then
            Music:playEffect("game_res/90010500/sound/niu/niu_boy_"..tostring(table_billing.cardType)..".mp3", false)
       else
            Music:playEffect("game_res/90010500/sound/niu/niu_girl_"..tostring(table_billing.cardType)..".mp3", false)
       end
       self.ui_root:playGameAnimate(string.format("game_res/90010500/armature/niudian/%d.csb", table_billing.cardType%14),
       Panel_card_type,
       {x=0, y=0},
       function()
          if call_func then
             call_func()
          end
       end,
       true
       )
    else
       Image_card_type:setVisible(true)
       Image_card_type_bg:setVisible(true)
       local Panel_card_type = ui_billing:getChildByName("Panel_card_type")
       Panel_card_type:removeAllChildren()
       Image_card_type:loadTexture("game_res/90010500/armature/niudian/niu_"..tostring(table_billing.cardType)..".png")
    end
end

    --设置输赢数字
function BillingUIManager:setUIBillingNum(ui_billing, table_billing)
   local Image_atlasLabel = ui_billing:getChildByName("Image_atlasLabel")
   Image_atlasLabel:setVisible(true)
   local AtlasLabel = Image_atlasLabel:getChildByName("AtlasLabel")
   local text = ""
   local res_path = "game_res/90010500/com/num_game_0.png"
   local res_path_bg = "game_res/90010500/gameScene/game_number_bg_0.png"
   if table_billing.iChangePoint>0 then
          text = "."..tostring(table_billing.iChangePoint)
   elseif table_billing.iChangePoint==0 then
          text = tostring(table_billing.iChangePoint)
   else
          text = "/"..tostring(table_billing.iChangePoint)
          res_path = "game_res/90010500/com/num_game_1.png"
          res_path_bg = "game_res/90010500/gameScene/game_number_bg_1.png"
   end
   AtlasLabel:setProperty(text, res_path, 32, 45, '.') 
   Image_atlasLabel:loadTexture(res_path_bg)
end

    --结算
function BillingUIManager:game_end(resp_table, animate)
    if not resp_table then
       return
    end
    self.game_end_resp_table = resp_table
    self:ui_open()
    for i=1,  #self.table_ui_billing do
        self.table_ui_billing[i]:setVisible(false)
    end
    if not animate then
        self.ui_root:getCardUIManager():ui_close()
        for key, var in pairs(resp_table) do
            local ui_billing = self:getUIBilling(key)
            self:setUIBillingCard(ui_billing, var)
            self:setUIBillingCardType(ui_billing, var)
            self:setUIBillingNum(ui_billing, var)
        end
        self.ui_root:getPlayerUIManager():game_end(resp_table)
       return
    end
    function getMaxValue(cards)
        if not cards or #cards<=0 then
           return nil
        end
        local maxValue = cards[1]
        for i=1, #cards do
           if cards[i]>maxValue then
              maxValue = cards[i]
           end
        end
        return maxValue
    end
    function cardTableCompare(card_table_1, card_table_2)
        if card_table_1.cardType>card_table_2.cardType then
            return true
        elseif card_table_1.cardType==card_table_2.cardType then
            if getMaxValue(card_table_1.cards)>getMaxValue(card_table_2.cards) then
                return true
            else
                return false
            end
        else
            return false
        end
    end
    local sort_rsp = {}
    for key, var in pairs(resp_table) do
        if key~=ViewHelp.getBankerChair() then
            local i=#sort_rsp
            local index = #sort_rsp
            while i>0 do
                if cardTableCompare(sort_rsp[i], var) then
                    index = index-1
                else
                    break
                end
                i = i-1
            end
            table.insert(sort_rsp, index+1, var)
            sort_rsp[index+1].chair = key
            sort_rsp[index+1].boy = ViewHelp.get_player_info_by_chairID(key).boy
        end
    end
    if ViewHelp.getBankerChair()>=0 then
        local banker_rsp = resp_table[ViewHelp.getBankerChair()]
        if banker_rsp then
            banker_rsp.boy = ViewHelp.get_player_info_by_chairID(ViewHelp.getBankerChair()).boy
            banker_rsp.chair = ViewHelp.getBankerChair()
            table.insert(sort_rsp, #sort_rsp+1, banker_rsp)
        end
    end
    
    local function animate_win_lose()
       if resp_table[ViewHelp.getSelfPlayer().chair] then
          local iChangePoint = resp_table[ViewHelp.getSelfPlayer().chair].iChangePoint
          if iChangePoint>=0 then
              Music:playEffect("game_res/90010500/sound/game/game_win.mp3", false)
          else
              Music:playEffect("game_res/90010500/sound/game/game_lose.mp3", false)
          end
          if iChangePoint>0 then
             self.ui_root:playGameAnimate("game_res/90010500/armature/SL/SL.csb", nil, nil, function()
                self:game_end_animate(resp_table)
             end)
          elseif iChangePoint==0 then
             self.ui_root:playGameAnimate("game_res/90010500/armature/PG/PG.csb", nil, nil, function()
                self:game_end_animate(resp_table)
             end)
          else
             self.ui_root:playGameAnimate("game_res/90010500/armature/SB/SB.csb", nil, nil, function()
                self:game_end_animate(resp_table)
             end)
          end
        else
            self:game_end_animate(resp_table)
        end
    end
    local cur_i = 1
    local function endAnimate()
        self:setUIBillingCardByChair(sort_rsp[cur_i].chair, sort_rsp[cur_i])
        if cur_i==#sort_rsp then
            self:setUIBillingCardType(self:getUIBilling(sort_rsp[cur_i].chair), sort_rsp[cur_i], animate,  function()
                animate_win_lose()
            end) 
        else
            self:setUIBillingCardType(self:getUIBilling(sort_rsp[cur_i].chair), sort_rsp[cur_i], animate,  function()
                endAnimate()
            end) 
            cur_i = cur_i+1 
        end
    end
    endAnimate()
end

    --输赢钱动画
function BillingUIManager:game_end_animate(resp_table)
    local loseMaxChair = -1
    local loseMax = 1
    local winMaxChair = -1
    local winMax = -1
    for key, var in pairs(resp_table) do
        if key~=ViewHelp.getBankerChair() then
            if var.iChangePoint<0 then
                if var.iChangePoint<loseMax then
                    loseMax = var.iChangePoint
                    loseMaxChair = key
                end
            else
                if var.iChangePoint>winMax then
                    winMax = var.iChangePoint
                    winMaxChair = key
                end
            end
        end
    end
    if loseMaxChair==-1 then
       self:game_end_animate_win(resp_table, winMaxChair)
    else
       self:game_end_animate_lose(resp_table, loseMaxChair, winMaxChair)
    end

end

    --输钱动画
function BillingUIManager:game_end_animate_lose(resp_table, loseMaxChair, winMaxChair)
     Music:playEffect("game_res/90010500/sound/game/game_fly_coin.mp3", false)
     for key, var in pairs(resp_table) do
        if var.iChangePoint<0 and key~=ViewHelp.getBankerChair() then
           local call_func_lose = nil
           if key==loseMaxChair then
                 call_func_lose = function()
                    self:game_end_animate_win(resp_table, winMaxChair)
                 end
           end
           self:coinMoveAction(key, ViewHelp.getBankerChair(), 10+math.abs(var.iChangePoint)/ViewHelp.getDeskConfig().config.antes, call_func_lose)
      end
   end
end

    --赢钱动画
function BillingUIManager:game_end_animate_win(resp_table, winMaxChair)
    Music:playEffect("game_res/90010500/sound/game/game_fly_coin.mp3", false)
    local function animate_win_call()
        for key, var in pairs(resp_table) do
            local ui_billing = self:getUIBilling(key)
            self:setUIBillingNum(ui_billing, var)
        end

--        for key, var in pairs(resp_table) do
--            local desk_player = ViewHelp.get_player_info_by_chairID(key)
--            if desk_player then
--                desk_player.profit = desk_player.profit+var.iChangePoint
--                desk_player.point = var.iTotalPoint
--                if desk_player.profit>desk_player.behavior.MaxProfit then
--                  desk_player.behavior.MaxProfit = desk_player.profit
--                end
--            end
--        end
        self.ui_root:getPlayerUIManager():game_end(resp_table)
--        self.ui_root:updateGameRecord()
    end
    if winMaxChair~=-1 then
         for key, var in pairs(resp_table) do
             if var.iChangePoint>0 and key~=ViewHelp.getBankerChair() then
                local call_func_win = nil
                if key==winMaxChair then
                   call_func_win = function()
                      animate_win_call()
                   end
                end
                self:coinMoveAction(ViewHelp.getBankerChair(), key, 5+math.abs(var.iChangePoint)/ViewHelp.getDeskConfig().config.antes, call_func_win)
            end
        end
    else
        animate_win_call()
    end
end

    --金币移动动画
function BillingUIManager:coinMoveAction(chair_begin, chair_end, num, call_func)

    if ViewHelp.getDeskConfig().config.NoteType==1 then
       num = math.random(5, 20)
    end
    for i=1, num  do

        local sprite = cc.Sprite:create("game_res/90010500/com/c_animate_coin.png")

        sprite:setScale(1.5)
        self.ui_root:getAnimatePanel():addChild(sprite)

        local ui_player_begin = self.ui_root:getPlayerUIManager():getUIPlayer(chair_begin)
   
        local Image_head_begin = self.ui_root:getPlayerUIManager():getUIPlayerChild(ui_player_begin, "Image_seat_bg", "Image_head")
        
        local point_begin  = Image_head_begin:convertToWorldSpace(cc.p(0, 0))

        sprite:setPosition(cc.p(point_begin.x+math.random(math.ceil(Image_head_begin:getContentSize().width)), point_begin.y+math.random(math.ceil(Image_head_begin:getContentSize().height))))

        local ui_player_end = self.ui_root:getPlayerUIManager():getUIPlayer(chair_end)
        local Image_head_end = self.ui_root:getPlayerUIManager():getUIPlayerChild(ui_player_end, "Image_seat_bg", "Image_head")
        local point_end  = Image_head_end:convertToWorldSpace(cc.p(0, 0))
        local moveTo = cc.MoveTo:create(0.25, cc.p(point_end.x+math.random(math.ceil(Image_head_begin:getContentSize().width)), point_end.y+math.random(math.ceil(Image_head_begin:getContentSize().height))))
        local easeIn = cc.EaseIn:create(moveTo, 2.5)
        local spawn_move = cc.Spawn:create(moveTo, easeIn)
      
        local delayTime = cc.DelayTime:create(0.025*(i-1))
        local fadeIn = cc.FadeIn:create(0.025*(i-1))
        local spawn_in = cc.Spawn:create(delayTime, fadeIn)

        local fadeOut = cc.FadeOut:create(0.2)

        local removeSelf = cc.RemoveSelf:create()

        local sequence = nil

        if i==num then
            local delayTime_end = cc.DelayTime:create(0.5)
            if call_func~=nil then
                local callFunc = cc.CallFunc:create(call_func)
                sequence = cc.Sequence:create(spawn_in, spawn_move, fadeOut, delayTime_end, callFunc, removeSelf)
            else
                sequence = cc.Sequence:create(spawn_in, spawn_move, fadeOut, delayTime_end, removeSelf)              
            end
        else
            sequence = cc.Sequence:create(spawn_in, spawn_move, fadeOut, removeSelf)
        end

        sprite:runAction(sequence)  

    end

end

-- 有玩家坐下
function BillingUIManager:playerSitDesk( user_info )

    if ViewHelp.getBasePosUserID()==tonumber(user_info.userID) and self.game_end_resp_table~=nil then
        self.ui_root:getAnimatePanel():removeAllChildren()
        self:game_end(self.game_end_resp_table)
    end

end


function BillingUIManager:ui_open()
    self.ui_project:setVisible(true)
end

function BillingUIManager:ui_close()
    self.ui_project:setVisible(false)
end

return BillingUIManager

--endregion
