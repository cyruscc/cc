--region *.lua
--Date
--此文件由[BabeLua]插件自动生成


local STATE_ALLOW = 0
local STATE_FORBIT = 1

local m_download = import("....common.download")
local CAddGamePointLayer  = import("....room.view2.room.AddGamePointLayer")

local GamePersonalLayer = class("GamePersonalLayer", function()
    return cc.CSLoader:createNode("game_res/90010500/gameScene/GamePersonalLayer.csb")
end)

function GamePersonalLayer:ctor(desk_player, ui_root)
    self.desk_player = clone(desk_player)
    local Panel_root = self:getChildByName("Panel_root")
    self.Image_root = Panel_root:getChildByName("Image_root")
    api_action_showPageLayer( self.Image_root )

    local Button_close = self.Image_root:getChildByName("Button_close")
    Button_close:addClickEventListener(function()
        self:recvKeyBack()
    end
    )

    local Text_id = self.Image_root:getChildByName("Text_id")
    Text_id:setString("ID:"..self.desk_player.userID)

    local Text_ip = self.Image_root:getChildByName("Text_ip")
    Text_ip:setString("IP:"..self.desk_player.dwUserIP)

    local Text_name = self.Image_root:getChildByName("Text_name")
    Text_name:setString( api_get_ascll_sub_str_by_ui(self.desk_player.nick , 14) )


    local Image_sex = self.Image_root:getChildByName("Image_sex")
    if self.desk_player.boy == 1 then
        Image_sex:loadTexture("game_res/90010500/com/c_icon_boy.png")
    else
        Image_sex:loadTexture("game_res/90010500/com/c_icon_girl.png")
    end

    local Image_head = self.Image_root:getChildByName("Image_head")
    m_download:get_instance():set_head_image_and_auto_update( Image_head , self.desk_player.avatarUrl , self.desk_player.userID )

    
        --举报
    local Button_report =self. Image_root:getChildByName("Button_report")
    Button_report:addClickEventListener(function()
        self:recvKeyBack()
    end
    )

    local Button_closeRecorder = self.Image_root:getChildByName("Button_closeRecorder")
    local function setRecorder( isClose )
        print( "屏蔽语音 " , isClose )
        if isClose then
            Button_closeRecorder:loadTextureNormal("game_res/90010500/gameScene/playerinfo/open_recorder.png")
        else
            Button_closeRecorder:loadTextureNormal("game_res/90010500/gameScene/playerinfo/close_recorder.png")
        end
    end

    setRecorder( ViewHelp.isElementOfVoiceNotTable(self.desk_player.userID) )
    Button_closeRecorder:addClickEventListener(function()
        if ViewHelp.isElementOfVoiceNotTable(self.desk_player.userID) then
            setRecorder( false )
            ViewHelp.removeVoiceNotTable(self.desk_player.userID)
        else
            setRecorder( true )
            ViewHelp.insertVoiceNotTable(self.desk_player.userID)
        end
        
    end)

        --添加分数
    local Button_addPoint = self.Image_root:getChildByName("Button_addPoint")
    Button_addPoint:addClickEventListener(function()
        local user_info = ViewHelp.get_player_info_by_userID(self.desk_player.userID)
        if user_info == nil then
            api_show_tips("该玩家已离开房间")
            return nil
        end
        local apply_info ={}
        apply_info.apply_user_nickName = user_info.nick
        apply_info.apply_user_tablePoint = user_info.point
        apply_info.apply_user_id = user_info.userID
        apply_info.desk_id=ViewHelp.getDeskConfig().roomID


        ui_root:addChild(CAddGamePointLayer:create(apply_info, true))
    end
    )
        --踢人
    local Button_kicking = self.Image_root:getChildByName("Button_kicking")
    Button_kicking:addClickEventListener(function()
        local msgTips = api_show_Msg_Tip( "踢出后是否允许再次进入房间？", function()
            ViewHelp.getGameScene():reqBootPlayer(self.desk_player.userID, false)
            self:recvKeyBack()
        end, function()
            ViewHelp.getGameScene():reqBootPlayer(self.desk_player.userID, true)
            self:recvKeyBack()
        end)
        msgTips:setButtonOkTitle("允许")
        msgTips:setButtonCancelTitle("拒绝")
    end
    )

    if  ViewHelp.getDeskConfig().mastUserID~=ViewHelp.getBasePosUserID() then
        Button_addPoint:setTouchEnabled(false)
        Button_addPoint:setBright(false)
        Button_kicking:setTouchEnabled(false)
        Button_kicking:setBright(false)
    end

    if  ViewHelp.getDeskConfig().mastUserID==self.desk_player.userID then
        Button_kicking:setTouchEnabled(false)
        Button_kicking:setBright(false)
    end

    self:registerScriptHandler(handler(self,self.onNodeEvent))

end

function GamePersonalLayer:recvKeyBack()
    if nil == self.isRecvKeyBack then
        self.isRecvKeyBack = true
        api_action_hidePageLayer( self.Image_root , function()
            self:removeFromParent()
        end)
    end
end


function GamePersonalLayer:onNodeEvent(event)

    if event == "enter" then
        g_pushBombBox(self)
    elseif event == "exit" then
        g_popBombBox(self)
    end

end


return GamePersonalLayer




--endregion
