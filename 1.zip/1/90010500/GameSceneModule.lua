--此层是为了将脚本转成面向对象结构新建

local GameSceneModule = class("GameSceneModule")

function GameSceneModule:getInstance()
    if not self.GameSceneModule then
       self.GameSceneModule = self.new()
    end
    return self.GameSceneModule
end

function GameSceneModule:init(GameScene)
    self.GameScene = GameScene
    GameScene:getHelper():setGameMessageHandler( self )
end

    --准备倒计时取消
function GameSceneModule:response_game_ready_timer_cancel(resp_json)
    local resp_table = {}
    self.GameScene:game_ready_timer_cancel(resp_table)
end
    --准备倒计时
function GameSceneModule:response_game_ready_timer(resp_json)
    local resp_table = {}
    resp_table.time = resp_json.time
    self.GameScene:game_ready_timer(resp_table)
end

    --玩家准备
function GameSceneModule:request_player_ready()    
    local request = {}
    request.chair = ViewHelp.getSelfPlayer().chair
    ViewHelp.getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.T_PLAYER_READY, request)

    print("玩家请求准备------------------------------------------------------------------------------%d", chair)

end

function GameSceneModule:response_player_ready(resp_json)
    local resp_table = {}
    resp_table.chair = resp_json.chair
    self.GameScene:player_ready(resp_table)
end

    --游戏开始51
function GameSceneModule:response_game_start(resp_json)
    dump( resp_json )
    local resp_table = {}
    local playerData = {}
    for i=1, #resp_json.playerData do
       playerData[i] = {}
       playerData[i].chair = resp_json.playerData[i].chair
       playerData[i].point = resp_json.playerData[i].point
    end
    resp_table.playerData = playerData
    resp_table.antes = resp_json.antes
    resp_table.bankerType = resp_json.bankerType
    resp_table.CurRounds = resp_json.CurRounds 
    resp_table.MaxRounds = resp_json.MaxRounds
    resp_table.NoteType  = resp_json.NoteType

    self.GameScene:game_start(resp_table)
end

    --通知玩家叫庄
function GameSceneModule:response_game_banker_notify(resp_json)
    local resp_table = {}
    resp_table.chair = resp_json.chair
    resp_table.bankertime = resp_json.bankertime
    self.GameScene:game_banker_notify(resp_table)
end

    --玩家叫庄
function GameSceneModule:request_player_banker(chair, bIsQiang)

    local request = {}
    request.chair = chair
    request.bIsQiang = bIsQiang
    ViewHelp.getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.T_PLAYER_BANKER, request)
end

function GameSceneModule:response_player_banker(resp_json)

    local resp_table = {}
    resp_table.chair = resp_json.chair
    resp_table.bIsQiang = resp_json.bIsQiang
    self.GameScene:player_banker(resp_table)
end


    --叫庄结束
function GameSceneModule:response_game_banker_end(resp_json)

    local resp_table = {}
    resp_table.chair = resp_json.chair
    resp_table.iTipFlag = resp_json.iTipFlag
    resp_table.players = resp_json.players
    self.GameScene:game_banker_end(resp_table)
end

--    --随机庄结束62
--function GameSceneModule:response_game_banker_rand(resp_json)

--    local resp_table = {}
--    resp_table.chair = resp_json.chair
--    resp_table.iTipFlag = resp_json.iTipFlag
--    if resp_json.players then
--       resp_table.players = {}
--       for i=1, #resp_json.players do
--          resp_table.players[i] = resp_json.players[i]
--       end
--    end
--    self.GameScene:game_banker_rand(resp_table)
--end

    --通知玩家下注55
function GameSceneModule:response_game_bet_notify(resp_json)

    local resp_table = {}
    resp_table.betTime = resp_json.betTime
    local betItems = {}
    for i=1, #resp_json.betItems do
       local _betItems = {}
       _betItems.chair = resp_json.betItems[i].chair
       _betItems.point = resp_json.betItems[i].point
       _betItems.multiply = resp_json.betItems[i].multiply
       _betItems.note = {}
       if resp_json.betItems[i].note and #resp_json.betItems[i].note>0 then
          for j=1, #resp_json.betItems[i].note do
             _betItems.note[j] = resp_json.betItems[i].note[j]
          end
       end
       betItems[i] = _betItems
    end
    resp_table.betItems = betItems
    self.GameScene:game_bet_notify(resp_table)
end


    --玩家下注
function GameSceneModule:request_player_bet(chair, multiplying)
    local request = {}
    request.chair = chair
    request.multiplying = multiplying
    ViewHelp.getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.T_PLAYER_BET, request)
end

function GameSceneModule:response_player_bet(resp_json)

    local resp_table = {}
    resp_table.chair = resp_json.chair
    resp_table.multiplying = resp_json.multiplying
    self.GameScene:player_bet(resp_table)
end

    --发牌
function GameSceneModule:response_game_card_send(resp_json)
    local resp_table = {}
    for i=1, #resp_json do
        local user_json = resp_json[i]
        local resp_user_crad = {}
        for j=1, #user_json.cards do
           resp_user_crad[j] = user_json.cards[j]
        end
        resp_table[user_json.chair]=resp_user_crad
    end
    self.GameScene:game_card_send(resp_table)
end

    --开始开牌
function GameSceneModule:response_game_card_open(resp_json)

    local resp_table = {}
    resp_table.displayTime = resp_json.displayTime
    self.GameScene:game_card_open(resp_table)
end

    --玩家开牌
function GameSceneModule:request_player_card_open(chair)

    local request = {}
    request.chair = chair
    ViewHelp.getGameScene():getHelper():sendGameMessage(Table_GameMessage_ASSID.T_PLAYER_CARD_OPEN, request)
end

function GameSceneModule:response_player_card_open(resp_json)

    local resp_table = {}
    resp_table.chair = resp_json.chair
    resp_table.remain = resp_json.remain
    self.GameScene:player_card_open(resp_table)
end

    --结算
function GameSceneModule:response_game_end(resp_json)
    local resp_table = {}
    for i=1, #resp_json do
        local user_json = resp_json[i]
        local resp_user ={}
        local resp_user_crad = {}
        for j=1, #user_json.cards do
           resp_user_crad[j] = user_json.cards[j]
        end
        resp_user.cards = resp_user_crad
        resp_user.cardType = user_json.cardType
        resp_user.iChangePoint = user_json.iChangePoint
        resp_user.iTotalPoint = user_json.iTotalPoint
        resp_table[user_json.chair]=resp_user
    end
    self.GameScene:game_end(resp_table)
end


    --断线重连
function GameSceneModule:response_game_rebind(resp_json)

    local resp_table = {}

        --游戏准备阶段
    if resp_json.GameStation == 0 or resp_json.GameStation == 1 then
     
        self:game_rebind_json_analys(resp_table,resp_json)

        --游戏叫庄阶段
    elseif resp_json.GameStation==20 then

        self:game_rebind_json_analys(resp_table,resp_json)

        --游戏下注阶段
    elseif resp_json.GameStation==21 then

        self:game_rebind_json_analys(resp_table,resp_json)
        local table_playerData = {}
        if resp_json.playerData~=nil then
            for i=1, #resp_json.playerData do
                local _playerData = {}
                local playerData_json = resp_json.playerData[i]
                _playerData.chair = playerData_json.chair
                _playerData.bIsDo = playerData_json.bIsDo
                _playerData.multiplying = playerData_json.multiplying
                _playerData.maxMultiply = playerData_json.maxMultiply
                local _note = {}
                if playerData_json.note then
                   for j=1, #playerData_json.note do
                       _note[j] = playerData_json.note[j]
                   end
                end
                _playerData.note  = _note
                table_playerData[i] = _playerData
            end
        end
        resp_table.table_playerData = table_playerData

        --游戏发牌阶段
    elseif resp_json.GameStation==22 then

        self:game_rebind_json_analys(resp_table,resp_json)
        local table_playerData = {}
        if resp_json.playerData~=nil then
            for i=1, #resp_json.playerData do
                local _playerData = {}
                local playerData_json = resp_json.playerData[i]
                _playerData.chair = playerData_json.chair
                _playerData.multiplying = playerData_json.multiplying
                local table_card = {}
                for j=1, #playerData_json.cards do
                    table_card[j] = playerData_json.cards[j]
                end
                _playerData.table_card = table_card
                table_playerData[i] = _playerData
            end
        end
        resp_table.table_playerData = table_playerData

         --游戏开牌阶段
    elseif resp_json.GameStation==23 then

        self:game_rebind_json_analys(resp_table,resp_json)
        local table_playerData = {}
        if resp_json.playerData~=nil then
            for i=1, #resp_json.playerData do
                local _playerData = {}
                local playerData_json = resp_json.playerData[i]
                _playerData.chair = playerData_json.chair
                _playerData.multiplying = playerData_json.multiplying
                _playerData.bIsDo = playerData_json.bIsDo
                local table_card = {}
                for j=1, #playerData_json.cards do
                    table_card[j] = playerData_json.cards[j]
                end
                _playerData.table_card = table_card
                table_playerData[i] = _playerData
            end
        end

        resp_table.table_playerData = table_playerData

        --游戏结算阶段
    elseif resp_json.GameStation==24 then

        self:game_rebind_json_analys(resp_table,resp_json)

    end
    self.GameScene:game_rebind(resp_table)
end

function GameSceneModule:response_game_record( resp_json )
    self.GameScene:show_game_record()
end

function GameSceneModule:response_game_lack_point( resp_json )
    self.GameScene:pointLease()
end

function GameSceneModule:game_rebind_json_analys(resp_table, resp_json)

   resp_table.GameStation = resp_json.GameStation
   resp_table.iLeaverTime = resp_json.iLeaverTime
   resp_table.bankerType = resp_json.bankerType
   resp_table.chair = resp_json.chair
   resp_table.iTipFlag = resp_json.iTipFlag
   resp_table.deskActive = resp_json.deskActive
   local table_bAgree = {}
    if resp_json.bAgree~=nil then
        for i=1, #resp_json.bAgree do
            local bAgree_json = resp_json.bAgree[i]
            table_bAgree[bAgree_json.chair] = bAgree_json.bAgree
        end
    end
    resp_table.table_bAgree = table_bAgree
end

return GameSceneModule