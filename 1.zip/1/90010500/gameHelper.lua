---------------------------------------------------------
-- 日期：	20150807
-- 作者:	xxm
-- 描述:	游戏房间业务数据层接口
-- 注意:    尽可能业务逻辑独立(维护成本降到最低)
-----------------------------------------------------------------------------


local gameHelperBase = import("app.platform.game.gameHelperBase")
local gameHelperModule = class("gameHelperModule" , gameHelperBase )

local CURRENT_MODULE_NAME = ... 

local GameMessage_MainID = 180

Table_GameMessage_ASSID = 
{
    --消息接收和发送ID相同
    T_GAME_READY_TIMER_CANCEL = 47,--准备倒计时取消
    T_GAME_READY_TIMER = 48,--准备倒计时
    T_PLAYER_READY = 49,--玩家准备
    T_GAME_START = 51,--游戏开始
    T_GAME_BANKER_NOTIFY = 52,--通知玩家叫庄
    T_PLAYER_BANKER = 53,--玩家叫庄
    T_GAME_BANKER_END = 54,--叫庄结束
    --T_GAME_BANKER_RAND = 62,--随机庄
    T_GAME_BET_NOTIFY = 55,--通知玩家下注
    T_PLAYER_BET = 56,--玩家下注
    T_GAME_CARD_SEND = 57,--发牌
    T_GAME_CARD_OPEN = 59,--开始开牌
    T_PLAYER_CARD_OPEN = 60,--玩家开牌
    T_GAME_END = 61,--结算
    T_GAME_RECORD = 62 , --游戏结束战绩
    T_GAME_REBIND = 2,--断线重连
    T_PLAYER_POINT_LEASE = 210,
    T_LACK_POINT = 71,
}

local Table_Action_Handler = {}

local Local_handler = nil


function gameHelperModule:ctor()
    self.super:ctor( 5 )
end


function gameHelperModule:setGameMessageHandler(handler)
    Local_handler = handler
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_READY_TIMER_CANCEL] = handler.response_game_ready_timer_cancel
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_READY_TIMER] = handler.response_game_ready_timer
    Table_Action_Handler[Table_GameMessage_ASSID.T_PLAYER_READY] = handler.response_player_ready
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_START] = handler.response_game_start
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_BANKER_NOTIFY] = handler.response_game_banker_notify
    Table_Action_Handler[Table_GameMessage_ASSID.T_PLAYER_BANKER] = handler.response_player_banker
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_BANKER_END] = handler.response_game_banker_end
    --Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_BANKER_RAND] = handler.response_game_banker_rand
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_BET_NOTIFY] = handler.response_game_bet_notify
    Table_Action_Handler[Table_GameMessage_ASSID.T_PLAYER_BET] = handler.response_player_bet
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_CARD_SEND] = handler.response_game_card_send
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_CARD_OPEN] = handler.response_game_card_open
    Table_Action_Handler[Table_GameMessage_ASSID.T_PLAYER_CARD_OPEN] = handler.response_player_card_open
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_END] = handler.response_game_end
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_REBIND] = handler.response_game_rebind
    Table_Action_Handler[Table_GameMessage_ASSID.T_GAME_RECORD] = handler.response_game_record
    Table_Action_Handler[Table_GameMessage_ASSID.T_LACK_POINT] = handler.response_game_lack_point
end


-- 收到具体游戏消息（180）的游戏接口
-- message 为json数据时 len 参数为nil
function gameHelperModule:handleGameMessage( AssistantID , message , len )
    if Table_Action_Handler[AssistantID]~=nil then
        Table_Action_Handler[AssistantID](Local_handler, message)
    end
end

-- 自己进入游戏，切换场景
function gameHelperModule:selfJoinDesk( hcode , room_info )
    print("selfJoinDesk----------------------------")
    local game_scene  = GameApp:enterScene('game.90010500.view.GameScene')   -- 进入游戏
    self.super:init_game( game_scene )
end



function gameHelperModule:performWithDelay(node, callback, delay)
	cclog('-------------------------------performWithDelay'..delay)
    --local delay = CCDelayTime:create(delay)
    --local callfunc = CCCallFunc:create(callback)
    --local sequence = CCSequence:createWithTwoActions(delay, callfunc)
    local sequence = cc.Sequence:create(cc.DelayTime:create(delay), cc.CallFunc:create(callback))
    node:runAction(sequence)
    return sequence
end

function gameHelperModule:loadWidget(jsonFile)
    --local node = GUIReader:shareReader():widgetFromJsonFile(jsonFile)
    --return node
    local node = cc.CSLoader:createNode(jsonFile)
    return node
end

function gameHelperModule:seekWidgetByName(root, name, classname)
--	local node = UIHelper:seekWidgetByName(root, name)
--	if classname ~= nil then
--		node = tolua.cast(node, classname)
--	end
--    return node
    
	local node = root:getChildByName(name)
	if classname ~= nil then
		--node = tolua.cast(node, classname)
        return node
	end
    return node
end

function gameHelperModule:playActionByName(name, ani)
	ActionManager:shareManager():playActionByName(name, ani)
end

function gameHelperModule:playActionByNode(csbName, node)
    local action = cc.CSLoader:createTimeline(csbName)
    node:runAction(action)
    action:gotoFrameAndPlay(0, false)
end


return gameHelperModule
